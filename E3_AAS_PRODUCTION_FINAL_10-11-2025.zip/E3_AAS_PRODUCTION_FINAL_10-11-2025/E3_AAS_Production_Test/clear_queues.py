#!/usr/bin/env python3
"""
Clear RabbitMQ Queues
"""

import pika

def clear_queues():
    """Clear all test queues"""
    try:
        connection = pika.BlockingConnection(
            pika.ConnectionParameters(host='localhost', port=5672)
        )
        channel = connection.channel()
        
        # Purge test queues
        queues = ['test_queue1', 'test_queue2', 'pdcc_queue']
        for queue in queues:
            try:
                channel.queue_purge(queue)
                print(f"✅ Cleared queue: {queue}")
            except Exception as e:
                print(f"⚠️  Queue {queue} not found or already empty: {e}")
        
        connection.close()
        print("✅ All queues cleared")
        return True
        
    except Exception as e:
        print(f"❌ Failed to clear queues: {e}")
        return False

if __name__ == "__main__":
    clear_queues()
