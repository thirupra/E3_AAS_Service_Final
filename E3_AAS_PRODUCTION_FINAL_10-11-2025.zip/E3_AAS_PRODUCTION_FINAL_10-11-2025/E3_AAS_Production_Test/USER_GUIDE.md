# Automatic Announcement Service (AAS) v1.0.0 - User Guide

## Overview

The Automatic Announcement Service (AAS) v1.0.0 is a production-ready, enterprise-grade solution for automatically processing and delivering audio announcements in IRIS+ platform environments. This guide covers configuration, operation, and troubleshooting.

## Table of Contents
1. [Quick Start](#quick-start)
2. [Configuration Reference](#configuration-reference)
3. [Message Formats](#message-formats)
4. [Operation Procedures](#operation-procedures)
5. [Monitoring & Logging](#monitoring--logging)
6. [Troubleshooting](#troubleshooting)
7. [Best Practices](#best-practices)

## Quick Start

### Starting the Service
```bash
# Start AAS service
sudo systemctl start aas

# Check status
sudo systemctl status aas

# View real-time logs
sudo journalctl -u aas -f
```

### Sending Test Announcements
```bash
cd /opt/aas/scripts

# Send single announcement
python3 test_pdcc_single_annout.py

# Monitor PPM responses
python3 ppm_receiver.py
```

## Configuration Reference

### Core Configuration File: broker_config.json

#### Device Identity Configuration
```json
{
  "device_identity": {
    "product": "ela",                // Product type: Electronic Audio (ela)
    "service": "aag",                // Service type: Audio Announcement Gateway (aag)
    "instance": "0030646e3de2",      // Unique device MAC address identifier
    "static_ip": "10.26.1.20"       // Device static IP address on network
  }
}
```

#### Scheduler Configuration
```json
{
  "scheduler": {
    "announcement_tick_ms": 500,           // How often to check for announcements (milliseconds)
    "min_sleep_ms": 50,                    // Minimum sleep time between checks
    "elisa_ack_timeout_seconds": 30,       // Timeout waiting for ELISA3 acknowledgment
    "max_pending_jobs": 4096,              // Maximum announcements in queue
    "verbose_logging": true,               // Enable detailed logging (false for production)
    "default_priority": 5                  // Default priority for announcements (1-9, 1=highest)
  }
}
```

#### Certificate Management
```json
{
  "certificate": {
    "deviceId": "wenzel.irisplus.gemini",     // Unique device identifier for certificates
    "certPath": "./device.crt",              // Path to device certificate file
    "keyPath": "./device.key",               // Path to private key file
    "ottUrl": "https://ott4.gemini:5000",    // One-Time Token server URL for cert requests
    "caBundlePath": "./ca-bundle.crt",       // Path to Certificate Authority bundle
    "signUrl": "https://ca4.gemini:4443",    // CA server URL for certificate signing
    "renewUrl": "https://ca4.gemini:4443",   // CA server URL for certificate renewal
    "ottUser": "user",                       // OTT server username
    "ottPass": "pass",                       // OTT server password
    "renewal_threshold_days": 2              // Renew certificate when 2 days before expiry
  }
}
```

#### Audio Cache Configuration  
```json
{
  "audio_cache": {
    "directory": "./audio_cache",     // Directory to store downloaded audio files
    "max_size_bytes": 2147483648,     // Maximum cache size (2GB)
    "file_extension": ".ogg"          // Audio file format extension
  }
}
```

#### IPC Configuration
```json
{
  "ipc": {
    "ftok_path": "/tmp/aas_elisa_ipc.key",   // File path for IPC key generation
    "proj_id": 65                            // Project ID for System V IPC (must match ELISA3)
  }
}
```

#### AMQP Broker Configuration
```json
{
  "amqp": {
    "host": "broker4.gemini",              // AMQP broker hostname
    "username": "wenzel",                  // Authentication username
    "port": 5671,                          // Secure AMQP port (5671 for TLS, 5672 for plain)
    "exchange": "gemini.pdc",              // Exchange for PDC (Physical Device Control)
    "routing_key": "aas.control.wenzel",   // Routing key for control messages
    "queue_name": "gemini.client.wenzel",  // Queue name for this device
    "virtual_host": "/",                   // AMQP virtual host (usually "/")
    "max_retries": 5,                      // Maximum connection retry attempts
    "retry_delay_secs": 5,                 // Delay between retry attempts
    "prefetch_count": 1                    // Number of messages to prefetch
  },
  "ppm": {
    "host": "broker4.gemini",              // PPM broker hostname
    "username": "wenzel",                  // Authentication username
    "port": 5671,                          // Secure AMQP port
    "exchange": "gemini.ppm",              // Exchange for PPM (Physical Process Monitor)
    "routing_key": "aas.monitor.wenzel",   // Routing key for monitoring messages
    "virtual_host": "/"                    // AMQP virtual host
  },
  "tdm_broker": {
    "host": "broker4.gemini",              // TDM broker hostname
    "username": "wenzel",                  // Authentication username
    "port": 5671,                          // Secure AMQP port
    "exchange": "gemini.tdm",              // Exchange for TDM (Time Division Multiplex)
    "routing_key": "ela.monitor.wenzel",   // Routing key for device monitoring
    "virtual_host": "/"                    // AMQP virtual host
  }
}
```

#### Scheduler Configuration
```json
{
  "scheduler": {
    "announcement_tick_ms": 500,        // Scheduler loop interval (ms)
    "min_sleep_ms": 50,                 // Minimum sleep between operations (ms)
    "elisa_ack_timeout_seconds": 30,    // ELISA3 acknowledgment timeout (sec)
    "max_pending_jobs": 4096,           // Maximum queued announcements
    "verbose_logging": true,            // Enable detailed logging
    "default_priority": 5               // Default announcement priority (1-9)
  }
}
```

#### Certificate Management
```json
{
  "certificate": {
    "deviceId": "wenzel.irisplus.gemini",                    // Device certificate ID
    "certPath": "/opt/aas/certs/device.crt",                // Client certificate path
    "keyPath": "/opt/aas/certs/device.key",                 // Private key path
    "ottUrl": "https://ott4.gemini:5000",                   // OTT server URL
    "caBundlePath": "/opt/aas/certs/ca-bundle.crt",         // CA bundle path
    "signUrl": "https://ca4.gemini:4443",                   // Certificate signing URL
    "renewUrl": "https://ca4.gemini:4443",                  // Certificate renewal URL
    "renewal_threshold_days": 2                             // Renewal threshold (days)
  }
}
```

#### Audio Cache Configuration  
```json
{
  "audio_cache": {
    "directory": "./audio_cache",      // Cache directory path
    "max_size_bytes": 2147483648,      // Maximum cache size (2GB)
    "file_extension": ".ogg"           // Audio file extension
  }
}
```

#### IPC Configuration
```json
{
  "ipc": {
    "ftok_path": "/tmp/aas_elisa_ipc.key", // IPC key file path
    "proj_id": 65                          // Project ID for message queue
  }
}
```

#### AMQP Broker Configuration
```json
{
  "amqp": {
    "host": "localhost",
    "port": 5672,
    "username": "guest",
    "password": "guest",
    "virtual_host": "/",
    "exchange": "test_exchange2",
    "routing_key": "test_routingkey2",
    "queue_name": "test_queue2",
    "queue_durable": true,
    "prefetch_count": 1,
    "retry_delay_secs": 5,
    "client_cert_file": "/opt/aas/certs/client.crt",
    "client_key_file": "/opt/aas/certs/client.key"
  }
}
```

## Message Formats

### PDCC ANNOUT Message (Incoming)
```json
{
  "msg-meta": {
    "id": "unique-message-id",
    "created": "2025-11-07T10:30:00.000Z",
    "type": "PDCC",
    "version": "1.5"
  },
  "physicalDeviceCommands": [
    {
      "pdevCommand": {
        "cmd-meta": {
          "deviceCommandId": "cmd-12345",
          "command": "ANNOUT",
          "channelAddress": "CH:1-1",
          "priority": 3,
          "sequenceNo": 12345,
          "announcementId": "ann-67890",
          "announcementHash": "8f4285c72ee645695d17f93ed0328784d04fa27d",
          "requestedOutputTime": "2025-11-07T10:32:00.000Z",
          "validUntil": "2025-11-07T10:45:00.000Z",
          "announcementProfile": {
            "text": "Test announcement message",
            "language": "en"
          }
        },
        "cmd-content": {
          "content-type": "text/x-url",
          "content": "https://audio.example.com/file.ogg"
        }
      }
    }
  ]
}
```

### PPM Response Message (Outgoing)
```json
{
  "timestamp": 1699351800000,
  "type": "info",
  "event": "pdc-received",
  "product": "ela",
  "service": "aag",
  "instance": "0030646e3de2",
  "metaData": {
    "deviceCommandId": "cmd-12345",
    "announcementId": "ann-67890",
    "status": "accepted"
  }
}
```

## Operation Procedures

### Daily Operations

#### Service Health Check
```bash
# Check service status
sudo systemctl status aas

# Check recent logs for errors
sudo journalctl -u aas -p err --since "today"

# Verify message processing
sudo journalctl -u aas | grep "ANNOUT\|PPM\|SUCCESS" | tail -10
```

#### Certificate Status Check
```bash
# Check certificate expiration
openssl x509 -in /opt/aas/certs/device.crt -text -noout | grep "Not After"

# Check certificate renewal logs
sudo journalctl -u aas | grep -i "certificate\|renewal\|ott"
```

### Message Testing

#### Send Test ANNOUT
```bash
cd /opt/aas/scripts

# Single announcement test
python3 test_pdcc_single_annout.py

# Sequential announcement test  
python3 test_sequential_annout_anndel.py
```

#### Monitor PPM Responses
```bash
# Start PPM message receiver
cd /opt/aas/scripts
python3 ppm_receiver.py

# In another terminal, send test message
python3 test_pdcc_single_annout.py
```

### Configuration Updates

#### Update Configuration
```bash
# Stop service
sudo systemctl stop aas

# Backup current configuration
cp /opt/aas/config/broker_config.json /opt/aas/config/broker_config.json.backup

# Edit configuration
nano /opt/aas/config/broker_config.json

# Validate JSON syntax
python3 -m json.tool /opt/aas/config/broker_config.json

# Start service
sudo systemctl start aas

# Verify configuration loaded
sudo journalctl -u aas | grep "Configuration loaded"
```

## Monitoring & Logging

### Log Levels
The AAS supports multiple log levels:
- **ERROR**: Critical errors requiring attention
- **WARNING**: Important issues that don't stop operation  
- **INFO**: Normal operational messages (default)
- **DEBUG**: Detailed diagnostic information

### Runtime Log Level Control
```bash
# Get AAS process ID
AAS_PID=$(pgrep -f aas_service)

# Cycle to next log level (ERROR -> WARNING -> INFO -> DEBUG -> ERROR)
kill -USR1 $AAS_PID

# Enable DEBUG logging immediately
kill -USR2 $AAS_PID
```

### Log Analysis

#### Key Log Patterns
```bash
# Startup and shutdown
sudo journalctl -u aas | grep -E "(Starting|Stopping|Started|Stopped)"

# Message processing
sudo journalctl -u aas | grep -E "(ANNOUT|ANNDEL|PPM|SUCCESS|ERROR)"

# Certificate operations
sudo journalctl -u aas | grep -i "certificate\|ott\|renewal"

# ELISA3 communication
sudo journalctl -u aas | grep -E "(ELISA|IPC|msgsnd|msgrcv)"

# Network connectivity
sudo journalctl -u aas | grep -E "(AMQP|Connection|Reconnect)"
```

#### Performance Monitoring
```bash
# Message processing rate
sudo journalctl -u aas --since "1 hour ago" | grep "ANNOUT" | wc -l

# Queue status
sudo journalctl -u aas | grep -E "queue.*size|pending.*jobs" | tail -5

# Cache statistics  
sudo journalctl -u aas | grep -i "cache" | tail -5
```

## Troubleshooting

### Common Issues

#### Service Won't Start
**Symptoms**: Service fails to start, error in systemctl status

**Investigation**:
```bash
sudo systemctl status aas
sudo journalctl -u aas --since "5 minutes ago"
```

**Common Causes**:
- Configuration file syntax errors
- Missing certificate files
- RabbitMQ server not running
- Permission issues

**Solutions**:
```bash
# Check configuration syntax
python3 -m json.tool /opt/aas/config/broker_config.json

# Verify RabbitMQ is running
sudo systemctl status rabbitmq-server

# Check file permissions
ls -la /opt/aas/config/
ls -la /opt/aas/certs/

# Fix permissions if needed
sudo chown -R aas:aas /opt/aas
```

#### AMQP Connection Issues
If you see errors like "Failed to connect to broker" or "AMQP connection timeout", here's what to check:

First, look at the logs to see what's happening:
```bash
sudo journalctl -u aas | grep -i "amqp\|connection\|broker"
```

Try these fixes:
```bash
# Test if RabbitMQ is running
rabbitmq-diagnostics ping

# Check if you can reach the broker
telnet broker4.gemini 5671

# Make sure your credentials are correct
rabbitmqctl list_users
```

#### Certificate Issues
When you get "Certificate validation failed" or "OTT request failed" errors:

Check the logs first:
```bash
sudo journalctl -u aas | grep -i "certificate\|ott\|ssl"
```

Then try these solutions:
```bash
# Check if your certificate is valid
openssl x509 -in ./device.crt -text -noout

# Test OTT server connection
curl -v https://ott4.gemini:5000/health

# Verify certificate chain
openssl verify -CAfile ./ca-bundle.crt ./device.crt
```

#### IPC Communication Failures
If you see "IPC key generation failed" or "Message queue creation failed":

Check the logs:
```bash
sudo journalctl -u aas | grep -i "ipc\|elisa\|message queue"
```

Fix IPC issues:
```bash
# Check current IPC resources
ipcs -q

# Remove old message queues if needed
ipcrm -q queue_id

#### Certificate Issues
**Symptoms**: "Certificate validation failed", "OTT request failed"

**Investigation**:
```bash
sudo journalctl -u aas | grep -i "certificate\|ott\|ssl"
```

**Solutions**:
```bash
# Check certificate validity
openssl x509 -in /opt/aas/certs/device.crt -text -noout

# Test OTT server connectivity
curl -v https://ott-server:5000/health

# Verify CA bundle
openssl verify -CAfile /opt/aas/certs/ca-bundle.crt /opt/aas/certs/device.crt
```

#### IPC Communication Failures
**Symptoms**: "IPC key generation failed", "Message queue creation failed"

**Investigation**:
```bash
sudo journalctl -u aas | grep -i "ipc\|elisa\|message queue"
```

**Solutions**:
```bash
# Check IPC resources
ipcs -q

# Remove stale message queues if needed
ipcrm -q queue_id

# Verify file permissions for IPC key file
ls -la /tmp/aas_elisa_ipc.key
```

### Performance Issues

#### High CPU Usage
```bash
# Monitor AAS process
top -p $(pgrep -f aas_service)

# Check scheduler frequency
sudo journalctl -u aas | grep "announcement_tick_ms"

# Consider increasing announcement_tick_ms in configuration
```

#### High Memory Usage
```bash
# Monitor memory usage
ps aux | grep aas_service

# Check queue sizes
sudo journalctl -u aas | grep -i "queue.*size\|pending.*jobs"

# Consider reducing max_pending_jobs in configuration
```

#### Audio Download Issues
```bash
# Check cache statistics
sudo journalctl -u aas | grep -i "cache\|download\|audio"

# Verify audio URLs are accessible
curl -I https://audio-server/test-file.ogg

# Check available disk space
df -h /opt/aas/audio_cache/
```

## Best Practices

### Configuration Management
1. **Always backup configuration** before making changes
2. **Use version control** for configuration files
3. **Test configuration changes** in development environment first
4. **Document environment-specific** settings

### Security
1. **Secure certificate files** with proper permissions (600 for keys, 644 for certificates)
2. **Use strong passwords** for AMQP credentials
3. **Regularly rotate certificates** before expiration
4. **Monitor for security events** in logs

### Performance Optimization
1. **Tune scheduler parameters** based on load requirements
2. **Monitor queue sizes** and adjust max_pending_jobs as needed
3. **Configure appropriate cache sizes** for your storage capacity
4. **Use SSD storage** for better I/O performance

### Monitoring
1. **Set up log rotation** to prevent disk space issues
2. **Monitor service health** with external monitoring tools
3. **Create alerts** for critical errors and certificate expiration
4. **Regularly review logs** for unusual patterns

### Maintenance
1. **Schedule regular restarts** during maintenance windows
2. **Keep system packages updated** including dependencies
3. **Monitor disk space** for logs and audio cache
4. **Document operational procedures** for team knowledge sharing

---

For additional support or questions not covered in this guide, please contact the development team or refer to the RELEASE_NOTES.md for detailed technical information.