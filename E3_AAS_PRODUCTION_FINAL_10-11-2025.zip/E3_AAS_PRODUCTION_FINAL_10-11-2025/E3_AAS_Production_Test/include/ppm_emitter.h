#ifndef PPM_EMITTER_H_
#define PPM_EMITTER_H_

#include <nlohmann/json.hpp>
#include <string>
#include <optional>

class PPMReporter; // Forward declaration

/**
 * @brief Context information for PPM message emission.
 *
 * Contains the routing and identification information needed
 * to construct and send PPM messages.
 */
struct PpmContext {
  std::string routing_key;  ///< PPM routing key from configuration
  std::string product;     ///< Product identifier (e.g., "ela")
  std::string service;     ///< Service identifier (e.g., "aag")
  std::string instance;    ///< Device instance identifier
  std::string exchange;
};

/**
 * @brief Emitter for PPM (Physical Device Management) messages.
 *
 * Provides a convenient interface for sending standardized PPM messages
 * including info, success, and error notifications.
 */
class PPMEmitter {
 public:
  /**
   * @brief Constructs a PPMEmitter instance.
   *
   * @param reporter Reference to the PPM reporter for message sending
   * @param ctx PPM context information for message construction
   */
  PPMEmitter(PPMReporter& reporter, PpmContext ctx)
      : reporter_(reporter), ctx_(std::move(ctx)) {}

  /**
   * @brief Sends a PPM info message for PDCC received.
   *
   * @param cmd_meta Command metadata from the PDCC message
   */
  void InfoPdcReceived(const nlohmann::json& cmd_meta) { 
    send("info", "pdc-received", cmd_meta, std::nullopt); 
  }

  /**
   * @brief Sends a PPM success acknowledgment message.
   *
   * @param cmd_meta Command metadata from the PDCC message
   */
  void Ack(const nlohmann::json& cmd_meta) { 
    send("success", "aag-ack", cmd_meta, std::nullopt); 
  }

  /**
   * @brief Sends a PPM error negative acknowledgment message.
   *
   * @param cmd_meta Command metadata from the PDCC message
   * @param detail Error detail message
   */
  void Nack(const nlohmann::json& cmd_meta, const std::string& detail) {
    send("error", "aag-nack", cmd_meta, detail);
  }

 private:
  /**
   * @brief Internal method to send PPM messages.
   *
   * Constructs and sends PPM messages with the specified type and event.
   *
   * @param type Message type (info, success, error)
   * @param event Event identifier
   * @param cmd_meta Command metadata
   * @param detail Optional error detail
   */
  void send(const std::string& type, const std::string& event,
            const nlohmann::json& cmd_meta,
            std::optional<std::string> detail);

  PPMReporter& reporter_;  ///< Reference to PPM reporter for message sending
  PpmContext ctx_;         ///< PPM context information
};

#endif  // PPM_EMITTER_H_
