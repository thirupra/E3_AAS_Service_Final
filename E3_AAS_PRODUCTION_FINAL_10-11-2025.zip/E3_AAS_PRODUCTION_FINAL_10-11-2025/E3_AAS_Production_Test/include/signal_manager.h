/**
 * @file SignalManager.h
 * @brief Signal handler manager to replace global signal handling variables.
 * 
 * This singleton replaces the global signal handling variables with a 
 * proper encapsulated solution that manages graceful shutdown.
 * 
 * @author Code Refactoring Team
 * @date 2025-11-06
 */

#pragma once

#include <condition_variable>
#include <mutex>
#include <csignal>

// Forward declarations
class CertificateModule;
class StatusFeedbackModule;

/**
 * @brief Singleton class to manage signal handling without global variables.
 */
class SignalManager {
private:
    static SignalManager* instance_;
    
    std::condition_variable exitCv_;
    std::mutex exitMtx_;
    CertificateModule* certModule_ = nullptr;
    StatusFeedbackModule* statusModule_ = nullptr;
    
    // Private constructor for singleton
    SignalManager() = default;
    
    // Static signal handler that delegates to instance
    static void SignalHandler(int signum);
    
    // Instance method to handle signals
    void HandleSignal(int signum);

public:
    /**
     * @brief Get the singleton instance.
     * @return Reference to the SignalManager instance
     */
    static SignalManager& GetInstance();
    
    /**
     * @brief Set the certificate module for shutdown coordination.
     * @param cert Pointer to CertificateModule
     */
    void SetCertModule(CertificateModule* cert);
    
    /**
     * @brief Set the status module for shutdown coordination.
     * @param status Pointer to StatusFeedbackModule
     */
    void SetStatusModule(StatusFeedbackModule* status);
    
    /**
     * @brief Install signal handlers for SIGINT and SIGTERM.
     */
    void InstallHandlers();
    
    /**
     * @brief Wait for exit signal (blocking call).
     */
    void WaitForExit();
    
    /**
     * @brief Trigger exit condition (for programmatic shutdown).
     */
    void TriggerExit();
    
    // Delete copy constructor and assignment operator
    SignalManager(const SignalManager&) = delete;
    SignalManager& operator=(const SignalManager&) = delete;
};