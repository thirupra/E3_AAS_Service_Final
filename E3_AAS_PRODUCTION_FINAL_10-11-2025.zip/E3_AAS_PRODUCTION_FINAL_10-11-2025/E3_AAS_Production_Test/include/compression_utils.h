#pragma once
#include <string>
#include <cstddef>
#include <cstdint>

namespace CompressionUtils {
    // gzip-compress input; returns empty string on failure.
    std::string GzipCompress(const std::string& input);

    // Decompress gzip data from raw bytes; throws std::runtime_error on failure.
    std::string DecompressGzip(const uint8_t* data, size_t length);
}