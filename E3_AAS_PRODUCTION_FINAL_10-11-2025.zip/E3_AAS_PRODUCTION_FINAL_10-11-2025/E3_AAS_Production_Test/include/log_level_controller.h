/**
 * @file LogLevelController.h
 * @brief Runtime log level control for production debugging.
 * @author Chetana Srinivas
 * @date 2025
 */

#ifndef LOG_LEVEL_CONTROLLER_H_
#define LOG_LEVEL_CONTROLLER_H_

#include "log_manager.h"
#include <mutex>

/**
 * @brief Controller for runtime log level changes without service restart.
 * 
 * Provides signal-based and programmatic control over log levels
 * for production debugging scenarios.
 */
class LogLevelController {
public:
    /**
     * @brief Gets the singleton instance.
     * @return Reference to LogLevelController instance
     */
    static LogLevelController& GetInstance();
    
    /**
     * @brief Initializes signal handlers for runtime log level control.
     * 
     * Sets up the following signal handlers:
     * - SIGUSR1: Enable DEBUG logging
     * - SIGUSR2: Enable INFO logging  
     * - SIGUSR3: Enable WARNING logging
     * - SIGUSR4: Enable ERROR logging
     */
    void Initialize();
    
    /**
     * @brief Sets the log level programmatically.
     * @param level The log level to set
     */
    void SetLogLevel(LogLevel level);
    
    /**
     * @brief Gets the current log level.
     * @return Current log level
     */
    LogLevel GetLogLevel() const;
    
    // Disable copy constructor and assignment operator
    LogLevelController(const LogLevelController&) = delete;
    LogLevelController& operator=(const LogLevelController&) = delete;

private:
    /**
     * @brief Private constructor for singleton pattern.
     */
    LogLevelController() = default;
    
    /**
     * @brief Signal handler for runtime log level changes.
     * @param signum Signal number received
     */
    static void SignalHandler(int signum);
    
    mutable std::mutex mutex_;  ///< Mutex for thread safety
};

#endif  // LOG_LEVEL_CONTROLLER_H_
