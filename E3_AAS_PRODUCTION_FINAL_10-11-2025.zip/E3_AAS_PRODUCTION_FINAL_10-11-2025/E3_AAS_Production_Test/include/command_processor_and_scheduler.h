#ifndef COMMAND_PROCESSOR_AND_SCHEDULER_H_
#define COMMAND_PROCESSOR_AND_SCHEDULER_H_

#include "announcement_job.h"
#include "config_settings.h"
#include "pdcc_priority_queue_manager.h"
#include "elisa3_manager.h"
#include "ppm_reporter.h"
#include <array>
#include <condition_variable>
#include <deque>
#include <mutex>
#include <thread>
#include <unordered_map>
#include <unordered_set>

/**
 * @file CommandProcessorAndScheduler.h
 * @brief Orchestrates announcement processing and scheduling with priority-based job management.
 * 
 * This class implements a two-phase processing system:
 * 1. AnnouncementProcessor (producer): Periodically wakes up to drain the PDCC queue
 *    and distribute jobs into 9 priority bins based on their priority levels.
 * 2. Scheduler (consumer): On signal, picks the highest priority available job for
 *    a free channel, sends it to ELISA3, and waits for acknowledgment.
 * 
 * The system enforces per-destination serialization to prevent conflicts and
 * implements timeout handling for ELISA3 responses. ELISA ACK/NACK responses
 * are mapped to appropriate PPM aag-ack/aag-nack messages.
 */

/**
 * @brief Main orchestrator for announcement processing and scheduling.
 * 
 * Manages the complete lifecycle of announcement jobs from queue processing
 * through ELISA3 device communication, with priority-based scheduling and
 * timeout handling.
 */
class CommandProcessorAndScheduler {
 public:
  /**
   * @brief Function type for getting current system time.
   * 
   * Used for time-based operations and testing with mock time sources.
   */
  using NowFn = std::function<std::chrono::system_clock::time_point()>;

  /**
   * @brief Function type for emitting PPM messages.
   * 
   * Called when jobs complete (successfully or with errors) to send
   * appropriate PPM status messages.
   */
  //using PpmEmitFn = std::function<void(const AnnouncementJob&, bool success, const std::string& detail)>;
  // In your header file (likely CommandProcessorAndScheduler.h)
  using PpmEmitFn = std::function<void(const std::string& status, const std::string& event, const AnnouncementJob& job, const std::string& detail)>;

  /**
   * @brief Function type for logging messages.
   * 
   * Used for debug and diagnostic logging throughout the processing pipeline.
   */
  using LogFn = std::function<void(const std::string&)>;

  /**
   * @brief PPM metadata for publishing ack/nack messages.
   */
  struct PpmMeta {
    std::string announcement_id;
    std::string device_command_id;
    std::string channel_address;
    int priority;
    int sequence_no;
  };

  /**
   * @brief Constructs a CommandProcessorAndScheduler instance.
   * 
   * @param cfg Configuration settings for the scheduler
   * @param pdcc_queue Pointer to the PDCC priority queue manager
   * @param elisa Pointer to the ELISA3 manager for device communication
   * @param ppm_emit Callback function for emitting PPM messages
   * @param now Function for getting current time (defaults to system clock)
   * @param log Function for logging messages (defaults to no-op)
   */
  CommandProcessorAndScheduler(const Config& cfg,
                               PDCCPriorityQueueManager* pdcc_queue,
                               ELISA3Manager* elisa,
                               PpmEmitFn ppm_emit,
                               NowFn now = []{ return std::chrono::system_clock::now(); },
                               LogFn log = [](const std::string&){});
  
  /**
   * @brief Destructor that ensures clean shutdown.
   */
  ~CommandProcessorAndScheduler();

  // Disable copy constructor and assignment operator
  CommandProcessorAndScheduler(const CommandProcessorAndScheduler&) = delete;
  CommandProcessorAndScheduler& operator=(const CommandProcessorAndScheduler&) = delete;

  /**
   * @brief Starts the announcement processor and scheduler threads.
   * 
   * Initializes the background processing threads and begins job processing.
   */
  void Start();

  /**
   * @brief Stops the announcement processor and scheduler threads.
   * 
   * Gracefully shuts down all background processing and cleans up resources.
   */
  void Stop();

  /**
   * @brief External nudge to wake up processing threads.
   * 
   * Called when new ANNOUT commands arrive or ANNDEL commands occur
   * to immediately process new jobs or handle cancellations.
   */
  void Nudge();
 private:
  /**
   * @brief Main loop for the announcement processor thread.
   * 
   * Periodically wakes up to check for due jobs in the PDCC queue,
   * processes them, and distributes them into priority bins.
   */
  void AnnouncementProcessorLoop();

  /**
   * @brief Main loop for the scheduler thread.
   * 
   * Continuously monitors priority bins for available jobs and
   * dispatches them to ELISA3 devices when channels are free.
   */
  void SchedulerLoop();

  /**
   * @brief Handles ELISA3 acknowledgment responses.
   * 
   * Processes incoming ACK/NACK responses from ELISA3 devices
   * and completes the corresponding announcement jobs.
   * 
   * @param ack The ELISA3 acknowledgment response
   */
  void OnElisaAck(const ElisaAck& ack);

  /**
   * @brief Distributes due jobs into priority bins.
   * 
   * Takes a list of due jobs and places them into the appropriate
   * priority bins based on their priority levels (1-9).
   * 
   * @param due Vector of jobs that are ready for processing
   */
  void EnqueueDueIntoPriorityBins(const std::vector<AnnouncementJob>& due);

  /**
   * @brief Builds PPM metadata from an announcement job.
   * 
   * Creates PpmMeta structure with job information for PPM publishing.
   * 
   * @param job The announcement job
   * @return PpmMeta structure with job metadata
   */
  PpmMeta BuildPpmMeta(const AnnouncementJob& job);

  /**
   * @brief Picks and dispatches the highest priority available job.
   * 
   * Searches through priority bins (highest to lowest) to find an
   * available job for a free channel and dispatches it to ELISA3.
   * 
   * @return True if a job was dispatched, false if no jobs available
   */
  bool PickAndDispatchHighPriorityJob();

  /**
   * @brief Completes a job with success or failure status.
   * 
   * Finalizes job processing, emits appropriate PPM messages,
   * and cleans up job state.
   * 
   * @param job The job to complete
   * @param success Whether the job completed successfully
   * @param detail Additional details about the completion
   */
  void CompleteJob(const AnnouncementJob& job, bool success, const std::string& detail);

  Config cfg_;                          ///< Configuration settings
  PDCCPriorityQueueManager* pdcc_queue_; ///< Pointer to PDCC queue manager
  ELISA3Manager* elisa_;                ///< Pointer to ELISA3 manager
  PpmEmitFn ppm_emit_;                  ///< PPM message emission callback
  NowFn now_;                          ///< Current time function
  LogFn log_;                          ///< Logging function

  std::atomic<bool> stop_{false};       ///< Stop flag for graceful shutdown

  // Producer (AnnouncementProcessor) thread management
  std::thread ann_thread_;              ///< Announcement processor thread
  std::mutex ann_mu_;                   ///< Mutex for announcement processor synchronization
  std::condition_variable ann_cv_;      ///< Condition variable for announcement processor

  // Consumer (Scheduler) thread management
  std::thread sch_thread_;              ///< Scheduler thread
  std::mutex sch_mu_;                   ///< Mutex for scheduler synchronization
  std::condition_variable sch_cv_;     ///< Condition variable for scheduler

  // Priority-based job distribution (9 priority levels: 1-9)
  std::array<std::deque<AnnouncementJob>, 10> prio_bins_;  ///< Priority bins for job distribution

  // Channel management for per-destination serialization
  std::unordered_set<std::string> inflight_channels_;     ///< Currently active channels

  /**
   * @brief Tracks what's currently playing per channel for preemption logic.
   */
  struct Inflight {
    std::string device_command_id;  ///< Device command ID of the current job
    int         priority = -1;      ///< Priority of the current job
    std::string channel;            ///< Channel address
    std::string announcement_id;    ///< Announcement ID of the current job
  };

  std::unordered_map<std::string, Inflight> inflight_by_channel_;  ///< Currently inflight jobs per channel

  /**
   * @brief Structure representing a job waiting for ELISA3 response.
   * 
   * Tracks jobs that have been dispatched to ELISA3 and are waiting
   * for acknowledgment, including timeout deadline information.
   */
  struct Waiter { 
    AnnouncementJob job;                                    ///< The job being processed
    std::chrono::system_clock::time_point deadline;        ///< Timeout deadline
    // PPM metadata blob we use for PublishAck/PublishNack:
    PpmMeta     meta;
    bool        preempted = false; 
  };
  std::unordered_map<std::string, Waiter> waiters_;       ///< Jobs waiting for ELISA3 responses

  PPMReporter* ppm_reporter_ = nullptr;  ///< PPM reporter (not owned by this class)
};

#endif  // COMMAND_PROCESSOR_AND_SCHEDULER_H_

