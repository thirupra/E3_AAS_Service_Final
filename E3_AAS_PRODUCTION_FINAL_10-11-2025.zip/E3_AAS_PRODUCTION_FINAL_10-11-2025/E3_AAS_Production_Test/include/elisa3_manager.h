#ifndef ELISA3_MANAGER_H_
#define ELISA3_MANAGER_H_

#include "announcement_job.h"
#include "config_settings.h"
#include <atomic>
#include <cstdint>
#include <string>
#include <thread>
#include <vector>

/**
 * @file ELISA3Manager.h
 * @brief System V message queue communication manager for ELISA3 devices.
 * 
 * This class handles bidirectional communication with ELISA3 devices using
 * System V message queues. It implements a two-part message protocol:
 * 1. A size header message containing the payload size in bytes
 * 2. A text payload message containing control map and content information
 * 
 * The manager supports two types of responses from ELISA3:
 * - ACK/NACK replies for specific ANNOUT commands (non-empty magic field)
 * - Spontaneous TDM status events (empty magic field)
 * 
 * The class provides separate callback mechanisms for different response types:
 * - AckCallback: For ANNOUT command responses (used by CommandProcessorAndScheduler)
 * - StatusCallback: For TDM status events (used by StatusFeedbackModule)
 * 
 * A background listener thread continuously monitors for incoming messages
 * and dispatches them to the appropriate callbacks.
 */

/**
 * @brief Structure representing an ACK/NACK reply from ELISA3.
 * 
 * Contains the parsed response data from ELISA3 devices for ANNOUT commands.
 * The device_command_id field identifies which command the response refers to.
 */
struct ElisaAck {
  std::string device_command_id;          ///< Device command ID ("magic" in wire format)
  unsigned long code{0};                  ///< Primary ELISA response code
  
  // Additional fields for compatibility and future extensibility
  std::vector<unsigned long> codes;       ///< Multiple codes if present (first mirrors `code`)
  std::string par2;                       ///< Optional parameter2 (e.g., channel address)
};

/**
 * @brief Structure representing spontaneous TDM status from ELISA3.
 * 
 * Contains status information from ELISA3 devices that is not tied to
 * a specific command (empty magic field in wire format).
 */
struct TdmStatus {
  unsigned long code;                     ///< ELISA numeric status code
  std::string par2;                       ///< Optional parameter2 (e.g., channel address)
};

/**
 * @brief Callback function type for ANNOUT command responses.
 * 
 * Called when ELISA3 sends ACK/NACK responses for specific announcement commands.
 */
using AckCallback = std::function<void(const ElisaAck&)>;

/**
 * @brief Callback function type for TDM status events.
 * 
 * Called when ELISA3 sends spontaneous status updates or TDM events.
 */
using StatusCallback = std::function<void(const TdmStatus&)>;

/**
 * @brief Callback function type for PPM error messages.
 * 
 * Called when ELISA3 sends error responses that need to be forwarded as PPM aag-nack.
 */
using PpmErrorCallback = std::function<void(const std::string& device_command_id, const std::string& error_detail)>;

/**
 * @brief Manages System V message queue communication with ELISA3 devices.
 * 
 * Handles the complete lifecycle of communication with ELISA3 devices,
 * including sending announcement requests and processing responses.
 * Uses a background thread for continuous message monitoring.
 */
class ELISA3Manager {
 public:
  /**
   * @brief Constructs an ELISA3Manager instance.
   * 
   * Initializes the manager with the provided configuration and sets up
   * the System V message queue connection.
   * 
   * @param cfg Configuration settings including IPC parameters
   */
  explicit ELISA3Manager(const Config& cfg);
  
  /**
   * @brief Destructor that ensures clean shutdown.
   * 
   * Automatically stops the listener thread and cleans up resources.
   */
  ~ELISA3Manager();

  // Disable copy constructor and assignment operator
  ELISA3Manager(const ELISA3Manager&) = delete;
  ELISA3Manager& operator=(const ELISA3Manager&) = delete;

  /**
   * @brief Starts the background listener thread.
   * 
   * Idempotent operation that starts the message monitoring thread
   * if it's not already running.
   */
  void Start();

  /**
   * @brief Stops the background listener thread.
   * 
   * Signals shutdown and waits for the listener thread to complete.
   * This method blocks until the thread has finished.
   */
  void Stop();

  /**
   * @brief Registers callback for ANNOUT command responses.
   * 
   * Sets the callback function that will be invoked when ELISA3
   * sends ACK/NACK responses for announcement commands.
   * 
   * @param cb Callback function for ANNOUT responses
   */
  void SetAckCallback(AckCallback cb);

  /**
   * @brief Registers callback for TDM status events.
   * 
   * Sets the callback function that will be invoked when ELISA3
   * sends spontaneous status updates or TDM events.
   * 
   * @param cb Callback function for TDM status events
   */
  void SetStatusCallback(StatusCallback cb);

  /**
   * @brief Sets the callback function for PPM error messages.
   * 
   * Sets the callback function that will be invoked when ELISA3
   * sends error responses that need to be forwarded as PPM aag-nack.
   * 
   * @param cb Callback function for PPM error messages
   */
  void SetPpmErrorCallback(PpmErrorCallback cb);

  /**
   * @brief Sends an ANNOUT request to ELISA3.
   * 
   * Builds and sends an announcement request to the ELISA3 device
   * using the provided job information.
   * 
   * @param job The announcement job to send
   * @return True if the request was successfully queued, false otherwise
   */
  bool SendPlayRequest(const AnnouncementJob& job);

  /**
   * @brief Sends a pre-built SES/ELISA payload.
   * 
   * Sends a raw payload string to ELISA3 (useful for testing and tools).
   * The payload should be in the correct SES/ELISA format.
   * 
   * @param ses_payload The pre-built payload string
   * @return True if the payload was successfully queued, false otherwise
   */
  bool SendPlayRequest(const std::string& ses_payload);

 private:
  /**
   * @brief Opens the System V message queue.
   * 
   * Establishes connection to the System V message queue using
   * the configured IPC parameters.
   * 
   * @return True if the queue was successfully opened, false otherwise
   */
  bool OpenQueues();

  /**
   * @brief Sends a size header message to ELISA3.
   * 
   * Sends the first part of the two-part message protocol,
   * indicating the size of the payload that will follow.
   * 
   * @param payload_size Size of the payload in bytes
   * @return True if the header was successfully sent, false otherwise
   */
  bool SendSizeHeader(unsigned long payload_size);

  /**
   * @brief Sends a payload message to ELISA3.
   * 
   * Sends the second part of the two-part message protocol,
   * containing the actual control map and content data.
   * 
   * @param payload The payload string to send
   * @return True if the payload was successfully sent, false otherwise
   */
  bool SendPayload(const std::string& payload);

  /**
   * @brief Receives a reply message from ELISA3.
   * 
   * Waits for and receives a response message from ELISA3.
   * This method blocks until a message is available or timeout occurs.
   * 
   * @param out_payload Output parameter for the received payload
   * @return True if a message was successfully received, false otherwise
   */
  bool ReceiveReply(std::string* out_payload);

  /**
   * @brief Builds the outgoing payload for an announcement job.
   * 
   * Constructs the SES/ELISA payload string from an AnnouncementJob,
   * following the exact format required by the ELISA3 protocol.
   * 
   * @param job The announcement job to build payload for
   * @return The formatted payload string
   */
  std::string BuildOutgoingPayload(const AnnouncementJob& job) const;

  /**
   * @brief Dispatches incoming payload to appropriate callbacks.
   * 
   * Parses the received payload and determines whether it's an ACK/NACK
   * response or a TDM status event, then calls the appropriate callback.
   * 
   * @param payload The received payload string
   */
  void DispatchIncoming(const std::string& payload);

  /**
   * @brief Main loop for the background listener thread.
   * 
   * Continuously monitors the message queue for incoming messages
   * and processes them by dispatching to callbacks.
   */
  void ListenerLoop();

  Config cfg_;                    ///< Configuration settings
  int qid_ = -1;                  ///< System V message queue identifier
  std::atomic<bool> stop_{false}; ///< Stop flag for graceful shutdown
  std::thread listener_;           ///< Background listener thread

  // Callback functions (may be null)
  AckCallback ack_cb_;            ///< Callback for ANNOUT responses
  StatusCallback status_cb_;      ///< Callback for TDM status events
  PpmErrorCallback ppm_error_cb_; ///< Callback for PPM error messages
};

#endif  // ELISA3_MANAGER_H_
