#ifndef PDCC_PRIORITY_QUEUE_MANAGER_H_
#define PDCC_PRIORITY_QUEUE_MANAGER_H_

#include "announcement_job.h"
#include "config_settings.h"
#include <chrono>
#include <condition_variable>
#include <mutex>
#include <optional>
#include <queue>
#include <unordered_map>
#include <unordered_set>
#include <vector>


/**
 * @file PDCCPriorityQueueManager.h
 * @brief Priority queue manager for PDCC announcement jobs.
 *
 * Manages a min-heap ordered by (requested_output_time asc, priority desc, sequence_no asc)
 * with support for ANNDEL cancellation and deduplication. Computes the next wakeup time
 * for the AnnouncementProcessor thread and validates job expiry.
 */

/**
 * @brief Lightweight metadata stored in the download state registry.
 *
 * Tracks the current state of audio file downloads and provides
 * the local file path when download is successful.
 */
struct DownloadStatus {
  DownloadState state = DownloadState::kQueued;  ///< Current download state
  std::string local_file_path;                   ///< Local file path (non-empty only if state == kSuccess)
};


/**
 * @brief Thread-safe priority queue manager for PDCC ANNOUT jobs.
 *
 * Manages a priority queue of announcement jobs ordered by playout time and priority.
 * Provides thread-safe operations for adding, removing, and querying jobs.
 * Supports job cancellation and download state tracking.
 */
class PDCCPriorityQueueManager {
 public:
  /**
   * @brief Constructs a PDCCPriorityQueueManager instance.
   *
   * @param cfg Configuration settings for the queue manager
   */
  explicit PDCCPriorityQueueManager(const Config& cfg);

  /**
   * @brief Pushes a validated ANNOUT job into the priority queue.
   *
   * Adds a new announcement job to the queue and returns the next
   * wakeup time for the scheduler.
   *
   * @param job The announcement job to add to the queue
   * @return Next wakeup time point after insertion, or empty if queue is empty
   */
  std::optional<std::chrono::system_clock::time_point>
  Push(const AnnouncementJob& job);

  /**
   * @brief Processes an ANNDEL command by canceling matching jobs.
   *
   * Removes pending jobs that match the announcement ID and optionally
   * the channel address from the priority queue.
   *
   * @param announcement_id The announcement ID to cancel
   * @param channel_address Optional channel address filter (empty means all channels)
   * @return Number of jobs canceled
   */
  size_t CancelByAnnouncement(const std::string& announcement_id,
                              const std::string& channel_address = "");

  /**
   * @brief Pops all jobs that are due at or before the specified time.
   *
   * Retrieves all jobs that are ready for processing (due time reached)
   * and not expired, removing them from the priority queue.
   *
   * @param now Current time point for comparison
   * @return Vector of due jobs (unsorted)
   */
  std::vector<AnnouncementJob> PopDue(std::chrono::system_clock::time_point now);

  /**
   * @brief Registers initial state for a newly seen job.
   *
   * Call this before Push() so the scheduler can see the state immediately.
   * This ensures the download state is tracked from the beginning.
   *
   * @param job The announcement job to register
   */
  void RegisterJobState(const AnnouncementJob& job);

  /**
   * @brief Updates the download state and optional path for an existing job.
   *
   * Thread-safe method for updating job download status.
   * Safe to call from downloader callback.
   *
   * @param announcement_id The announcement ID to update
   * @param state New download state
   * @param local_file_path Optional local file path (for successful downloads)
   * @return true if a matching job was found and updated, false otherwise
   */
  bool UpdateDownloadStatus(const std::string& announcement_id,
                            DownloadState state,
                            const std::string& local_file_path = "");
  /**
   * @brief Updates audio download status with logging.
   *
   * Provides a callback interface for logging audio download status updates.
   * This method handles the conversion from string status to enum state.
   *
   * @param announcement_id The unique ID of the announcement
   * @param status The download status string (e.g., "completed", "failed")
   * @param file_path The path to the downloaded audio file (empty on failure)
   */
  void UpdateAudioStatus(const std::string& announcement_id,
                         const std::string& status,
                         const std::string& file_path);

  /**
   * @brief Queries the current download state for a job.
   *
   * Thread-safe method to retrieve the current download status.
   * Returns false if the job is not registered.
   *
   * @param announcement_id The announcement ID to query
   * @param out Output parameter for the download status
   * @return true if job found and status retrieved, false otherwise
   */
  bool GetDownloadStatus(const std::string& announcement_id,
                         DownloadStatus* out) const;

  /**
   * @brief Computes the next wakeup time point.
   *
   * Returns the earliest requested_output_time in the heap,
   * which is when the scheduler should next check for due jobs.
   *
   * @return Next wakeup time point, or empty if queue is empty
   */
  std::optional<std::chrono::system_clock::time_point> NextWakeup() const;

  /**
   * @brief Gets the current size of the priority queue.
   *
   * @return Number of jobs currently in the queue
   */
  size_t Size() const;

 private:
  /**
   * @brief Internal node structure for the priority queue.
   *
   * Wraps an AnnouncementJob for storage in the priority queue.
   */
  struct Node {
    AnnouncementJob job;  ///< The announcement job data
  };

  /**
   * @brief Comparison functor for the priority queue.
   *
   * Defines the ordering: requested_output_time asc, priority desc, sequence_no asc.
   */
  struct Cmp {
    bool operator()(const Node& a, const Node& b) const;
  };

  Config cfg_;                                                      ///< Configuration settings
  mutable std::mutex mu_;                                          ///< Mutex for thread safety
  std::priority_queue<Node, std::vector<Node>, Cmp> heap_;         ///< Priority queue of jobs
  std::unordered_multimap<std::string, std::string> id_to_channels_; ///< ID to channels mapping
  std::unordered_set<std::string> dedupe_keys_;                    ///< Deduplication keys

  // Download state registry (authoritative)
  mutable std::mutex state_mu_;                                    ///< Mutex for state registry
  std::unordered_map<std::string, DownloadStatus> state_by_ann_;  ///< State by announcement ID

  /**
   * @brief Private version of NextWakeup that assumes mutex is already held.
   *
   * @return Next wakeup time point, or empty if queue is empty
   */
  std::optional<std::chrono::system_clock::time_point> NextWakeupLocked() const;
};

#endif  // PDCC_PRIORITY_QUEUE_MANAGER_H_

