/**
 * @class PPMReporter
 * @brief Singleton AMQP publisher for PPM messages, extending BrokerBase functionality.
 *
 * Specification: {S_106} PPM Message Publishing via AMQP
 *
 * Responsibilities:
 *  - Manage AMQP connection for publishing.
 *  - Provide thread-safe singleton access.
 *  - Publish JSON messages to configured exchange and routing key.
 *  - Maintain connection lifecycle (connect, disconnect, init, deinit).
 *
 * Author: Thirupathi Rao
 * Date: 2025-09-09
 */
#pragma once

#include "broker_base.h"

class PPMReporter : public BrokerBase {
public:
    /// Returns the singleton instance of PPMReporter.
    static PPMReporter* GetInstance();

    static PPMReporter* GetInstance(CertificateModule* certModule);


    /// Destroys the singleton instance.
    static void DestroyInstance();

    /// Connects to the configured AMQP broker.
    bool Connect() override;

    /// Publishes a message to a specified exchange.  
    bool Publish(const std::string& exchange, const std::string& routing_key, const std::string& message) override;

    /// Disconnects cleanly from the AMQP broker.
    void Disconnect() override;

    /// Initializes the reporter by establishing connection.
    bool Init() override;

    /// Deinitializes the reporter by disconnecting.
    void Deinit() override;

    /// Returns the AMQP queue name used for publishing.
    const std::string& GetQueueName() const { return config_.queue_name; }

    /// Destructor cleans up resources.
    ~PPMReporter();

    // Prevent copying and assignment.
    PPMReporter(const PPMReporter&) = delete;

    PPMReporter& operator=(const PPMReporter&) = delete;

    /**
     * @brief Publish a PPM message using a dynamic routing key built from type and event.
     * @param type The message type (e.g., "SUCCESS", "ERROR")
     * @param event The event name (e.g., "aag-ack", "start-msg")
     * @param message The JSON message payload to publish
     * @return true if message was published successfully, false otherwise
     */
    bool PublishPPM(const std::string& type, const std::string& event, const std::string& message);

private:
    /// Private constructor to enforce singleton.
    explicit PPMReporter(CertificateModule* certModule = nullptr);

    ///< Singleton instance pointer.
    static PPMReporter* instance_;

    ///< Connection status flag.
    bool connected_;

    /**
     * @brief Build a dynamic routing key using base routing_key from config and the message type/event.
     * @param type The message type (e.g., "SUCCESS", "ERROR")
     * @param event The event name (e.g., "aag-ack", "start-msg")
     * @return Dynamic routing key in format "<base>.<type>.<event>" (all lowercase)
     */
    std::string BuildDynamicRoutingKey(const std::string& type, const std::string& event);
    
    
};
