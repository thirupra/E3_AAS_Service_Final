/**
 * @class AMQPHandler
 * @brief Handles AMQP connectivity, message consumption, JSON message processing,
 * and coordinates with DownloadManager and PPMReporter.
 *
 * This class is a **singleton** responsible for managing the AMQP message bus
 * client. It provides a robust and resilient solution for consuming messages from
 * a RabbitMQ broker in a dedicated, multi-threaded environment.
 *
 * Spec_number: {S_102} AMQP Messaging and PDCC Processing
 *
 * Features:
 * - **Singleton Pattern**: Ensures a single instance is available application-wide.
 * - **Connection Management**: Connects to the broker with a robust retry mechanism.
 * - **Message Consumption**: Pulls messages from a configured queue in a continuous loop.
 * - **Gzip Decompression**: Automatically decompresses messages if they are
 * encoded with gzip, inspecting the `content_encoding` property.
 * - **JSON Processing**: Parses and validates incoming JSON messages, handling different
 * message types (e.g., commands, keep-alives) and dispatching tasks accordingly.
 * - **PPM Reporting**: Sends PPM (Physical Device Command) acknowledgment (info)
 * and negative acknowledgment (error) messages back to the broker.
 * - **Task Delegation**: Submits audio download jobs to the `DownloadManager`.
 * - **Resilience**: Monitors message receipt with a dedicated watchdog thread
 * for automatic reconnects, ensuring long-term stability.
 *
 * @author Thirupathi Rao
 * @date 2025-09-09
 */
#pragma once
#include <atomic>
#include <thread>
#include <nlohmann/json.hpp>
#include "broker_base.h"
#include "download_manager.h"
#include <mutex>
#include <condition_variable>
#include <unordered_set>
#include "certificate_module.h"
#include "aas_app.h"
#include "ppm_emitter.h"
#include "pdcc_priority_queue_manager.h"

// REMOVED: extern std::mutex log_mutex;
// Use LogManager::GetInstance() for thread-safe logging instead

using json = nlohmann::json;

class AMQPHandler : public BrokerBase {
public:
    /// @brief Gets the singleton instance, creating it if needed.
    /// @return A pointer to the AMQPHandler instance.
    static AMQPHandler* GetInstance();

    /// @brief Destroys the singleton instance and nullifies the pointer.
    static void DestroyInstance();

    /// @brief Connects to the AMQP broker using base class logic.
    /// @return `true` if the connection succeeds, `false` otherwise.
    bool Connect() override;

    /// @brief Disconnects from the broker and stops all associated threads.
    void Disconnect() override;

    /// @brief Initializes the handler by connecting to the broker with retry logic and starting threads.
    /// @return `true` if initialization is successful, `false` otherwise.
    bool Init() override;

    /// @brief Deinitializes the handler, which is equivalent to disconnecting.
    void Deinit() override;

    /// @brief Subscribes to a specified queue and configures message prefetch.
    /// @param topic The name of the queue to subscribe to.
    /// @param callback The function to call for each received message.
    /// @return `true` if subscription succeeds, `false` otherwise.
    bool Subscribe(const std::string& topic, const MessageCallback& callback) override;

    /// @brief Sets the custom callback function for processing messages.
    /// @param cb The callback function to handle received messages.
    void SetMessageCallback(const MessageCallback& callback) override;

    /// @brief Publishes a PPM info (acknowledgment) message back to the broker.
    /// @param subscribe_message The original JSON message string that is being acknowledged.
    void ProcessAmqpCommands(const std::string& subscribe_message);

    /// @brief Publishes a PPM info (pdc-received) message for valid messages.
    /// @param subscribe_message The original JSON message string that is being acknowledged.
    void SendPpmInfoMessage(const std::string& subscribe_message);

    /// @brief Publishes a PPM error (NACK) message for invalid or failed messages.
    /// @param msgJson The JSON object containing error details or metadata.
    void SendPpmErrorMessage(const json& msgJson);

    /// @brief Publishes a PPM success (aag-ack) message after successful processing.
    /// @param cmd_meta The command metadata from the original PDCC message.
    void SendPpmSuccessMessage(const nlohmann::json& cmd_meta);

    /// @brief Publishes a PPM error (aag-nack) message after failed processing.
    /// @param cmd_meta The command metadata from the original PDCC message.
    /// @param error_detail The error detail string explaining the failure.
    void SendPpmErrorMessage(const nlohmann::json& cmd_meta, const std::string& error_detail);

    /// @brief Starts the message consumption, watchdog, and reconnect threads.
    void Start();

    /// @brief Gracefully stops the worker threads.
    /// @param fullShutdown If `true`, stops all threads including watchdog and reconnect loops.
    void Stop(bool fullShutdown = true);

    /// @brief Requests a full shutdown of the handler and its threads.
    void RequestShutdown();

    /// @brief Handles a received message from the `ConsumeLoop` thread.
    /// @param subscribe_message The raw message string.
    void ReceivedMessage(const std::string& subscribe_message);

    /// @brief Processes a parsed JSON message, handling validation and task delegation.
    /// @param process_message The JSON string to process.
    void ProcessMessage(const std::string& process_message);

    /// @brief Assigns a `DownloadManager` instance for submitting audio download jobs.
    /// @param dm A pointer to the `DownloadManager` instance.
    void SetDownloadManager(DownloadManager* dm);

    void SetPPMEmitter(PPMEmitter* e);
    /// @brief Sets the AASApp callback for processing commands.
    /// @param aas_app A pointer to the AASApp instance.
    void SetAASApp(AASApp* aas_app);
    
    /// @brief Destructor, ensures threads are stopped and resources are cleaned up.
    ~AMQPHandler();

    // Prevent copying and assignment to enforce the singleton pattern.
    AMQPHandler(const AMQPHandler&) = delete;
    AMQPHandler& operator=(const AMQPHandler&) = delete;

    /// @brief Decompresses gzip compressed data.
    /// @param data A pointer to the compressed data buffer.
    /// @param length The length of the compressed data.
    /// @return The decompressed string.
    static std::string DecompressGzip(const uint8_t* data, size_t length);

    /// @brief Generates a unique message ID for deduplication.
    /// @param message The JSON message to generate ID from.
    /// @return A unique string identifier for the message.
    static std::string GenerateMessageId(const nlohmann::json& message);

    /// @brief Checks if a message is a duplicate and handles it appropriately.
    /// @param message_id The unique message identifier.
    /// @return true if the message is a duplicate, false otherwise.
    bool IsDuplicateMessage(const std::string& message_id);

    /// @brief Adds a message ID to the processed set for deduplication.
    /// @param message_id The unique message identifier to add.
    void MarkMessageAsProcessed(const std::string& message_id);

    /// @brief Gets the singleton instance, creating it if needed.
    /// @param config The BrokerConfig struct with connection details.
    /// @param certModule Pointer to a CertificateModule for dynamic certificate management.
    /// @return A pointer to the AMQPHandler instance.
    //static AMQPHandler* GetInstance(BrokerConfig config, CertificateModule* certModule);
    static AMQPHandler* GetInstance(const BrokerConfig& config, CertificateModule* certModule, PDCCPriorityQueueManager* pdccQueueManager);

    // Utility: ISO8601 parse
    static std::chrono::system_clock::time_point ParseIso8601(const std::string& iso);
    static bool IsExpired(const std::string& iso);

    PDCCPriorityQueueManager* pdccQueueManager_ = nullptr; ///< Manages the priority queue for incoming PDCC commands.
 

protected:
    /// @brief Private constructor to enforce the singleton pattern.
    explicit AMQPHandler();

    AMQPHandler(const BrokerConfig& config, CertificateModule* certModule, PDCCPriorityQueueManager* pdccQueueManager);

    /// @brief The main message consumption loop, runs in a separate thread.
    void ConsumeLoop();

    /// @brief Attempts to connect to the broker with retry and exponential backoff.
    /// @param maxRetries The maximum number of connection attempts.
    /// @param delaySeconds The base delay in seconds between retries.
    /// @return `true` if connection succeeds, `false` otherwise.
    bool ConnectWithRetry(int maxRetries, int delaySeconds);

    /// @brief Sets up channel-specific details like prefetch and subscription after connection.
    /// @return `true` if setup succeeds, `false` otherwise.
    bool PostConnectSetup() override;

    static AMQPHandler* instance_;          ///< The static pointer to the singleton instance.
    std::atomic<bool> running_;             ///< Atomic flag to control the `ConsumeLoop` thread's lifetime.
    std::thread consumer_thread_;           ///< The thread running the message consumption loop.

    DownloadManager* downloadManager_ = nullptr; ///< Pointer to a DownloadManager instance for delegating tasks.

    PPMEmitter* ppm_ = nullptr;

    AASApp* aas_app_ = nullptr; ///< Pointer to AASApp instance for processing commands.

    // Watchdog related members
    std::atomic<std::chrono::steady_clock::time_point> last_message_time_; ///< Timestamp of the last message received, used by the watchdog.
    std::thread watch_thread_;              ///< The dedicated thread for the watchdog loop.
    std::atomic<bool> watching_;            ///< Atomic flag to control the watchdog and reconnect loops.
    void WatchdogLoop();                    ///< The watchdog thread function that monitors for message inactivity.
    void ReconnectHandlerLoop();            ///< The thread function that handles reconnection attempts.

    std::thread reconnect_thread_;                       ///< The thread for the reconnect handler.
    std::atomic<bool> reconnect_requested_{false};        ///< Atomic flag to signal a reconnect is needed.
    std::mutex reconnect_mutex_;                          ///< Mutex for synchronizing with the reconnect thread.
    std::condition_variable reconnect_cv_;                ///< Condition variable to wake the reconnect thread.
    std::mutex start_stop_mutex_;                         ///< Mutex to ensure thread-safe start/stop operations.
    std::mutex log_mutex_;                                ///< Mutex for thread-safe logging within the class.
    CertificateModule* certModule_;                       ///< Pointer to a CertificateModule for dynamic certificate management.
    
    // Deduplication members
    std::unordered_set<std::string> processed_message_ids_; ///< Set of processed message IDs for deduplication
    std::mutex dedup_mutex_;                              ///< Mutex for thread-safe deduplication operations
};
