#ifndef ANNOUNCEMENT_JOB_H_
#define ANNOUNCEMENT_JOB_H_

#pragma once
#include <chrono>
#include <cstdint>
#include <optional>
#include <string>
#include <vector>
#include <unordered_map>

/**
 * @file AnnouncementJob.h
 * @brief Data model for PDCC command -> AAS job lifecycle.
 *
 * Follows PDCC meta/content fields and the ELISA control-map mapping per spec.
 * See: Appendix C mapping (status, magic, ablaufid, prio, ziel, start, stop, intervall, connstatus).
 */

/** @brief Command kinds we care about. */
enum class CommandKind { 
  kAnnOut,    ///< Announcement output command
  kAnnDel,    ///< Announcement delete command  
  kKeepAlive  ///< Keep-alive message
};

/** @brief Download state for the audio asset. */
enum class DownloadState { 
  kQueued,      ///< Job queued for download
  kNotStarted,  ///< Download not yet initiated
  kPending,     ///< Download pending
  kInProgress,  ///< Download in progress
  kError,       ///< Download failed with error
  kSuccess      ///< Download completed successfully
};

/** @brief Result kinds from ELISA. */
enum class ElisaResult {
  kSuccess,      ///< Operation completed successfully
  kNoDevice,     ///< Target device not found
  kNoLine,       ///< Communication line not available
  kDestDef,      ///< Destination definition error
  kDestOccu,     ///< Destination occupied
  kUnknown,      ///< Unknown error condition
  kDeviceFault,  ///< Device hardware fault
  kOther         ///< Other unspecified error
};

/** @brief Parsed and validated PDCC command (ANNOUT/ANNDEL), plus runtime fields. */
struct AnnouncementJob {
  // PDCC command metadata fields
  std::string device_command_id;       ///< Unique device command identifier (magic)
  int priority = 1;                    ///< Priority level (1-9, where 1 is lowest)
  CommandKind command = CommandKind::kAnnOut;  ///< Type of command
  std::string channel_address;         ///< Target channel/device address (ziel)
  std::chrono::system_clock::time_point valid_until;         ///< Command expiration time (stop)
  std::chrono::system_clock::time_point requested_output_time; ///< Scheduled play time (start)
  int64_t sequence_no = 0;            ///< Sequence number for ordering
  std::string announcement_id;         ///< Unique announcement identifier (ablaufid)
  std::string announcement_hash;       ///< Hash of announcement content

  // PDCC profile information (optional)
  std::string profile_text;            ///< Text content of the announcement
  std::string profile_language;       ///< Language code (e.g., "en", "de")

  // Content and file management (supports multiple files per announcement)
  std::vector<std::string> content_urls;      ///< HTTPS URLs to audio files (multiple files supported)
  std::vector<std::string> local_file_paths;  ///< Local file paths after download (parallel to content_urls)
  
  // Backward compatibility helpers
  std::string content_url;             ///< DEPRECATED: Use content_urls instead (kept for compatibility)
  std::string local_file_path;         ///< DEPRECATED: Use local_file_paths instead (kept for compatibility)

  // Runtime bookkeeping
  std::chrono::system_clock::time_point received_time;  ///< When the job was received

  // Download lifecycle management
  DownloadState download_state = DownloadState::kNotStarted;  ///< Current download state
  std::string download_error;          ///< Error details when download_state == kError

  // Processing status flags
  bool download_ok = true;            ///< Set to false if download/integrity failed
  bool cancelled = false;             ///< Set to true if job was cancelled

  /**
   * @brief Generates a unique deduplication key for this job.
   * 
   * Creates a composite key using announcement_id and sequence_no to
   * identify duplicate jobs and prevent redundant processing.
   * 
   * @return Unique string key for deduplication
   */
  std::string DedupeKey() const;

  /**
   * @brief Checks if the job has expired beyond its valid time window.
   * 
   * Determines whether the current time has exceeded the job's valid_until
   * timestamp, indicating the job should no longer be processed.
   * 
   * @param now Current system time point
   * @return True if the job has expired, false otherwise
   */
  bool IsExpired(std::chrono::system_clock::time_point now) const;

  // Multi-file support helper methods
  
  /**
   * @brief Adds a content URL to the announcement (supports multiple files).
   * @param url HTTPS URL to audio file
   */
  void AddContentUrl(const std::string& url) {
    content_urls.push_back(url);
    // Maintain backward compatibility
    if (content_urls.size() == 1) {
      content_url = url;
    }
  }
  
  /**
   * @brief Sets the local file path for a specific content URL index.
   * @param index Index in content_urls vector
   * @param path Local file path after download
   */
  void SetLocalFilePath(size_t index, const std::string& path) {
    if (index >= local_file_paths.size()) {
      local_file_paths.resize(index + 1);
    }
    local_file_paths[index] = path;
    // Maintain backward compatibility
    if (index == 0) {
      local_file_path = path;
    }
  }
  
  /**
   * @brief Gets the number of content files in this announcement.
   * @return Number of audio files
   */
  size_t GetFileCount() const {
    return content_urls.size();
  }
  
  /**
   * @brief Checks if all files have been successfully downloaded.
   * @return True if all files are downloaded, false otherwise
   */
  bool AllFilesDownloaded() const {
    if (content_urls.empty()) return false;
    if (local_file_paths.size() != content_urls.size()) return false;
    
    for (const auto& path : local_file_paths) {
      if (path.empty()) return false;
    }
    return true;
  }
};
inline std::string CommandKindToString(CommandKind cmd) {
    switch (cmd) {
        case CommandKind::kAnnOut:    return "ANNOUT";
        case CommandKind::kAnnDel:    return "ANNDEL";
        case CommandKind::kKeepAlive: return "KEEPALIVE";
        default:                      return "UNKNOWN";
    }
}


#endif  // ANNOUNCEMENT_JOB_H_