#ifndef MESSAGE_VALIDATOR_H
#define MESSAGE_VALIDATOR_H

#include <string>
#include <nlohmann/json.hpp>
#include <chrono>
#include <ctime>

/**
 * @brief Comprehensive message validation for AAS PDCC messages
 * 
 * This class provides validation for all PDCC message requirements including:
 * - Timestamp validation (requestedOutputTime, validUntil)
 * - Priority validation (1-9 range)
 * - Mandatory field validation
 * - Business rule validation
 */
class MessageValidator {
public:
    /**
     * @brief Validation result structure
     */
    struct ValidationResult {
        bool is_valid;
        std::string error_message;
        std::string error_code;
    };

    /**
     * @brief Validate a complete PDCC message
     * @param message The JSON message to validate
     * @return ValidationResult with validation status and error details
     */
    static ValidationResult ValidateMessage(const nlohmann::json& message);

    /**
     * @brief Validate a single command within a PDCC message
     * @param command The command JSON to validate
     * @return ValidationResult with validation status and error details
     */
    static ValidationResult ValidateCommand(const nlohmann::json& command);

    /**
     * @brief Validate timestamp format and values
     * @param timestamp_str ISO timestamp string
     * @param field_name Name of the timestamp field for error reporting
     * @return ValidationResult with validation status and error details
     */
    static ValidationResult ValidateTimestamp(const std::string& timestamp_str, const std::string& field_name);

    /**
     * @brief Validate priority value
     * @param priority Priority value to validate
     * @return ValidationResult with validation status and error details
     */
    static ValidationResult ValidatePriority(int priority);

    /**
     * @brief Validate mandatory fields for ANNOUT command
     * @param cmd_meta Command metadata JSON
     * @return ValidationResult with validation status and error details
     */
    static ValidationResult ValidateAnnoutMandatoryFields(const nlohmann::json& cmd_meta);

    /**
     * @brief Validate mandatory fields for ANNDEL command
     * @param cmd_meta Command metadata JSON
     * @return ValidationResult with validation status and error details
     */
    static ValidationResult ValidateAnndelMandatoryFields(const nlohmann::json& cmd_meta);

    /**
     * @brief Check if a timestamp is in the past
     * @param timestamp_str ISO timestamp string
     * @return true if timestamp is in the past, false otherwise
     */
    static bool IsTimestampInPast(const std::string& timestamp_str);

    /**
     * @brief Check if a timestamp is expired (validUntil)
     * @param timestamp_str ISO timestamp string
     * @return true if timestamp is expired, false otherwise
     */
    static bool IsTimestampExpired(const std::string& timestamp_str);

    /**
     * @brief Parse ISO timestamp string to time_t
     * @param timestamp_str ISO timestamp string
     * @return time_t value or -1 if parsing fails
     */
    static time_t ParseISOTimestamp(const std::string& timestamp_str);

private:
    static const std::string kErrorInvalidTimestamp;
    static const std::string kErrorInvalidPriority;
    static const std::string kErrorMissingField;
    static const std::string kErrorTimestampInPast;
    static const std::string kErrorTimestampExpired;
    static const std::string kErrorInvalidCommand;
    static const std::string kErrorMalformedMessage;
};

#endif // MESSAGE_VALIDATOR_H
