/**
 * @file Version.h
 * @brief Version information for the Automatic Announcement Service
 * @author Production Release Team
 * @date 2025-11-07
 * @copyright Copyright 2025 Wenzel
 */

#pragma once

#include <string>

namespace Version {
    constexpr const char* MAJOR = "1";
    constexpr const char* MINOR = "0";
    constexpr const char* PATCH = "0";
    constexpr const char* VERSION_STRING = "1.0.0";
    constexpr const char* BUILD_DATE = __DATE__;
    constexpr const char* BUILD_TIME = __TIME__;
    constexpr const char* PRODUCT_NAME = "Automatic Announcement Service (AAS)";
    constexpr const char* COMPANY = "Wenzel";
    constexpr const char* COPYRIGHT = "Copyright 2025 Wenzel";
    
    /**
     * @brief Get full version string with build information
     * @return Formatted version string
     */
    inline std::string GetFullVersionString() {
        return std::string(PRODUCT_NAME) + " v" + VERSION_STRING + 
               " (Built: " + BUILD_DATE + " " + BUILD_TIME + ")";
    }
    
    /**
     * @brief Get version info for logging
     * @return Version info string
     */
    inline std::string GetVersionInfo() {
        return "AAS v" + std::string(VERSION_STRING);
    }
}