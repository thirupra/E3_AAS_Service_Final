/**
 * @file AudioFileFetcher.h
 * @brief Thread-safe client for fetching audio files over HTTPS with mTLS and caching.
 *
 * This class is responsible for the secure retrieval of audio files from a remote
 * server. It leverages a **dynamic certificate module** for mutual TLS (mTLS)
 * authentication and an **audio cache** for efficient, disk-backed storage of
 * downloaded content.
 *
 * Specification: {S_104} Secure Audio Fetching with mTLS
 *
 * Key Responsibilities:
 * - **Secure Download**: Establishes a secure HTTPS connection with the server,
 * using client certificates provided by the `CertificateModule`.
 * - **Cache Integration**: Checks the local `AudioFileCache` for the requested
 * file first to avoid redundant downloads.
 * - **On-Demand Fetching**: Downloads the file from the network only if it's
 * not found in the cache.
 * - **Cache Population**: Stores successfully downloaded files into the
 * `AudioFileCache`.
 *
 * @author Thirupathi Rao
 * @date 2025-09-09
 */
#pragma once
#include <string>
#include "audio_file_cache.h"
#include "certificate_module.h"
#include <string>
#include <mutex>
#include <iostream>

extern std::mutex log_mutex;
/**
 * @class AudioFileFetcher
 * @brief Handles the secure fetching of audio files, coordinating between
 * network downloads and a local file cache.
 */
class AudioFileFetcher {
public:
    /**
     * @brief Constructs the `AudioFileFetcher` instance.
     * @param certModule A pointer to the initialized `CertificateModule` for dynamic certificate paths.
     * @param cache A reference to the `AudioFileCache` for storing and retrieving audio files.
     */
    AudioFileFetcher(CertificateModule* certModule, AudioFileCache& cache);

    /**
     * @brief Initializes the fetcher (e.g., sets up network library context).
     * @return `true` if initialization is successful, `false` otherwise.
     */
    bool Init();

    /**
     * @brief Deinitializes the fetcher, cleaning up any resources.
     */
    void Deinit();

    /**
     * @brief Fetches an audio file, checking the cache first and downloading from the network if necessary.
     *
     * This is the primary public method for retrieving audio. It checks if the file exists
     * in the cache using the provided hash. If not, it attempts a secure download.
     *
     * @param url The HTTPS URL of the audio file to fetch.
     * @param hash The unique hash (e.g., announcement ID) to use as the cache key.
     * @return The local path to the cached audio file if successful, or an empty string on failure.
     */
    std::string FetchAudio(const std::string& url, const std::string& hash);

    /**
     * @brief Checks if an audio file exists in the cache.
     * @param hash The unique hash to check in the cache.
     * @return true if file exists in cache, false otherwise.
     */
    bool IsAudioCached(const std::string& hash);

private:
    /**
     * @brief Downloads a file over HTTPS, using mTLS authentication.
     *
     * This private method encapsulates the low-level network download logic. It uses
     * the client certificates from `CertificateModule` for authentication.
     *
     * @param url The URL of the file to download.
     * @param dest_path The local destination path for the downloaded file.
     * @return The absolute path to the downloaded file on success, or an empty string on failure.
     */
    std::string DownloadFromNetwork(const std::string& url, const std::string& dest_path);  

    AudioFileCache& cache_; ///< A reference to the cache for storing downloaded audio files.
    CertificateModule* certModule_ = nullptr; ///< A pointer to the certificate module for mTLS.
};
