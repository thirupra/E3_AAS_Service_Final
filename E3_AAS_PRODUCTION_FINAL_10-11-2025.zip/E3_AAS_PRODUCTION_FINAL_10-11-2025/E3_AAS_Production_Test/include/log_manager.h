/**
 * @file LogManager.h
 * @brief Centralized logging management for the AAS application.
 * @author Chetana Srinivas
 * @date 2025
 * @copyright Copyright 2025 Wenzel
 */

#ifndef LOG_MANAGER_H_
#define LOG_MANAGER_H_

#include <iostream>
#include <string>
#include <mutex>

/**
 * @brief Log levels for the LogManager.
 */
enum class LogLevel {
    Error = 0,    ///< Error messages
    Warning = 1,  ///< Warning messages
    Info = 2,     ///< Informational messages
    Debug = 3     ///< Debug messages
};

/**
 * @brief Singleton LogManager class for centralized logging.
 * 
 * Provides thread-safe logging with configurable log levels.
 * Currently outputs to console, with future support for syslog.
 */
class LogManager {
public:
    /**
     * @brief Gets the singleton instance of LogManager.
     * 
     * @return Reference to the LogManager instance
     */
    static LogManager& GetInstance();

    /**
     * @brief Sets the current log level.
     * 
     * Messages below this level will not be printed.
     * 
     * @param level The minimum log level to display
     */
    void SetLogLevel(LogLevel level);

    /**
     * @brief Gets the current log level.
     * 
     * @return Current log level
     */
    LogLevel GetLogLevel() const;

    /**
     * @brief Logs an error message.
     * 
     * @param message The error message to log
     */
    void LogError(const std::string& message);

    /**
     * @brief Logs a warning message.
     * 
     * @param message The warning message to log
     */
    void LogWarning(const std::string& message);

    /**
     * @brief Logs an info message.
     * 
     * @param message The info message to log
     */
    void LogInfo(const std::string& message);

    /**
     * @brief Logs a debug message.
     * 
     * @param message The debug message to log
     */
    void LogDebug(const std::string& message);

    // Disable copy constructor and assignment operator
    LogManager(const LogManager&) = delete;
    LogManager& operator=(const LogManager&) = delete;

private:
    /**
     * @brief Private constructor for singleton pattern.
     */
    LogManager();

    /**
     * @brief Internal logging method.
     * 
     * @param level The log level
     * @param levelName String representation of the log level
     * @param message The message to log
     */
    void LogInternal(LogLevel level, const std::string& levelName, const std::string& message);

    /**
     * @brief Gets current timestamp string.
     * 
     * @return Formatted timestamp string
     */
    std::string GetTimestamp() const;

    LogLevel currentLevel_;  ///< Current log level threshold
    mutable std::mutex logMutex_;  ///< Mutex for thread safety
};

// Convenience macros for easy logging
#define LOG_ERROR(msg) LogManager::GetInstance().LogError(msg)
#define LOG_WARNING(msg) LogManager::GetInstance().LogWarning(msg)
#define LOG_INFO(msg) LogManager::GetInstance().LogInfo(msg)
#define LOG_DEBUG(msg) LogManager::GetInstance().LogDebug(msg)

#endif  // LOG_MANAGER_H_
