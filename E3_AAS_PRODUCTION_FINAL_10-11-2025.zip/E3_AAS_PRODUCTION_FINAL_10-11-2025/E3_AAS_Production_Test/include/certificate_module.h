/**
 * @file CertificateModule.h
 * @brief Certificate lifecycle module with JSON config support and daily auto-renewal.
 */

#pragma once

#include <string>
#include <atomic>

/**
 * @class CertificateModule
 * @brief Manages certificate lifecycle: validation, OTT request, CSR generation,
 *        signing, and renewal. Supports daily automatic renewal loop.
 */
class CertificateModule {
private:
    // Instance variables instead of static/global variables
    std::atomic<bool> running_{true};
    bool lastRenewalPerformed_{false};
    
public:
    /**
     * @brief Construct a CertificateModule.
     * @param deviceId Device identifier.
     * @param certPath Path to device certificate file.
     * @param keyPath Path to device private key file.
     * @param ottUrl URL for OTT (One-Time Token) request.
     * @param caBundlePath Path to CA certificate bundle.
     * @param signUrl URL for certificate signing.
     * @param renewUrl URL for certificate renewal.
     * @param ottUser OTT request username.
     * @param ottPass OTT request password.
     * @param expectedFingerprint Expected CA certificate fingerprint (for validation).
     */
    CertificateModule(const std::string& deviceId,
                      const std::string& certPath,
                      const std::string& keyPath,
                      const std::string& ottUrl,
                      const std::string& caBundlePath,
                      const std::string& signUrl,
                      const std::string& renewUrl,
                      const std::string& ottUser,
                      const std::string& ottPass,
                      const std::string& expectedFingerprint = "");

    /**
     * @brief Destructor for CertificateModule.
     */
    ~CertificateModule();

    /**
     * @brief Initialize the certificate module.
     *        - Downloads CA bundle.
     *        - Validates existing certificate.
     *        - Requests or renews certificate if needed.
     * @return true if successful, false otherwise.
     */
    bool Init();

    /**
     * @brief Cleanup resources if needed.
     */
    void Deinit();

    /**
     * @brief Download CA bundle from the configured source.
     * @return true if successful, false otherwise.
     */
    bool DownloadCABundle();

    /**
     * @brief Run full certificate request flow (OTT → CSR → sign).
     * @return true if successful, false otherwise.
     */
    bool RequestCertificateFlow();

    /**
     * @brief Validate existing certificate.
     * @return true if valid, false otherwise.
     */
    bool ValidateCert();

    /**
     * @brief Renew the existing certificate using CA endpoint.
     * @return true if successful, false otherwise.
     */
    bool RenewCert();

    /**
     * @brief Request a one-time token (OTT) from the OTT server.
     * @return The OTT string if successful, empty string on failure.
     */
    std::string RequestOTT();

    /**
     * @brief Generate a Certificate Signing Request (CSR).
     * @return CSR string if successful, empty string otherwise.
     */
    std::string GenerateCSR();

    /**
     * @brief Sign a certificate using CSR and OTT.
     * @param csr The Certificate Signing Request.
     * @param ott The One-Time Token.
     * @return true if signing succeeded, false otherwise.
     */
    bool SignCert(const std::string& csr, const std::string& ott);

    /**
     * @brief Check if certificate is near expiry.
     * @param daysThreshold Days before expiry to trigger renewal.
     * @return true if certificate will expire soon, false otherwise.
     */
    bool IsCertNearExpiry(int daysThreshold = 2);

    /**
     * @brief Get the path to the currently valid certificate.
     * @return Certificate path string.
     */
    std::string GetValidCert() const;

    /**
     * @brief Get the path to the private key.
     * @return Private key path string.
     */
    std::string GetKeyPath() const;

    /**
     * @brief Get the path to the CA bundle.
     * @return CA bundle path string.
     */
    std::string GetCABundlePath() const;

    /**
     * @brief Get the path to the client certificate.
     * @return Client certificate path string.
     */
    std::string GetClientCertPath() const { return certPath_; }

    /**
     * @brief Get the path to the client private key.
     * @return Private key path string.
     */
    std::string GetClientKeyPath() const { return keyPath_; }

    /**
     * @brief Get the path to the CA certificate bundle.
     * @return CA bundle path string.
     */
    std::string GetCACertPath() const { return caBundlePath_; }

    /**
     * @brief Run an infinite daily renewal loop.
     *        - Validates certificate daily.
     *        - Renews if near expiry.
     *        - If renewal fails, requests a fresh certificate.
     *        - Sleeps 24 hours before repeating.
     */
    void RunDailyRenewalLoop();
    void StopRenewalLoop() { running_ = false; }
    std::string GetDeviceId() const;

    /**
     * @brief Validate CA bundle against expected fingerprint.
     * @return true if fingerprint matches or no fingerprint configured, false otherwise.
     */
    bool ValidateCAFingerprint();

    /**
     * @brief Calculate SHA256 fingerprint of a certificate file.
     * @param certPath Path to the certificate file.
     * @return SHA256 fingerprint as hex string, empty on failure.
     */
    std::string CalculateCertFingerprint(const std::string& certPath);

private:
    std::string deviceId_;
    std::string certPath_;
    std::string keyPath_;
    std::string ottUrl_;
    std::string caBundlePath_;
    std::string signUrl_;
    std::string renewUrl_;
    std::string ottUser_;
    std::string ottPass_;
    std::string expectedFingerprint_;  
    bool isValid_;

public:
    /**
     * @brief Check if renewal loop is running.
     * @return true if running, false otherwise
     */
    bool IsRunning() const;

private:

    /**
     * @brief Run a system command (no capture).
     * @param cmd Command string.
     * @return true if exit code was 0, false otherwise.
     */
    bool RunCommand(const std::string& cmd);

    /**
     * @brief Run a system command and capture its output.
     * @param cmd Command string.
     * @return Captured output as string.
     */
    std::string RunCommandCapture(const std::string& cmd);
};
