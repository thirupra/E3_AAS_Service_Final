#pragma once
#include <chrono>
#include <string>
#include "broker_base.h"
#include "config_manager.h"

/**
 * @file ConfigSettings.h
 * @brief Configuration struct - now populated from ConfigManager singleton.
 * 
 * This struct provides a convenient interface to configuration values
 * loaded from the ConfigManager. Values are no longer hard-coded.
 */

struct Config {
    BrokerConfig tdm_broker;
    
    // IPC (System V message queue) key string/path token + proj id.
    std::string ipc_ftok_path;
    int ipc_proj_id;

    // Scheduler cadence and timeouts (now loaded from config file)
    std::chrono::milliseconds announcement_tick;
    std::chrono::milliseconds min_sleep;
    std::chrono::seconds elisa_ack_timeout;

    // Queue sizes
    size_t max_pending_jobs;

    // Logging toggles
    bool verbose_logging;

    /**
     * @brief Factory method to create Config from ConfigManager.
     * 
     * @return Config struct populated with values from ConfigManager
     */
    static Config FromConfigManager() {
        const auto& mgr = ConfigManager::GetInstance();
        const auto& ipc_cfg = mgr.GetIpc();
        const auto& sched_cfg = mgr.GetScheduler();
        
        Config cfg;
        cfg.tdm_broker = mgr.GetTdmBroker();
        cfg.ipc_ftok_path = ipc_cfg.ftok_path;
        cfg.ipc_proj_id = ipc_cfg.proj_id;
        cfg.announcement_tick = std::chrono::milliseconds(sched_cfg.announcement_tick_ms);
        cfg.min_sleep = std::chrono::milliseconds(sched_cfg.min_sleep_ms);
        cfg.elisa_ack_timeout = std::chrono::seconds(sched_cfg.elisa_ack_timeout_seconds);
        cfg.max_pending_jobs = sched_cfg.max_pending_jobs;
        cfg.verbose_logging = sched_cfg.verbose_logging;
        
        return cfg;
    }
};

