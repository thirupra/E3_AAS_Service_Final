
#ifndef AAS_APP_H_
#define AAS_APP_H_


#pragma once
#include <chrono>
#include <functional>
#include <optional>
#include <string>
#include "announcement_job.h"
#include "command_processor_and_scheduler.h"
#include "config_settings.h"
#include "elisa3_manager.h"
#include "pdcc_priority_queue_manager.h"

/**
 * @file AASApp.h
 * @brief Main application facade for the Audio Announcement System (AAS).
 * 
 * This class serves as the central integration point for the AAS system,
 * coordinating between AMQP message handling, PDCC queue management,
 * scheduling, and ELISA3 communication.
 * 
 * The AASApp orchestrates the complete announcement lifecycle:
 * - Receives PDCC commands from AMQPHandler
 * - Manages announcement jobs in the priority queue
 * - Coordinates with the scheduler for timing
 * - Handles communication with ELISA3 devices
 * - Emits PPM status messages
 * 
 * @note Initial "pdc-received" PPM messages are sent by AMQPHandler.
 *       AASApp only emits final success/error messages after ELISA processing.
 */


struct PdccAnnOut {
  std::string device_command_id;      ///< Unique identifier for the device command
  int priority = 1;                   ///< Priority level (1-9, where 9 is highest)
  std::string channel_address;        ///< Target channel/device address
  std::chrono::system_clock::time_point valid_until;        ///< Command expiration time
  std::chrono::system_clock::time_point requested_output_time;  ///< When to play the announcement
  int64_t sequence_no = 0;            ///< Sequence number for ordering
  std::string announcement_id;        ///< Unique announcement identifier
  std::string announcement_hash;      ///< Hash of the announcement content
  std::string profile_text;           ///< Text content of the announcement
  std::string profile_language;      ///< Language code (e.g., "en", "de")
  std::vector<std::string> content_urls;      ///< HTTPS URLs to audio files (supports multiple files)
  
  // Backward compatibility
  std::string content_url;            ///< DEPRECATED: Use content_urls instead (kept for compatibility)
};


/**
 * @brief Structure representing an ANNDEL (announcement delete) command.
 * 
 * Contains metadata required to cancel/delete a pending announcement.
 */
struct PdccAnnDel {
  std::string device_command_id;      ///< Unique identifier for the device command
  std::string channel_address;        ///< Target channel/device address (optional)
  int64_t sequence_no = 0;            ///< Sequence number for ordering
  std::string announcement_id;        ///< Announcement ID to cancel
};

/**
 * @brief Callback function type for emitting PPM (Publication Process Monitoring) messages.
 * 
 * Used to send final success/error status messages after ELISA3 processing.
 * 
 * @param type Message type ("success" or "error")
 * @param event Event type ("aag-ack" or "aag-nack")
 * @param job The announcement job that was processed
 * @param detail Additional error details (for error messages)
 */
using PpmEmitFn = std::function<void(const std::string& type,
                                     const std::string& event,
                                     const AnnouncementJob& job,
                                     const std::string& detail)>;


/**
 * @brief Callback function type for downloading audio files.
 * 
 * Synchronous download function that returns the local file path or nullopt on failure.
 * 
 * @param https_url HTTPS URL of the audio file to download
 * @param expected_hash Expected SHA hash of the file for verification
 * @param error_detail Output parameter for error details
 * @return Local file path if successful, nullopt if failed
 */
using DownloadFn = std::function<std::optional<std::string>(
        const std::string& https_url,
        const std::string& expected_hash,
        std::string* error_detail)>; 


/**
 * @brief Callback function type for download status notifications.
 * 
 * Used for UI updates, metrics collection, and logging download progress.
 * 
 * @param job The announcement job being processed
 * @param state Current download state
 * @param detail Additional status details
 */
using DownloadStatusFn = std::function<void(const AnnouncementJob& job,
                                            DownloadState state,
                                            const std::string& detail)>;

/**
 * @brief Main application class for the Audio Announcement System.
 * 
 * This class serves as the central coordinator for all AAS functionality,
 * managing the complete announcement lifecycle from PDCC command reception
 * through ELISA3 device communication.
 */

class AASApp {
 public:
  /**
   * @brief Constructs an AASApp instance.
   * 
   * @param cfg Configuration settings for the application
   * @param ppm_emit Callback function for emitting PPM messages
   * @param download_fn Callback function for downloading audio files
   * @param status_fn Optional callback for download status notifications
   */
  AASApp(const Config& cfg, PpmEmitFn ppm_emit, DownloadFn download_fn,
         DownloadStatusFn status_fn = nullptr);

  /**
   * @brief Starts the AAS application.
   * 
   * Initializes and starts the scheduler and other background processes.
   */
  void Start();

  /**
   * @brief Stops the AAS application.
   * 
   * Gracefully shuts down all background processes and cleans up resources.
   */
  void Stop();

  /**
   * @brief Handles an ANNOUT (announcement output) command.
   * 
   * Processes the announcement request and queues the job for scheduling.
   * Audio download is handled by DownloadManager.
   * 
   * @param pdcc The ANNOUT command data
   */
  void HandleAnnOut(const PdccAnnOut& pdcc);

  /**
   * @brief Handles an ANNDEL (announcement delete) command.
   * 
   * Cancels a pending announcement and removes it from the queue.
   * 
   * @param pdcc The ANNDEL command data
   */
  void HandleAnnDel(const PdccAnnDel& pdcc);

  /**
   * @brief Handles download completion and schedules the job.
   * 
   * Called when a download completes successfully or fails.
   * Schedules the job for processing or handles download failure.
   * 
   * @param announcement_id The announcement ID
   * @param success Whether the download was successful
   * @param local_file_path The local file path (empty if failed)
   */
  void HandleDownloadComplete(const std::string& announcement_id, bool success, const std::string& local_file_path);

  /**
   * @brief Handles a keep-alive message.
   * 
   * Currently a no-op, but can be extended for health monitoring.
   */
  void HandleKeepAlive();

  /**
   * @brief Gets a pointer to the PDCC priority queue manager.
   * 
   * @return Pointer to the queue manager
   */
  PDCCPriorityQueueManager* Queue() { return &pdcc_queue_; }

  /**
   * @brief Gets a pointer to the command processor and scheduler.
   * 
   * @return Pointer to the scheduler
   */
  CommandProcessorAndScheduler* Scheduler() { return &scheduler_; }
  /**
   * @brief Gets a reference to the ELISA3 manager.
   * 
   * @return Reference to the ELISA3 manager
   */
  ELISA3Manager& GetElisaManager() { return elisa_; }

 private:
  /**
   * @brief Creates an AnnouncementJob from PDCC ANNOUT data.
   * 
   * @param p The PDCC ANNOUT command data
   * @return The created announcement job
   */
  AnnouncementJob MakeJobFromPdcc(const PdccAnnOut& p) const;

  /**
   * @brief Notifies about download status changes.
   * 
   * @param j The announcement job
   * @param st The new download state
   * @param detail Additional status details
   */
  void NotifyStatus(const AnnouncementJob& j, DownloadState st, const std::string& detail) const;

  Config cfg_;                    ///< Application configuration
  PpmEmitFn ppm_emit_;           ///< PPM message emission callback
  DownloadFn download_fn_;        ///< Audio file download callback
  DownloadStatusFn status_fn_;    ///< Download status notification callback

  PDCCPriorityQueueManager pdcc_queue_;    ///< Priority queue for announcement jobs
  ELISA3Manager elisa_;                    ///< ELISA3 device communication manager
  CommandProcessorAndScheduler scheduler_; ///< Command processor and scheduler
};

#endif