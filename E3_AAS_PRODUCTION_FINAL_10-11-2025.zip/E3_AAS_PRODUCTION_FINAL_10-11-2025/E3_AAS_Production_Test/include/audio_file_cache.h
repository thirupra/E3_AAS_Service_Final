/**
 * @brief Thread-safe LRU cache for audio files with asynchronous eviction.
 *
 * Specification: {S_105} Audio Cache Management and Eviction Policy
 *
 * This class manages caching of audio files identified by a hash key,
 * storing them on disk with efficient Least Recently Used (LRU) eviction,
 * using a background thread to asynchronously remove old files when needed.
 *
 * Author: Thirupathi Rao
 * Date: 2025-09-09
 */
#pragma once
#include <string>
#include <list>
#include <unordered_map>
#include <mutex>
#include <condition_variable>
#include <thread>
#include <atomic>



/**
 * @brief Thread-safe LRU cache for audio files with asynchronous eviction.
 */
class AudioFileCache {
public:
    /**
     * @brief Constructs the audio cache with a maximum size limit.
     * @param maxSize Maximum number of audio files to cache.
     */
    explicit AudioFileCache(size_t maxSize);
    

    bool Init();
    void Deinit();

    /**
     * @brief Retrieves full cached file path for a given hash.
     * Updates usage to keep file as most recently used.
     * @param hash Unique hash of the audio file (without file extension).
     * @return Full filesystem path if found, empty string otherwise.
     */
    std::string GetAudio(const std::string& hash);

    /**
     * @brief Adds or updates an audio file in the cache.
     * Triggers async eviction if cache exceeds max size.
     * @param hash Unique hash of the audio file (without extension).
     * @param filePath Absolute or relative path to the audio file.
     */
    void StoreAudio(const std::string& hash, const std::string& filePath);

    void RemoveAudio(const std::string& hash);


private:
    using ListIt = std::list<std::string>::iterator;
    struct CacheEntry {
        std::string path;
        std::list<std::string>::iterator lruIt;
        size_t sizeBytes;
    };

    size_t currentBytes_ = 0; ///< Current total size of cached files

    /**
     * @brief Marks a cached file as recently used by moving it to the front of LRU list.
     * @param key Hash key of the audio file.
     */
    void touch(const std::string& key);

    /**
     * @brief Background eviction thread function.
     * Waits for eviction requests and evicts least recently used files.
     */
    void EvictionLoop();

    std::unordered_map<std::string, CacheEntry> cacheMap_; //< Maps hash to path and position in LRU list.

    std::list<std::string> lruList_;  ///< Keys ordered from most recently used (front) to least (back).
    
    size_t maxBytes_;       ///< Maximum allowed cache size in bytes
    std::mutex mutex_;  // protects cacheMap_ and lruList_

    // Eviction thread members
    std::mutex eviction_mutex_; ///< Mutex for eviction thread condition.
    std::condition_variable eviction_cv_; ///< Condition variable to signal eviction thread.
    std::atomic<bool> eviction_requested_{false}; ///< Set when eviction required.
    std::atomic<bool> stop_eviction_thread_{false}; //< Set when shutdown requested.
    std::thread eviction_thread_; //< Background thread performing eviction.
};
