#pragma once
#include "broker_base.h"
#include "elisa3_manager.h"
#include "certificate_module.h"
#include <memory>
#include <thread>
#include <unordered_set>
#include <mutex>

/**
 * @class StatusFeedbackModule
 * @brief Manages device status and publishes to TDM broker.
 *
 * Derives from BrokerBase to directly handle AMQP connection,
 * publishing, and TLS/mTLS support. Tracks defective destinations
 * and manages state transitions based on ELISA III-IP feedback.
 */
class StatusFeedbackModule : public BrokerBase {
public:
    /**
     * @enum State
     * @brief Represents the operational state of the device.
     */
    enum class State {
        kUninitialized, ///< Not initialized
        kRunning,       ///< All destinations OK
        kStarted,       ///< Started
        kDegraded,      ///< Some destinations defective
        kFault,         ///< Device fault
        kRestarting     ///< Restarting
    };

    /**
     * @brief Get singleton instance.
     * @param cfg Configuration object.
     * @param elisaManager Shared pointer to ELISA3Manager.
     * @param certModule Pointer to CertificateModule.
     * @return Reference to singleton instance.
     */
    static StatusFeedbackModule& GetInstance(Config& cfg,
                                             std::shared_ptr<ELISA3Manager> elisaManager,
                                             CertificateModule* certModule);

    /**
     * @brief Start the status feedback module.
     */
    void Start();

    /**
     * @brief Stop the status feedback module.
     */
    void Stop();

    /**
     * @brief Handle ELISA ACK events.
     * @param ack ELISA acknowledgment structure.
     */
    void OnElisaAck(const ElisaAck& ack);

    /**
     * @brief Handle spontaneous ELISA TDM status events.
     * @param status TDM status structure from ELISA.
     */
    void OnTdmStatus(const TdmStatus& status);

    /**
     * @brief Establish connection to TDM broker.
     * @return true if successful, false otherwise.
     */
    bool Connect() override;

    /**
     * @brief Publishes a message to a specific exchange with a routing key.
     * @param exchange The AMQP exchange to publish to.
     * @param routing_key The routing key for message routing.
     * @param message The message content to publish.
     * @return true if the message was successfully published, false otherwise.
     */
    bool Publish(const std::string& exchange, const std::string& routing_key, const std::string& message) override;

private:
    /**
     * @brief Constructor.
     * @param cfg Configuration object.
     * @param elisaManager Shared pointer to ELISA3Manager.
     * @param certModule Pointer to CertificateModule.
     */
    StatusFeedbackModule(Config& cfg,
                         std::shared_ptr<ELISA3Manager> elisaManager,
                         CertificateModule* certModule);

    /**
     * @brief Destructor.
     */
    ~StatusFeedbackModule();

    /**
     * @brief Map ELISA code to internal state.
     * @param code ELISA code.
     * @return Corresponding State.
     */
    State MapElisaCodeToState(unsigned long code);

    /**
     * @brief Build and publish status message.
     * @param newState New state to publish.
     * @param ack ELISA acknowledgment.
     */
    void BuildAndPublishStatus(State newState, const ElisaAck& ack);

    /**
     * @brief Convert state to string.
     * @param state State enum.
     * @return String representation.
     */
    std::string StateToString(State state);

    /**
     * @brief Periodic status publishing loop.
     */
    void PeriodicStatusLoop();

    std::shared_ptr<ELISA3Manager> elisaManager_; ///< ELISA3Manager instance
    CertificateModule* certModule_;                    ///< CertificateModule instance
    State currentState_;                               ///< Current state
    std::thread periodicThread_;                       ///< Periodic thread
    bool shutdown_requested_ = false;                  ///< Shutdown flag

    /// Set of defective destination channel addresses
    std::unordered_set<std::string> defective_destinations_;
    std::mutex defective_mutex_;
};