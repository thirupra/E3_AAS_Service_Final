/**
 * @file BrokerBase.h
 * @brief Base class for AMQP broker connectivity and configuration handling.
 *
 * This header defines the foundation for interacting with an AMQP (RabbitMQ) broker.
 * The `BrokerBase` class provides common functionalities like connecting, disconnecting,
 * and handling basic setup (e.g., declaring exchanges and queues). It's designed
 * as a base class, so more specific handlers like `AMQPHandler` can inherit from it
 * and add custom logic for publishing, subscribing, and consuming messages.
 *
 * Specification: {S_101} Broker Connectivity and Configuration
 *
 * Responsibilities:
 * - Provides a uniform way to connect to an AMQP broker using either plain TCP or secure SSL/TLS.
 * - Manages the entire connection lifecycle, from socket creation to closing the connection.
 * - Declares and binds exchanges and queues as specified by the configuration.
 * - Holds all necessary connection settings in the `BrokerConfig` struct.
 * - Exposes a set of virtual methods for derived classes to override, enabling custom behavior.
 *
 * Author: Thirupathi Rao
 * Date: 2025-09-10
 */

#pragma once
#include <string>
#include <functional>
#include <iostream>
#include <mutex>
#include <thread>
#include "certificate_module.h"
// (portable rabbitmq-c includes)
#if defined(__has_include)
  #if __has_include(<rabbitmq-c/amqp.h>)
    #include <rabbitmq-c/amqp.h>
    #include <rabbitmq-c/framing.h>
    #if __has_include(<rabbitmq-c/tcp_socket.h>)
      #include <rabbitmq-c/tcp_socket.h>
    #endif
    #if __has_include(<rabbitmq-c/ssl_socket.h>)
      #include <rabbitmq-c/ssl_socket.h>
    #endif
  #elif __has_include(<amqp.h>)
    #include <amqp.h>
    #include <amqp_framing.h>
    #include <amqp_tcp_socket.h>
    #if __has_include(<amqp_ssl_socket.h>)
      #include <amqp_ssl_socket.h>
    #endif
  #else
    #error "rabbitmq-c headers not found. Install librabbitmq-dev (or adjust include paths)."
  #endif
#else
  // Fallback for older compilers: most Ubuntu/Debian use <amqp.h>
  #include <amqp.h>
  #include <amqp_framing.h>
  #include <amqp_tcp_socket.h>
#endif

/**
 * @struct BrokerConfig
 * @brief A structure to hold all configuration settings for an AMQP broker connection.
 *
 * This struct serves as a single place to store all the details needed to
 * establish and manage a connection to a RabbitMQ broker, including network
 * information, authentication credentials, and messaging-related settings.
 */
struct BrokerConfig {
    std::string host;               ///< The hostname or IP address of the broker.
    std::string username;           ///< The username for authentication.
    std::string password;           ///< The password for authentication.
    std::string virtual_host;       ///< The virtual host to connect to.
    std::string queue_name;         ///< The name of the queue to connect to.
    int port;                       ///< The port number of the broker.
    std::string exchange;           ///< The name of the message exchange.
    std::string routing_key;        ///< The routing key for message routing.
    std::string ca_cert_file;       ///< Path to the CA certificate file for SSL/TLS.
    std::string client_cert_file;   ///< Path to the client certificate file for SSL/TLS.
    std::string client_key_file;    ///< Path to the client key file for SSL/TLS.
    int max_retries;                ///< Maximum number of connection retry attempts.
    int retry_delay_secs;           ///< Delay in seconds between retry attempts.
    int prefetch_count;             ///< The number of messages the consumer can receive before acknowledging.

    /**
     * @brief Default constructor for BrokerConfig.
     * Initializes default values for numerical members.
     */
    BrokerConfig()
        : port(0), max_retries(5), retry_delay_secs(3), prefetch_count(1) {}

    /**
     * @brief Parameterized constructor for BrokerConfig.
     * @param h Hostname or IP.
     * @param u Username.
     * @param p Password.
     * @param vhost Virtual host.
     * @param q Queue name.
     * @param prt Port number.
     * @param exch Exchange name.
     * @param rkey Routing key.
     * @param ca Path to CA cert.
     * @param cc Path to client cert.
     * @param ck Path to client key.
     * @param retries Max connection retries.
     * @param delaySecs Delay between retries.
     * @param prefetch Consumer prefetch count.
     */
    BrokerConfig(const std::string& h, const std::string& u, const std::string& p,
                 const std::string& vhost, const std::string& q, int prt,
                 const std::string& exch, const std::string& rkey,
                 const std::string& ca, const std::string& cc, const std::string& ck,
                 int retries = 5, int delaySecs = 3, int prefetch = 1)
        : host(h), username(u), password(p), virtual_host(vhost),
          queue_name(q), port(prt), exchange(exch), routing_key(rkey),
          ca_cert_file(ca), client_cert_file(cc), client_key_file(ck),
          max_retries(retries), retry_delay_secs(delaySecs), prefetch_count(prefetch) {}
};

/**
 * @class BrokerBase
 * @brief Base class for managing an AMQP broker connection.
 *
 * This class handles the core logic for connecting to an AMQP broker. It
 * can establish either a plain TCP connection or a secure SSL/TLS connection
 * based on the provided configuration. It also manages the initial setup,
 * including declaring an exchange and a queue, and binding them together.
 *
 * Derived classes should inherit from `BrokerBase` to implement specific
 * messaging patterns, such as a publisher or a consumer.
 */
class BrokerBase {
public:
    /**
     * @using MessageCallback
     * @brief A function signature for a callback that processes a received message.
     *
     * This is a function type that takes a single `std::string` argument
     * (the message body) and returns `void`. It is used by a subscriber to
     * define what happens when a message is successfully consumed from the queue.
     */
    using MessageCallback = std::function<void(const std::string&)>;

    /**
     * @brief Constructs a new BrokerBase instance.
     * @param config A constant reference to the BrokerConfig struct
     * containing all connection details.
     */
    BrokerBase(const BrokerConfig& config, CertificateModule* certModule = nullptr)
        : config_(config), message_callback_(nullptr), conn_(nullptr), socket_(nullptr),
          connected_(false), certModule_(certModule) {}

    /**
     * @brief Destructor for BrokerBase.
     * Automatically calls `Disconnect()` to ensure a clean shutdown.
     */
    virtual ~BrokerBase() {
        Disconnect();
    }

    /**
     * @brief Establishes a connection to the AMQP broker.
     *
     * This method handles the full connection workflow:
     * 1. Creates a new connection object.
     * 2. Creates a TCP or SSL socket based on whether SSL certificate paths are provided.
     * 3. Opens the socket and attempts to log in using the configured credentials.
     * 4. Opens a communication channel.
     * 5. Declares the message exchange and the queue.
     * 6. Binds the queue to the exchange using the routing key.
     *
     * @return `true` if all steps succeed and the connection is ready; `false` otherwise.
     */
    virtual bool Connect();

    /**
     * @brief A virtual method for post-connection setup.
     *
     * This method is called after a successful connection, login, and
     * declaration of the exchange and queue. Derived classes can override
     * this method to perform additional setup, such as starting a consumer
     * or a message publisher.
     * @return `true` on success, `false` otherwise.
     */
    virtual bool PostConnectSetup() {
        return true;
    }

    /**
     * @brief Disconnects from the AMQP broker.
     *
     * This method gracefully closes the channel and the connection, and
     * frees all associated resources. This is a crucial step for a clean
     * shutdown of the application.
     */
    virtual void Disconnect();

    /**
     * @brief Initializes the broker handler.
     * This is the main entry point for starting the broker connection logic.
     * By default, it just calls `Connect()`.
     * @return `true` if initialization is successful, `false` otherwise.
     */
    virtual bool Init() {
        return Connect();
    }

    /**
     * @brief De-initializes the broker handler.
     * This is the main entry point for stopping the broker connection logic.
     * By default, it just calls `Disconnect()`.
     */
    virtual void Deinit() {
        Disconnect();
    }

    /**
     * @brief Publishes a message to a specific exchange with a routing key.
     *
     * This virtual method is intended to be overridden by a publishing-focused
     * derived class. It sends the given message to the specified AMQP exchange
     * and routing key.
     *
     * @param exchange The name of the AMQP exchange to publish to.
     * @param routing_key The routing key used by the exchange to route the message.
     * @param message The content of the message to be published.
     * @return `true` if the message was successfully published, `false` otherwise.
     */
    virtual bool Publish(const std::string& exchange, const std::string& routing_key, const std::string& message);

    /**
     * @brief Subscribes to a topic (queue).
     * This is a virtual method that should be implemented by a consuming-focused
     * derived class.
     * @param topic The name of the queue to subscribe to.
     * @param callback The function to be called for each received message.
     * @return `true` on success, `false` otherwise.
     */
    virtual bool Subscribe(const std::string& topic, const MessageCallback& callback) {
        return false;
    }

    /**
     * @brief Sets the callback function for message processing.
     * @param callback The function to be called when a message is received.
     */
    virtual void SetMessageCallback(const MessageCallback& callback) {
        message_callback_ = callback;
    }

    /**
     * @brief Gets the current system timestamp.
     * This is a static utility function, useful for logging and stamping messages.
     * @return A string representation of the current timestamp.
     */
    static std::string currentTimestamp();

protected:
    BrokerConfig config_;                   ///< The configuration settings for the connection.
    MessageCallback message_callback_;      ///< The callback function to process received messages.
    amqp_connection_state_t conn_;          ///< The main connection state object.
    amqp_socket_t* socket_;                 ///< Pointer to the underlying socket (TCP or SSL).
    bool connected_;                        ///< A flag to track the connection status.
    CertificateModule* certModule_;         ///< An optional module for dynamic certificate management.
};
