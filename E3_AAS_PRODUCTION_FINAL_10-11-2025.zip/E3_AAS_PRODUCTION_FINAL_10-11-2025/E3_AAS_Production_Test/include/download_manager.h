/**
 * @file DownloadManager.h
 * @brief Declaration of DownloadManager for asynchronous audio downloads with thread pool.
 *
 * Specification: {S_103} Audio Download Management 
 *
 * Provides thread-safe queueing of download jobs, multiple worker threads for
 * concurrent downloads, and status callback notification.
 *
 * Author: Thirupathi Rao
 * Date: 2025-09-09
 */
#pragma once
#include <queue>
#include <mutex>
#include <thread>
#include <vector>
#include <unordered_map>
#include <condition_variable>
#include <functional>
#include <chrono>
#include "audio_file_fetcher.h"


/**
 * @brief Enhanced PDCCJob structure supporting multiple audio files per announcement.
 */
struct PDCCJob {
    std::string announcementId;                  ///< Unique announcement ID (for status updates)
    std::vector<std::string> audioUris;          ///< URIs to fetch audio files (multiple files supported)
    std::vector<std::string> announcementHashes; ///< Hashes for cache and file storage (parallel to audioUris)
    
    // Backward compatibility
    std::string audioUri;            ///< DEPRECATED: Use audioUris instead (kept for compatibility)
    std::string announcementHash;   ///< DEPRECATED: Use announcementHashes instead (kept for compatibility)
};


/**
 * @brief Callback type to report download status back to manager.
 * @param announcementId Unique announcement ID.
 * @param status Status string like "SUCCESS" or "FAILED".
 * @param localFilePaths Vector of paths to downloaded files (supports multiple files per announcement).
 */
using DownloadStatusCallback = std::function<void(const std::string&, const std::string&, const std::vector<std::string>&)>;

/**
 * @brief Legacy callback type for backward compatibility.
 * @param announcementId Unique announcement ID.
 * @param status Status string like "SUCCESS" or "FAILED".
 * @param localFilePath Path to downloaded file on success, empty otherwise.
 */
using LegacyDownloadStatusCallback = std::function<void(const std::string&, const std::string&, const std::string&)>;

/**
 * @brief Structure to track multi-file download progress for an announcement.
 */
struct AnnouncementDownloadState {
    std::string announcementId;                          ///< Unique announcement ID
    std::vector<std::string> audioUris;                  ///< URLs to download
    std::vector<std::string> announcementHashes;        ///< Hashes for each file
    std::vector<std::string> localFilePaths;             ///< Downloaded file paths (parallel to audioUris)
    std::vector<bool> downloadCompleted;                 ///< Completion status for each file
    std::vector<std::string> downloadErrors;             ///< Error messages for failed downloads
    size_t completedCount = 0;                           ///< Number of files successfully downloaded
    size_t failedCount = 0;                              ///< Number of files that failed to download
    std::chrono::system_clock::time_point startTime;     ///< When download started
    
    /**
     * @brief Checks if all files have been processed (either completed or failed).
     * @return True if all downloads are finished, false if some are still pending
     */
    bool IsAllProcessed() const {
        return (completedCount + failedCount) >= audioUris.size();
    }
    
    /**
     * @brief Checks if all files were successfully downloaded.
     * @return True if all downloads succeeded, false otherwise
     */
    bool IsAllSuccessful() const {
        return completedCount == audioUris.size() && failedCount == 0;
    }
};

/**
 * @brief Manages asynchronous downloading of audio files using a thread pool.
 *
 * Supports multiple worker threads processing download jobs concurrently,
 * reporting status updates via callback.
 */
class DownloadManager {
public:
    /**
     * @brief Constructs DownloadManager.
     * @param fetcher Reference to AudioFileFetcher instance.
     * @param statusCb Callback for download status notifications.
     */
    DownloadManager(AudioFileFetcher& fetcher, DownloadStatusCallback statusCb);

    /**
     * @brief Initializes manager and starts worker thread pool.
     * @param numThreads Number of worker threads to launch. Default 0 uses hardware concurrency or 1.
     * @return True if initialization successful.
     */
    bool Init(size_t numThreads = 0);

    /**
     * @brief Gracefully stops all worker threads and clears thread pool.
     */
    void Deinit();

    /**
     * @brief Submits a download job.
     * @param job Download job with announcement data.
     */
    void SubmitTask(const PDCCJob& job);

    /**
     * @brief Reports audio download status for a job.
     * @param job The download job.
     * @param status Status string, e.g., "SUCCESS", "FAILED".
     * @param filePath Optional local file path of downloaded audio.
     */
    void SetAudioStatus(const PDCCJob& job, const std::string& status, const std::string& filePath = "");

    /**
     * @brief Checks if an audio file already exists in the cache.
     * @param hash Hash of the audio file to check.
     * @return true if file exists in cache, false otherwise.
     */
    bool IsAudioCached(const std::string& hash);


private:
    /**
     * @brief Thread worker function to process jobs from the queue.
     */
    void WorkerThread();
    
    /**
     * @brief Internal job structure for individual file downloads.
     */
    struct InternalDownloadJob {
        std::string announcementId;      ///< Announcement this file belongs to
        std::string audioUri;            ///< Single file URI to download
        std::string announcementHash;    ///< Hash for this specific file
        size_t fileIndex;                ///< Index of this file within the announcement
    };

    /**
     * @brief Handles completion of a single file download within a multi-file announcement.
     * @param announcementId ID of the announcement
     * @param fileIndex Index of the completed file
     * @param success Whether the download succeeded
     * @param localFilePath Path to downloaded file (if successful)
     * @param errorMessage Error message (if failed)
     */
    void HandleSingleFileCompletion(const std::string& announcementId, size_t fileIndex, 
                                   bool success, const std::string& localFilePath, 
                                   const std::string& errorMessage = "");

    /**
     * @brief Thread-safe logging methods
     */
    void LogInfo(const std::string& message) const;
    void LogError(const std::string& message) const;

    AudioFileFetcher& fetcher_;                          ///< Reference to audio fetcher
    DownloadStatusCallback statusCallback_;              ///< Status reporting callback

    std::queue<InternalDownloadJob> taskQueue_;          ///< Queue of individual file download jobs
    std::unordered_map<std::string, AnnouncementDownloadState> announcementStates_; ///< Track multi-file download progress
    
    std::mutex mutex_;                                    ///< Mutex protecting task queue and state
    mutable std::mutex logMutex_;                         ///< Mutex for thread-safe logging
    std::condition_variable cv_;                          ///< Condition variable for worker notification
    bool running_;                                        ///< Flag to indicate running state
    std::vector<std::thread> workerThreads_;             ///< Vector of worker threads
};
