/**
 * @file ConfigManager.h
 * @brief Centralized configuration manager singleton - replaces global config variables.
 * 
 * This class encapsulates all configuration data that was previously stored in global variables.
 * It follows the Google C++ Style Guide by avoiding global variables and using a thread-safe
 * singleton pattern instead.
 * 
 * @author Code Refactoring Team
 * @date 2025-11-04
 * @copyright Copyright 2025 Wenzel
 */

#pragma once

#include "broker_base.h"
#include <chrono>
#include <mutex>
#include <string>
#include <nlohmann/json.hpp>

/**
 * @brief Device identity configuration
 */
struct DeviceIdentityConfig {
    std::string product = "ela";             ///< Product identifier
    std::string service = "aag";             ///< Service identifier  
    std::string instance = "0030646e3de2";   ///< Device instance identifier
    std::string static_ip = "10.26.1.20";   ///< Device static IP address
};

/**
 * @brief Audio cache configuration
 */
struct AudioCacheConfig {
    std::string directory = "./audio_cache";     ///< Cache directory path
    size_t max_size_bytes = 2147483648;          ///< Maximum cache size (2GB default)
    std::string file_extension = ".ogg";         ///< Audio file extension
};

/**
 * @brief Scheduler configuration
 */
struct SchedulerConfig {
    int announcement_tick_ms = 500;           ///< Announcement processor tick interval
    int min_sleep_ms = 50;                    ///< Minimum sleep granularity
    int elisa_ack_timeout_seconds = 30;       ///< ELISA acknowledgment timeout
    size_t max_pending_jobs = 4096;           ///< Maximum pending jobs in queue
    bool verbose_logging = true;              ///< Enable verbose logging
    int default_priority = 5;                 ///< Default priority when missing from commands (1-9)
};

/**
 * @brief IPC (Inter-Process Communication) configuration
 */
struct IpcConfig {
    std::string ftok_path = "/tmp/aas_elisa_ipc.key"; ///< Path for ftok key generation
    int proj_id = 65;                                 ///< Project ID for message queue
};

/**
 * @brief Compression configuration
 */
struct CompressionConfig {
    int gzip_window_bits = 31;        ///< GZIP window bits (15 + 16 for gzip header)
    size_t buffer_size_bytes = 32768; ///< Compression buffer size
};

/**
 * @brief AMQP configuration
 */
struct AmqpConfig {
    int channel_id = 1;                      ///< AMQP channel ID
    int max_backoff_seconds = 60;            ///< Maximum backoff time for reconnection
    int watchdog_interval_seconds = 30;      ///< Watchdog check interval
    int reconnect_timeout_seconds = 120;     ///< Inactivity timeout before reconnect
    size_t max_dedup_cache_size = 10000;     ///< Maximum deduplication cache size
    int publish_flags = 0;                   ///< AMQP publish flags (mandatory/immediate)
    int initial_retry_delay_seconds = 1;     ///< Initial retry delay
    int backoff_retry_delay_seconds = 5;     ///< Backoff retry delay
};

/**
 * @brief Certificate configuration
 */
struct CertificateConfig {
    std::string device_id;
    std::string cert_path;
    std::string key_path;
    std::string ott_url;
    std::string ca_bundle_path;
    std::string sign_url;
    std::string renew_url;
    std::string ott_user;
    std::string ott_pass;
    std::string fingerprint;
    int retry_interval_seconds = 300;    ///< Retry interval for certificate operations
    int daily_check_minutes = 5;      ///< Daily check interval 5 mins now (24 hours)
    int ott_retry_minutes = 5;           ///< OTT retry interval
    int renewal_threshold_days = 2;      ///< Days before expiry to trigger renewal
};

/**
 * @brief Complete application configuration
 * 
 * This structure consolidates all configuration data that was previously scattered
 * across global variables and hard-coded constants.
 */
struct AppConfig {
    DeviceIdentityConfig device_identity;
    AudioCacheConfig audio_cache;
    SchedulerConfig scheduler;
    IpcConfig ipc;
    CompressionConfig compression;
    AmqpConfig amqp;
    CertificateConfig certificate;
    BrokerConfig amqp_broker;
    BrokerConfig ppm_broker;
    BrokerConfig tdm_broker;
    bool enable_md5_verification = true;
};

/**
 * @brief Centralized configuration manager singleton.
 * 
 * Replaces global config variables with a thread-safe singleton that provides
 * controlled access to all configuration data. This follows Google C++ Style Guide
 * recommendations for avoiding global variables.
 * 
 * Thread Safety: All public methods are thread-safe.
 */
class ConfigManager {
public:
    /**
     * @brief Gets the singleton instance.
     * 
     * Uses Meyer's singleton pattern which is thread-safe in C++11 and later.
     * 
     * @return Reference to the singleton ConfigManager instance
     */
    static ConfigManager& GetInstance();

    /**
     * @brief Loads configuration from JSON file.
     * 
     * @param config_file_path Path to the configuration JSON file
     * @return true if configuration loaded successfully, false otherwise
     */
    bool LoadFromFile(const std::string& config_file_path);

    /**
     * @brief Gets the complete application configuration.
     * 
     * Thread-safe accessor for the configuration data.
     * 
     * @return const reference to AppConfig
     */
    const AppConfig& GetConfig() const;

    /**
     * @brief Gets device identity configuration.
     * @return const reference to DeviceIdentityConfig
     */
    const DeviceIdentityConfig& GetDeviceIdentity() const;

    /**
     * @brief Gets audio cache configuration.
     * @return const reference to AudioCacheConfig
     */
    const AudioCacheConfig& GetAudioCache() const;

    /**
     * @brief Gets scheduler configuration.
     * @return const reference to SchedulerConfig
     */
    const SchedulerConfig& GetScheduler() const;

    /**
     * @brief Gets IPC configuration.
     * @return const reference to IpcConfig
     */
    const IpcConfig& GetIpc() const;

    /**
     * @brief Gets compression configuration.
     * @return const reference to CompressionConfig
     */
    const CompressionConfig& GetCompression() const;

    /**
     * @brief Gets AMQP configuration.
     * @return const reference to AmqpConfig
     */
    const AmqpConfig& GetAmqp() const;

    /**
     * @brief Gets certificate configuration.
     * @return const reference to CertificateConfig
     */
    const CertificateConfig& GetCertificate() const;

    /**
     * @brief Gets AMQP broker configuration.
     * @return const reference to BrokerConfig
     */
    const BrokerConfig& GetAmqpBroker() const;

    /**
     * @brief Gets PPM broker configuration.
     * @return const reference to BrokerConfig
     */
    const BrokerConfig& GetPpmBroker() const;

    /**
     * @brief Gets TDM broker configuration.
     * @return const reference to BrokerConfig
     */
    const BrokerConfig& GetTdmBroker() const;

    /**
     * @brief Gets MD5 verification flag.
     * @return true if MD5 verification is enabled
     */
    bool IsMd5VerificationEnabled() const;

    /**
     * @brief Sets configuration programmatically (for testing).
     * 
     * @param config The application configuration to set
     */
    void SetConfig(const AppConfig& config);

    // Delete copy constructor and assignment operator
    ConfigManager(const ConfigManager&) = delete;
    ConfigManager& operator=(const ConfigManager&) = delete;

private:
    /**
     * @brief Private constructor for singleton pattern.
     */
    ConfigManager();

    /**
     * @brief Destructor.
     */
    ~ConfigManager() = default;

    /**
     * @brief Loads broker configuration from JSON object.
     * 
     * @param json_broker JSON object containing broker config
     * @param broker_config Output BrokerConfig structure
     */
    void LoadBrokerConfig(const nlohmann::json& json_broker, BrokerConfig& broker_config);

    AppConfig config_;               ///< Application configuration
    mutable std::mutex config_mutex_; ///< Mutex for thread-safe access
};

