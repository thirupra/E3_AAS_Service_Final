# Automatic Announcement Service (AAS) - Release v1.0.0

Release Date: November 7, 2025  
Release Type: Production - First Major Release  
Build Target: E3 AAS Production Test  

## What's New in v1.0.0

This is the first production release of the Automatic Announcement Service (AAS) for IRIS+ platform integration. This release marks a significant milestone in delivering enterprise-grade automatic announcement capabilities.

### Key Features

#### Core System Components
- AMQP Message Processing: Automatic RabbitMQ integration with automatic reconnection and retry mechanisms
- Certificate Management: Automatic mTLS certificate lifecycle with OTT (One-Time Token) support and auto-renewal  
- Audio File Management: Automatic secure HTTPS audio downloading with MD5 verification and LRU caching
- ELISA3 Integration: Automatic System V IPC message queue communication with configurable parameters
- PPM Reporting: Automatic Physical Device Command acknowledgment and status reporting
- TDM Status Feedback: Automatic real-time device state reporting per IRIS+ specification

#### Scheduler & Queue Management  
- Priority-based Scheduling: 9-level priority queue (1=highest, 9=lowest)
- Time-based Execution: Precise announcement timing with microsecond accuracy
- Job Deduplication: Prevents duplicate announcements using composite keys
- Cancellation Support: ANNDEL command processing for job cancellation
- Configurable Timeouts: Flexible timeout settings for all operations

#### Configuration Management
- Centralized Configuration: Single JSON configuration file (`broker_config.json`)
- Runtime Configurability: All timing, sizing, and behavior parameters configurable
- **Environment Flexibility**: Development, testing, and production configurations supported

### Technical Specifications

#### System Requirements
- **Platform**: Linux (Ubuntu 18.04+ recommended)
- **Compiler**: GCC 11+ with C++17 support
- **Dependencies**: 
  - RabbitMQ (AMQP 0.9.1)
  - libcurl with OpenSSL
  - zlib for compression
  - nlohmann/json for JSON processing
  - System V IPC support

#### Performance Characteristics
- **Message Processing**: 500ms scheduler tick (configurable)
- **Concurrent Downloads**: Multi-threaded audio file fetching
- **Memory Footprint**: Configurable queue sizes (default: 4096 pending jobs)
- **Audio Cache**: 2GB default cache with LRU eviction
- **Connection Resilience**: Automatic AMQP reconnection with exponential backoff

### Configuration Highlights

#### Scheduler Parameters (All Configurable)
```json
{
  "announcement_tick_ms": 500,           // How often to check for announcements (milliseconds)
  "min_sleep_ms": 50,                    // Minimum sleep time between checks
  "elisa_ack_timeout_seconds": 30,       // Timeout waiting for ELISA3 acknowledgment
  "max_pending_jobs": 4096,              // Maximum announcements in queue
  "verbose_logging": true,               // Enable detailed logging (false for production)
  "default_priority": 5                  // Default priority for announcements (1-9, 1=highest)
}
```

#### Certificate Management  
- **5-minute retry intervals** for all certificate operations
- **Automatic renewal** with fallback to OTT request
- **Secure key generation** and CSR handling
- **CA bundle validation** and trust establishment

#### IPC Configuration
- **Single message queue** with multiple message types
- **Configurable paths** and project IDs
- **Bidirectional communication** (AAS ↔ ELISA3)

### 🐛 Bug Fixes & Improvements

#### Stability Enhancements
- **Thread-Safe Operations**: All shared data structures properly synchronized
- **Graceful Shutdown**: Signal handling for clean application termination  
- **Memory Management**: Proper resource cleanup and leak prevention
- **Error Handling**: Comprehensive error reporting with detailed logging

#### Message Validation
- **PDCC Compliance**: Full validation per PDCC message specification
- **Timestamp Validation**: Past/future timestamp detection and handling
- **Priority Validation**: Range checking (1-9) with configurable defaults
- **Malformed Message Handling**: Robust parsing with detailed error codes

### Deployment Notes

#### Production Readiness Features
- **Version Identification**: Built-in version reporting in logs and startup banner
- **Configuration Validation**: Startup validation of all configuration parameters
- **Health Monitoring**: Status reporting and error state detection
- **Operational Logging**: Structured logging with configurable levels

#### Security Features
- **mTLS Authentication**: Full mutual TLS with client certificates
- **Secure Downloads**: HTTPS with certificate validation
- **Input Validation**: Comprehensive message validation and sanitization
- **Path Traversal Protection**: Secure file handling and caching

### 📚 Documentation & Support

- **Installation Guide**: Step-by-step deployment instructions
- **Configuration Reference**: Complete parameter documentation
- **API Documentation**: PDCC message format specifications
- **Troubleshooting Guide**: Common issues and resolution steps

### 🔗 Integration Points

#### IRIS+ Platform Integration
- **TDM Compliance**: Full IRIS+ TDM specification compliance
- **PPM Reporting**: Standard Physical Device Command acknowledgments
- **Device Identity**: Configurable product/service/instance identification
- **Status Feedback**: Real-time device state reporting

#### ELISA3 Device Integration  
- **IPC Communication**: Reliable System V message queue interface
- **Protocol Compliance**: ELISA III-IP wire protocol support
- **Error Handling**: Device error detection and reporting
- **Status Monitoring**: Real-time device status tracking

---

## 📦 Installation & Deployment

See `INSTALLATION.md` for detailed deployment instructions.

## Configuration

See `USER_GUIDE.md` for configuration examples and best practices.

## Support

For technical support and questions, please refer to the troubleshooting documentation or contact the development team.

---

**Build Information:**
- Version: 1.0.0
- Build Date: November 7, 2025
- Target: Production Release
- Company: Wenzel  
- Copyright: 2025 Wenzel