# Automatic Announcement Service (AAS) v1.0.0 - Production Release

Enterprise-grade Automatic Announcement Service for IRIS+ Platform Integration

---

## Quick Start

### For Production Deployment
```bash
# 1. Build the application
mkdir build && cd build
cmake .. && make -j$(nproc)

# 2. Run production installer (as root)
sudo ./install.sh

# 3. Configure for your environment
sudo nano /opt/aas/config/broker_config.json

# 4. Start the service
sudo ./aas_service.sh start

# 5. Monitor service
sudo ./aas_service.sh status
sudo ./aas_service.sh follow
```

### For Development/Testing
```bash
# Build and run locally
mkdir build && cd build
cmake .. && make
./process
```

---

## What's Included

### Core Components
- AMQP Message Processor: Automatic RabbitMQ integration with auto-reconnection
- Certificate Manager: Automatic mTLS with OTT support and auto-renewal  
- Audio File Manager: Automatic secure HTTPS download with MD5 verification and LRU caching
- ELISA3 Integration: Automatic System V IPC communication interface
- PPM Reporter: Automatic Physical Device Command acknowledgment system
- Scheduler: Automatic priority-based announcement queue with precise timing

### Production Tools
- `install.sh`: Automated production deployment script
- `aas_service.sh`: Service management and monitoring tools
- Configuration Templates: Development and production config examples
- Test Scripts: Comprehensive testing utilities

### Documentation
- [Release Notes](./RELEASE_NOTES.md): Detailed feature overview and technical specs
- [Installation Guide](./INSTALLATION.md): Step-by-step deployment instructions  
- [User Guide](./USER_GUIDE.md): Configuration, operation, and troubleshooting
- [Build Instructions](#building-from-source): Developer build guide

---

## Building from Source

### Prerequisites
```bash
# Ubuntu/Debian
sudo apt update && sudo apt install -y \
    build-essential cmake \
    libcurl4-openssl-dev libssl-dev zlib1g-dev \
    librabbitmq-dev nlohmann-json3-dev

# CentOS/RHEL
sudo yum groupinstall "Development Tools"
sudo yum install -y cmake openssl-devel libcurl-devel zlib-devel librabbitmq-devel
```

### Build Steps
```bash
# Clone or extract source code
cd E3_AAS_Production_Test

# Create build directory
mkdir build && cd build

# Configure and build
cmake ..
make -j$(nproc)

# Verify build
./process --version  # Should display: AAS v1.0.0
```

### Build Targets
- **`process`**: Main AAS service binary
- **`make install`**: Install to system directories (requires root)
- **`make package`**: Create distribution package (if configured)

---

## Configuration

### Quick Configuration
```bash
# Copy production template
cp broker_config.production.json broker_config.json

# Edit configuration for your environment
nano broker_config.json
```

### Key Configuration Sections

#### Device Identity (Required)
```json
{
  "device_identity": {
    "product": "ela",                // Product type: Electronic Audio (ela)
    "service": "aag",                // Service type: Audio Announcement Gateway (aag)
    "instance": "0030646e3de2",      // Unique device MAC address identifier
    "static_ip": "10.26.1.20"       // Device static IP address on network
  }
}
```

#### AMQP Brokers (Required)
```json
{
  "amqp": { 
    "host": "broker4.gemini",              // AMQP broker hostname for incoming messages
    "username": "wenzel",                  // Authentication username
    "port": 5671,                          // Secure AMQP port (5671 for TLS)
    "exchange": "gemini.pdc",              // Exchange for PDC (Physical Device Control)
    "routing_key": "aas.control.wenzel",   // Routing key for control messages
    "queue_name": "gemini.client.wenzel"   // Queue name for this device
  },
  "ppm": { 
    "host": "broker4.gemini",              // PPM broker hostname for status reports
    "exchange": "gemini.ppm",              // Exchange for PPM (Physical Process Monitor)
    "routing_key": "aas.monitor.wenzel"    // Routing key for monitoring messages
  },
  "tdm_broker": { 
    "host": "broker4.gemini",              // TDM broker hostname for device status
    "exchange": "gemini.tdm",              // Exchange for TDM (Time Division Multiplex)
    "routing_key": "ela.monitor.wenzel"    // Routing key for device monitoring
  }
}
```

#### Certificate Management (Production)
```json
{
  "certificate": {
    "deviceId": "wenzel.irisplus.gemini",     // Unique device identifier for certificates
    "certPath": "./device.crt",              // Path to device certificate file
    "keyPath": "./device.key",               // Path to private key file
    "ottUrl": "https://ott4.gemini:5000",    // One-Time Token server URL for cert requests
    "caBundlePath": "./ca-bundle.crt",       // Path to Certificate Authority bundle
    "signUrl": "https://ca4.gemini:4443",    // CA server URL for certificate signing
    "renewUrl": "https://ca4.gemini:4443"    // CA server URL for certificate renewal
  }
}
```

See **[User Guide](./USER_GUIDE.md)** for complete configuration reference.

---

## Testing

### Test Announcement Processing
```bash
# Start PPM message receiver (terminal 1)
python3 ppm_receiver.py

# Send test announcement (terminal 2)  
python3 test_pdcc_single_annout.py

# Should see: PDCC message processed and PPM response
```

### Test ELISA3 Integration
```bash
# Start ELISA3 simulator (terminal 1)
python3 elisa3_sim.py --ftok-dir /tmp --proj-id 65

# Send announcement that requires ELISA3 (terminal 2)
python3 test_pdcc_single_annout.py

# Should see: IPC communication between AAS and ELISA3
```

### Health Monitoring
```bash
# Check service health
sudo ./aas_service.sh health

# Monitor real-time logs
sudo ./aas_service.sh follow

# View recent activity
sudo ./aas_service.sh logs 100
```

---

## 📁 File Structure

```
E3_AAS_Production_Test/
├── 📄 README.md                    # This file
├── 📄 VERSION                      # Version identifier (1.0.0)
├── 📄 RELEASE_NOTES.md             # Detailed release information
├── 📄 INSTALLATION.md              # Production deployment guide
├── 📄 USER_GUIDE.md                # Operation and configuration guide
├── 🔧 install.sh                   # Production installer script
├── ⚙️ aas_service.sh               # Service management script
├── ⚙️ broker_config.json           # Development configuration  
├── ⚙️ broker_config.production.json # Production configuration template
├── 🏗️ CMakeLists.txt               # Build configuration
├── 📂 src/                         # Source code
├── 📂 include/                     # Header files
├── 📂 External_lib/                # Third-party libraries
├── 🧪 *.py                         # Test and utility scripts
└── 📂 build/                       # Build output (after compilation)
    └── 🎯 process                  # Main executable
```

---

## 🔧 System Requirements

### Minimum Requirements
- **OS**: Linux (Ubuntu 18.04+, CentOS 7+)
- **Architecture**: x86_64  
- **RAM**: 512MB
- **Storage**: 100MB + 2GB for audio cache
- **Network**: AMQP broker connectivity

### Dependencies
- **Runtime**: RabbitMQ, OpenSSL, libcurl, zlib
- **Build**: GCC 11+, CMake 3.16+, C++17 support

---

## 🆘 Support

### Documentation
- **Configuration Issues**: See [User Guide](./USER_GUIDE.md)
- **Installation Problems**: See [Installation Guide](./INSTALLATION.md)  
- **Technical Details**: See [Release Notes](./RELEASE_NOTES.md)

### Quick Troubleshooting
```bash
# Check service status
sudo ./aas_service.sh health

# View error logs
sudo journalctl -u aas -p err --since "1 hour ago"

# Validate configuration
python3 -m json.tool broker_config.json

# Test connectivity
ping broker4.gemini
telnet broker4.gemini 5671
```

### Common Issues
- **Service won't start**: Check configuration syntax and broker connectivity
- **Certificate errors**: Verify OTT server access (ott4.gemini:5000) and certificate paths
- **IPC failures**: Ensure ELISA3 uses same IPC parameters (/tmp/aas_elisa_ipc.key, proj_id=65)
- **AMQP connection failed**: Check credentials and network connectivity to broker4.gemini

---

## 📊 Production Monitoring

### Health Checks
```bash
# Automated health monitoring
sudo ./aas_service.sh health

# Service status
systemctl status aas

# Resource usage  
top -p $(pgrep -f aas_service)
```

### Log Analysis
```bash
# Real-time monitoring
sudo journalctl -u aas -f

# Error analysis
sudo journalctl -u aas -p err --since "today"

# Performance metrics
sudo journalctl -u aas | grep -E "queue|cache|memory"
```

### Performance Tuning
- **High Load**: Increase `announcement_tick_ms` and `max_pending_jobs`
- **Memory Usage**: Reduce `audio_cache.max_size_bytes`
- **Network Issues**: Tune AMQP retry and timeout values

---

## 🔒 Security

### Production Security Checklist
- ✅ Use production certificates (not development/self-signed)
- ✅ Secure credential storage (avoid plaintext passwords)
- ✅ Restrict file permissions (600 for keys, 640 for configs)  
- ✅ Enable firewall rules for required ports only
- ✅ Regular certificate renewal monitoring
- ✅ Log monitoring for security events

### Certificate Management
```bash
# Check certificate expiration
openssl x509 -in /opt/aas/certs/device.crt -noout -dates

# Monitor auto-renewal logs
sudo journalctl -u aas | grep -i "certificate\|renewal\|ott"

# Manual certificate refresh (if needed)
sudo systemctl restart aas
```

---

## Version History

### v1.0.0 (2025-11-07) - Production Release
- First production release with enterprise-grade features
- Complete mTLS integration with OTT certificate management
- Optimized scheduler with configurable priority queues  
- Comprehensive monitoring and health check capabilities
- Production security features and deployment automation
- Complete documentation suite for deployment and operation

---

## License

Copyright 2025 Wenzel. All rights reserved.

This software is proprietary and confidential. Unauthorized copying, distribution, or modification is prohibited.

---

## Credits

Development Team: Wenzel Engineering  
Release Manager: Production Release Team  
Documentation: Technical Writing Team  
Testing: Quality Assurance Team  

---

Ready for Production Deployment

This release has been thoroughly tested and validated for production use. Follow the [Installation Guide](./INSTALLATION.md) for deployment instructions or contact the support team for assistance.