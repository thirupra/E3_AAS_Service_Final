# Automatic Announcement Service (AAS) v1.0.0 - Installation Guide

## Prerequisites

### System Requirements
- **Operating System**: Linux (Ubuntu 18.04+ or CentOS 7+)
- **Architecture**: x86_64
- **RAM**: Minimum 512MB, Recommended 2GB
- **Storage**: 100MB for application + 2GB for audio cache
- **Network**: AMQP broker connectivity required

### Dependencies

#### Build Dependencies
```bash
# Ubuntu/Debian
sudo apt update
sudo apt install -y \
    build-essential \
    cmake \
    libcurl4-openssl-dev \
    libssl-dev \
    zlib1g-dev \
    librabbitmq-dev \
    nlohmann-json3-dev

# CentOS/RHEL
sudo yum groupinstall "Development Tools"
sudo yum install -y cmake openssl-devel libcurl-devel zlib-devel librabbitmq-devel
```

#### Runtime Dependencies
```bash
# Ubuntu/Debian
sudo apt install -y \
    rabbitmq-server \
    openssl \
    curl

# CentOS/RHEL  
sudo yum install -y rabbitmq-server openssl curl
```

## Installation Steps

### 1. Prepare Installation Directory
```bash
# Create installation directory
sudo mkdir -p /opt/aas
sudo chown $USER:$USER /opt/aas
cd /opt/aas

# Create required subdirectories
mkdir -p {bin,config,logs,audio_cache,certs,scripts}
```

### 2. Build the Application
```bash
# Navigate to source directory
cd /path/to/E3_AAS_Production_Test

# Create build directory
mkdir -p build
cd build

# Configure and build
cmake ..
make -j$(nproc)

# Verify build
./process --version  # Should show version 1.0.0
```

### 3. Install Application Files
```bash
# Copy binary
cp process /opt/aas/bin/aas_service

# Copy configuration
cp broker_config.json /opt/aas/config/

# Copy test scripts (optional)
cp *.py /opt/aas/scripts/

# Set permissions
chmod +x /opt/aas/bin/aas_service
chmod +x /opt/aas/scripts/*.py
```

### 4. Configure System Service

#### Create systemd service file
```bash
sudo tee /etc/systemd/system/aas.service << 'EOF'
[Unit]
Description=Audio Announcement System (AAS) v1.0.0
After=network.target rabbitmq-server.service
Wants=rabbitmq-server.service

[Service]
Type=simple
User=aas
Group=aas
WorkingDirectory=/opt/aas
ExecStart=/opt/aas/bin/aas_service
ExecReload=/bin/kill -HUP $MAINPID
KillMode=mixed
KillSignal=SIGTERM
TimeoutStopSec=30
Restart=always
RestartSec=10

# Environment
Environment=AAS_CONFIG_PATH=/opt/aas/config/broker_config.json

# Logging
StandardOutput=journal
StandardError=journal
SyslogIdentifier=aas

# Security
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/opt/aas

[Install]
WantedBy=multi-user.target
EOF
```

#### Create service user
```bash
sudo useradd -r -s /bin/false -d /opt/aas -c "AAS Service User" aas
sudo chown -R aas:aas /opt/aas
```

### 5. Configure Application

#### Update broker_config.json
```bash
cd /opt/aas/config
cp broker_config.json broker_config.json.backup

# Edit configuration for your environment
nano broker_config.json
```

**Key configurations to update:**
- **device_identity**: Update instance ID and static IP
- **certificate paths**: Update to production certificate locations
- **broker URLs**: Update AMQP, PPM, and TDM broker endpoints
- **IPC paths**: Ensure paths are accessible to service user

#### Example production configuration:
```json
#### Example production configuration:
```json
{
  "device_identity": {
    "product": "ela",                // Product type: Electronic Audio (ela)
    "service": "aag",                // Service type: Audio Announcement Gateway (aag)
    "instance": "0030646e3de2",      // Unique device MAC address identifier
    "static_ip": "10.26.1.20"       // Device static IP address on network
  },
  "certificate": {
    "deviceId": "wenzel.irisplus.gemini",     // Unique device identifier for certificates
    "certPath": "./device.crt",              // Path to device certificate file
    "keyPath": "./device.key",               // Path to private key file
    "ottUrl": "https://ott4.gemini:5000",    // One-Time Token server URL for cert requests
    "caBundlePath": "./ca-bundle.crt",       // Path to Certificate Authority bundle
    "signUrl": "https://ca4.gemini:4443",    // CA server URL for certificate signing
    "renewUrl": "https://ca4.gemini:4443"    // CA server URL for certificate renewal
  }
}
```
```

### 6. Setup Certificates

#### For production with real certificates:
```bash
# Copy production certificates
sudo cp your-device.crt /opt/aas/certs/device.crt
sudo cp your-device.key /opt/aas/certs/device.key
sudo cp your-ca-bundle.crt /opt/aas/certs/ca-bundle.crt

# Set permissions
sudo chown aas:aas /opt/aas/certs/*
sudo chmod 640 /opt/aas/certs/*.crt
sudo chmod 600 /opt/aas/certs/*.key
```

#### For development/testing:
```bash
# The application will automatically obtain certificates via OTT
# Ensure OTT server credentials are configured in broker_config.json
```

### 7. Setup RabbitMQ

#### Configure RabbitMQ server:
```bash
# Start RabbitMQ
sudo systemctl enable rabbitmq-server
sudo systemctl start rabbitmq-server

# Create exchanges and queues (if needed)
sudo rabbitmqctl add_user aas_user YOUR_PASSWORD
sudo rabbitmqctl set_permissions -p / aas_user ".*" ".*" ".*"

# Enable management plugin (optional)
sudo rabbitmq-plugins enable rabbitmq_management
```

### 8. Start the Service

```bash
# Reload systemd
sudo systemctl daemon-reload

# Enable and start service
sudo systemctl enable aas
sudo systemctl start aas

# Check status
sudo systemctl status aas

# View logs
sudo journalctl -u aas -f
```

## Verification

### 1. Check Service Status
```bash
sudo systemctl status aas
```

### 2. Verify Log Output
```bash
# Should show version information and successful startup
sudo journalctl -u aas --since "5 minutes ago"
```

### 3. Test AMQP Connectivity
```bash
cd /opt/aas/scripts
python3 test_pdcc_single_annout.py
```

### 4. Check PPM Messages
```bash
cd /opt/aas/scripts
python3 ppm_receiver.py
```

## Configuration Reference

### Important Configuration Sections

#### Device Identity
```json
"device_identity": {
  "product": "ela",                // Product type: Electronic Audio (ela)
  "service": "aag",                // Service type: Audio Announcement Gateway (aag)
  "instance": "0030646e3de2",      // Unique device MAC address identifier
  "static_ip": "10.26.1.20"       // Device static IP address on network
}
```

#### Scheduler Settings
```json
"scheduler": {
  "announcement_tick_ms": 500,           // How often to check for announcements (milliseconds)
  "min_sleep_ms": 50,                    // Minimum sleep time between checks
  "elisa_ack_timeout_seconds": 30,       // Timeout waiting for ELISA3 acknowledgment
  "max_pending_jobs": 4096,              // Maximum announcements in queue
  "verbose_logging": true,               // Enable detailed logging (false for production)
  "default_priority": 5                  // Default priority for announcements (1-9, 1=highest)
}
```

#### IPC Configuration
```json
"ipc": {
  "ftok_path": "/tmp/aas_elisa_ipc.key",   // File path for IPC key generation
  "proj_id": 65                            // Project ID for System V IPC (must match ELISA3)
}
```

## Troubleshooting

### Common Issues

#### Service won't start
- Check permissions on /opt/aas directory
- Verify configuration file syntax
- Check RabbitMQ connectivity
- Review systemd logs: `sudo journalctl -u aas`

#### Certificate issues  
- Verify certificate file permissions
- Check OTT server connectivity
- Validate certificate paths in configuration

#### IPC communication failures
- Ensure ELISA3 simulator is using same IPC parameters
- Check file permissions for IPC token file
- Verify proj_id matches between AAS and ELISA3

### Log Analysis
```bash
# Real-time log monitoring
sudo journalctl -u aas -f

# Show recent errors
sudo journalctl -u aas -p err --since "1 hour ago"

# Show startup sequence  
sudo journalctl -u aas --since "$(systemctl show aas -p ActiveEnterTimestamp --value)"
```

## Maintenance

### Log Rotation
```bash
# Configure logrotate for journal logs
sudo tee /etc/logrotate.d/aas << 'EOF'
/var/log/journal/*/system@aas.service*.journal {
    daily
    rotate 7
    compress
    delaycompress
    missingok
    notifempty
}
EOF
```

### Monitoring
- Monitor service status: `sudo systemctl is-active aas`
- Monitor resource usage: `top -p $(pgrep -f aas_service)`
- Monitor logs for errors: `sudo journalctl -u aas -p err --since "today"`

### Updates
1. Stop service: `sudo systemctl stop aas`
2. Replace binary: `cp new_binary /opt/aas/bin/aas_service`
3. Update configuration if needed
4. Start service: `sudo systemctl start aas`

---

For additional support, refer to the troubleshooting documentation or contact the development team.