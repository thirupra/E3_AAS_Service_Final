/**
 * @file CertificateModule.cpp
 * @brief Implements the CertificateModule for handling CA, OTT, certificate issuance, and renewal flows.
 *
 * This module is a core component for secure device communication. It manages the full lifecycle
 * of a client certificate used for authentication, from initial acquisition to
 * daily renewal. The implementation relies on external commands like `curl` and `openssl`
 * for cryptographic and network operations.
 *
 * This module handles:
 * - **CA Bundle Management**: Downloads and validates the root CA bundle to establish trust.
 * - **One-Time Token (OTT) Requests**: Authenticates with a server to obtain a temporary token for certificate signing.
 * - **Key and CSR Generation**: Creates a private key and a Certificate Signing Request (CSR) to submit for signing.
 * - **Certificate Issuance**: Requests a signed client certificate from the CA server.
 * - **Certificate Renewal**: Attempts to renew the certificate daily using the Step CLI tool, with a fallback
 * to a full OTT-based request if renewal fails.
 * - **Lifecycle Management**: Provides a daily renewal loop that runs continuously and supports a
 * graceful shutdown via signals.
 *
 * @author Thirupathi Rao
 * @date 2025-09-04
 */

#include "certificate_module.h"
#include "log_manager.h"
#include "config_manager.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <array>
#include <thread>
#include <chrono>
#include <openssl/x509.h>
#include <openssl/pem.h>
#include <openssl/evp.h>
#include <openssl/sha.h>
#include <iomanip>
#include <sys/stat.h>
#include <ctime>
#include <cstring>
#include <csignal>
#include <atomic>
#include <vector>
#include <algorithm>

/**
 * @brief Checks if a file exists at the given path.
 *
 * @param path The file path to check.
 * @return `true` if the file exists and is accessible, `false` otherwise.
 */
static bool file_exists(const std::string& path) {
    struct stat buf;
    return stat(path.c_str(), &buf) == 0;
}

/**
 * @brief Downloads the CA bundle from the OTT endpoint if it does not already exist.
 *
 * This method uses a `curl` command to fetch the CA bundle from the specified
 * URL. It checks for the existence of the file first to avoid redundant downloads.
 *
 * @return `true` if the CA bundle is successfully downloaded or already exists, `false` on failure.
 */
bool CertificateModule::DownloadCABundle() {
    if (file_exists(caBundlePath_)) {
        LOG_INFO("CA bundle found: " + caBundlePath_);
        return true;
    }
    LOG_DEBUG("Downloading CA bundle...");
    std::ostringstream cmd;
    cmd << "curl -s -k " << ottUrl_ << "/roots | jq -r .crts[] > " << caBundlePath_;
    return RunCommand(cmd.str());
}

/**
 * @brief Constructor for CertificateModule.
 *
 * Initializes all the necessary paths, URLs, and credentials for certificate
 * management. It sets the initial state of the module to invalid until a
 * valid certificate is acquired.
 * 
 * @param deviceId Unique device identifier used in certificate CN
 * @param certPath Path where the certificate file will be stored
 * @param keyPath Path where the private key will be stored
 * @param ottUrl URL endpoint for requesting one-time tokens
 * @param caBundlePath Path where the CA bundle will be stored
 * @param signUrl URL endpoint for certificate signing requests
 * @param renewUrl URL endpoint for certificate renewal requests
 * @param ottUser Username for OTT authentication
 * @param ottPass Password for OTT authentication
 * @param expectedFingerprint Expected CA certificate fingerprint for validation
 */
CertificateModule::CertificateModule(const std::string& deviceId,
        const std::string& certPath,
        const std::string& keyPath,
        const std::string& ottUrl,
        const std::string& caBundlePath,
        const std::string& signUrl,
        const std::string& renewUrl,
        const std::string& ottUser,
        const std::string& ottPass,
        const std::string& expectedFingerprint)
    : deviceId_(deviceId),
      certPath_(certPath),
      keyPath_(keyPath),
      ottUrl_(ottUrl),
      caBundlePath_(caBundlePath),
      signUrl_(signUrl),
      renewUrl_(renewUrl),
      ottUser_(ottUser),
      ottPass_(ottPass),
      expectedFingerprint_(expectedFingerprint),
      isValid_(false) {}

/**
 * @brief Destructor for CertificateModule.
 * 
 * Cleans up any resources if needed.
 */
CertificateModule::~CertificateModule() {}

/**
 * @brief Initializes the CertificateModule.
 *
 * Downloads the CA bundle and ensures a valid certificate exists or creates one if needed.
 * The initialization process follows these steps:
 * 1. Download the CA bundle if it doesn't exist
 * 2. Validate the CA bundle fingerprint if expected fingerprint is provided
 * 3. Validate the existing certificate if any
 * 4. If no valid certificate exists, request a new one
 * 5. If a valid certificate exists but is near expiry, attempt to renew it
 * 6. If renewal fails, fall back to requesting a new certificate
 *
 * @return `true` if initialization succeeds and a valid certificate is available, `false` otherwise.
 */
bool CertificateModule::Init() {
    if (!DownloadCABundle()) {
        LOG_ERROR("CA bundle download failed!");
        return false;
    }

    // Validate CA bundle fingerprint if expected fingerprint is provided
    if (!ValidateCAFingerprint()) {
        std::cerr << "[ERROR] CA bundle fingerprint validation failed!" << std::endl;
        return false;
    }

    if (!ValidateCert()) {
        LOG_INFO("No valid certificate found; requesting new certificate...");
        if (!RequestCertificateFlow()) return false;
    } else {
        if (!RenewCert()) {
            LOG_WARNING("Renewal failed; requesting new certificate...");
            if (!RequestCertificateFlow()) return false;
        }
    }

    isValid_ = true;
    return true;
}

/**
 * @brief Orchestrates the full certificate request flow using OTT.
 * 
 * This method coordinates the three main steps of certificate acquisition:
 * 1. Requesting a one-time token (OTT) from the authentication server
 * 2. Generating a certificate signing request (CSR) with the device's private key
 * 3. Submitting the CSR along with the OTT to obtain a signed certificate
 * 
 * @return `true` if all steps succeed and a valid certificate is obtained, `false` if any step fails.
 */
bool CertificateModule::RequestCertificateFlow() {
    std::string ott = RequestOTT();
    if (ott.empty()) return false;
    std::string csr = GenerateCSR();
    if (csr.empty()) return false;
    if (!SignCert(csr, ott)) return false;
    return true;
}

/**
 * @brief De-initializes the module.
 * 
 * Currently a placeholder for any cleanup operations that might be needed when
 * shutting down the certificate module.
 */
void CertificateModule::Deinit() {}

/**
 * @brief Renews the certificate using Step CLI or falls back to OTT flow.
 * 
 * This method first checks if renewal is needed by verifying if the certificate
 * is near its expiry date. If renewal is needed, it attempts to use the Step CLI
 * tool for a streamlined renewal process. If that fails, it falls back to generating
 * a new key and CSR, then requesting a new certificate using the OTT flow.
 *
 * @return `true` if the certificate is successfully renewed or doesn't need renewal,
 *         `false` if renewal is needed but fails.
 */
bool CertificateModule::RenewCert() {
    // reset flag at start
    lastRenewalPerformed_ = false;

    const int renewal_threshold = ConfigManager::GetInstance().GetCertificate().renewal_threshold_days;
    if (!IsCertNearExpiry(renewal_threshold)) {
        LOG_INFO("Certificate is not near expiry. Skipping renewal.");
        return true;
    }

    LOG_INFO("Attempting certificate renewal...");

    std::string renewCmd = "step ca renew " + certPath_ + " " + keyPath_ +
                           " --ca-url " + signUrl_ +
                           " --root " + caBundlePath_ +
                           " --force";

    LOG_DEBUG("Running command: " + renewCmd);
    if (RunCommand(renewCmd)) {
        if (ValidateCert()) {
            lastRenewalPerformed_ = true; // actual renewal happened
            LOG_INFO("[SUCCESS] Certificate renewed successfully.");
            return true;
        }
    }

    LOG_WARNING("Renewal failed; requesting new certificate with OTT...");

    // If renewal failed but the existing certificate is still valid, skip OTT issuance.
    if (ValidateCert()) {
        LOG_INFO("Existing certificate still valid after failed renewal; skipping OTT issuance.");
        lastRenewalPerformed_ = false; // no renewal performed
        return true;
    }
    
    std::string csrPath = certPath_ + ".csr";
    // Client requested RSA key
    std::string keyCmd = "openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:3072 -out " + keyPath_;
    std::string subject = "/C=DE/ST=Berlin/L=Berlin/O=Demo Org/OU=Development/CN=" + deviceId_;
    std::string csrCmd = "openssl req -new -key " + keyPath_ + " -out " + csrPath + " -subj \"" + subject + "\"";

    if (!RunCommand(keyCmd) || !RunCommand(csrCmd)) {
        std::cerr << "[ERROR] Failed to generate new key/CSR for OTT." << std::endl;
        lastRenewalPerformed_ = false;
        return false;
    }

    std::string ott = RequestOTT();
    if (ott.empty()) {
        lastRenewalPerformed_ = false;
        return false;
    }

    std::string stepCmd = "step ca certificate " + deviceId_ + " " + certPath_ + " " + keyPath_ +
                          " --token " + ott +
                          " --ca-url " + signUrl_ +
                          " --root " + caBundlePath_ +
                          " --provisioner \"Automatic Certificate Management Environment\" --force";

    if (!RunCommand(stepCmd)) {
        lastRenewalPerformed_ = false;
        return false;
    }

    // If the new certificate is now valid, mark that we performed a renewal/issuance
    bool ok = ValidateCert();
    lastRenewalPerformed_ = ok;
    return ok;
}

/**
 * @brief Validates the existing certificate.
 * 
 * Checks if the certificate exists and is currently valid (not expired).
 * The validation process includes:
 * 1. Verifying the certificate file exists and is accessible
 * 2. Extracting the expiration date using OpenSSL
 * 3. Converting the date to a Unix timestamp
 * 4. Comparing the timestamp to the current time
 *
 * @return `true` if the certificate exists and has not expired, `false` otherwise.
 */
bool CertificateModule::ValidateCert() {
    std::ifstream certFile(certPath_);
    if (!certFile.good()) return false;
    certFile.close();

    std::ostringstream cmd;
    cmd << "openssl x509 -in " << certPath_ << " -noout -enddate";
    std::string output = RunCommandCapture(cmd.str());
    if (output.empty()) return false;

    const std::string prefix = "notAfter=";
    auto pos = output.find(prefix);
    if (pos == std::string::npos) return false;

    std::string dateStr = output.substr(pos + prefix.length());
    std::ostringstream dateCmd;
    dateCmd << "date -d \"" << dateStr << "\" +%s";
    std::string epochStr = RunCommandCapture(dateCmd.str());
    if (epochStr.empty()) return false;

    time_t expiry_time = std::stoll(epochStr);
    time_t now = std::time(nullptr);

    if (expiry_time <= now) return false;
    LOG_INFO("Certificate is valid until: " + dateStr);
    return true;
}

/**
 * @brief Requests a One-Time Token (OTT) from the server.
 * 
 * This method authenticates with the OTT server using the configured credentials
 * and requests a one-time token that can be used to sign a certificate. The method
 * will retry at regular intervals if the request fails, and will persist the token
 * to a file for potential later use.
 *
 * @return The one-time token as a string if successful, an empty string if all retries fail.
 */
std::string CertificateModule::RequestOTT() {
    LOG_DEBUG("Requesting OTT...");
    std::string ott;
    const int RETRY_INTERVAL = ConfigManager::GetInstance().GetCertificate().retry_interval_seconds;
    const std::string ottFile = certPath_ + ".ott";

    while (ott.empty()) {
        std::ostringstream ott_cmd;
        ott_cmd << "curl -s -w \"%{http_code}\" -o /tmp/ott_response.json -k "
                << "-u " << ottUser_ << ":" << ottPass_ << " "
                << "-X POST " << ottUrl_ << "/otts "
                << "-H \"Content-Type: application/json\" "
                << "-d '{\"deviceID\":\"" << deviceId_ << "\"}'";
        LOG_DEBUG("Executing OTT request command: " + ott_cmd.str());

        std::string http_output = RunCommandCapture(ott_cmd.str());
        if (http_output.size() < 3) {
            LOG_ERROR("OTT request failed - network/connection issue (no HTTP response). Will retry in " + std::to_string(RETRY_INTERVAL) + " seconds...");
            std::this_thread::sleep_for(std::chrono::seconds(RETRY_INTERVAL));
            continue;
        }

        std::string http_code = http_output.substr(http_output.size() - 3);
        LOG_DEBUG("OTT request HTTP response code: " + http_code);
        
        if (http_code == "200") {
            LOG_INFO("[SUCCESS] OTT request successful - HTTP 200 received");
            std::string jq_cmd = "jq -r '.ott' /tmp/ott_response.json";
            ott = RunCommandCapture(jq_cmd);
            if (!ott.empty() && ott != "null") {
                LOG_INFO("✓ OTT token successfully obtained and validated");
                std::ofstream out(ottFile);
                if (out.is_open()) { out << ott; out.close(); }
                break;
            } else {
                LOG_ERROR("HTTP 200 received but OTT token is empty or null in response");
                std::this_thread::sleep_for(std::chrono::seconds(RETRY_INTERVAL));
            }
        } else if (http_code == "500") {
            LOG_ERROR("[ERROR 500] OTT service internal server error - HTTP 500 received."+ std::to_string(RETRY_INTERVAL) + " seconds...");
            std::this_thread::sleep_for(std::chrono::seconds(RETRY_INTERVAL));
        } else {
            LOG_ERROR("OTT request failed with HTTP code: " + http_code + ". Will retry in " + std::to_string(RETRY_INTERVAL) + " seconds...");
            std::this_thread::sleep_for(std::chrono::seconds(RETRY_INTERVAL));
        }
        LOG_WARNING("Waiting" + std::to_string(RETRY_INTERVAL) + " seconds..." + "before next OTT retry attempt...");
    }
    return ott;
}

/**
 * @brief Generates an RSA private key and CSR.
 * 
 * Creates a 3072-bit RSA private key and generates a Certificate Signing Request (CSR)
 * with the device ID as the Common Name (CN). Both operations use the OpenSSL command
 * line tools.
 *
 * @return The path to the generated CSR file if successful, an empty string if either
 *         key or CSR generation fails.
 */
std::string CertificateModule::GenerateCSR() {
    std::string gen_key_cmd = "openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:3072 -out " + keyPath_;
    std::string subject = "/C=DE/ST=Berlin/L=Berlin/O=Demo Org/OU=Development/CN=" + deviceId_;
    std::string gen_csr_cmd = "openssl req -new -key " + keyPath_ + " -out " + certPath_ + ".csr -subj \"" + subject + "\"";

    if (!RunCommand(gen_key_cmd) || !RunCommand(gen_csr_cmd)) return "";

    LOG_INFO("RSA private key and CSR generated: " + keyPath_ + ", " + certPath_ + ".csr");
    return certPath_ + ".csr";
}

/**
 * @brief Signs the CSR using the provided OTT.
 * 
 * Submits the CSR to the CA server along with the one-time token (OTT) to obtain
 * a signed certificate. Uses the Step CLI tool to handle the signing process.
 *
 * @param csr Path to the Certificate Signing Request file (unused in current implementation)
 * @param ott One-time token obtained from the OTT server
 * @return `true` if the signing process succeeds and a valid certificate is obtained,
 *         `false` if an error occurs during the process.
 */
bool CertificateModule::SignCert(const std::string&, const std::string& ott) {
    std::string cmd = "step ca certificate " + deviceId_ + " " + certPath_ + " " + keyPath_ +
                      " --token " + ott +
                      " --ca-url " + signUrl_ +
                      " --root " + caBundlePath_ +
                      " --provisioner \"Automatic Certificate Management Environment\" --force";
    std::string output = RunCommandCapture(cmd);
    return !output.empty() && output.find("error") == std::string::npos;
}

/**
 * @brief Checks if certificate is near expiry.
 * 
 * Opens the certificate file, extracts the expiration date, and calculates
 * the number of days remaining until expiry. This uses the OpenSSL library
 * directly rather than command-line tools.
 *
 * @param daysThreshold The threshold in days before expiry to trigger renewal
 * @return `true` if the certificate will expire within the specified threshold or
 *         doesn't exist, `false` if it's valid beyond the threshold.
 */
bool CertificateModule::IsCertNearExpiry(int daysThreshold) {
    FILE* fp = fopen(certPath_.c_str(), "r");
    if (!fp) return true;
    X509* cert = PEM_read_X509(fp, nullptr, nullptr, nullptr);
    fclose(fp);
    if (!cert) return true;

    ASN1_TIME* notAfter = X509_get_notAfter(cert);
    BIO* bio = BIO_new(BIO_s_mem());
    ASN1_TIME_print(bio, notAfter);
    char buffer[64]{};
    BIO_read(bio, buffer, sizeof(buffer) - 1);
    BIO_free(bio);

    struct tm tm_expiry{};
    strptime(buffer, "%b %e %H:%M:%S %Y GMT", &tm_expiry);
    time_t expiry_time = mktime(&tm_expiry);
    X509_free(cert);

    double days_to_expiry = difftime(expiry_time, time(nullptr)) / (60 * 60 * 24);
    return (days_to_expiry < daysThreshold);
}

/**
 * @brief Validates the CA bundle against the expected fingerprint.
 * 
 * If an expected fingerprint is configured, this method calculates the SHA256
 * fingerprint of the CA bundle and compares it with the expected value.
 * If no expected fingerprint is configured, validation passes.
 *
 * @return `true` if fingerprint matches expected value or no fingerprint configured, 
 *         `false` if fingerprint doesn't match.
 */
bool CertificateModule::ValidateCAFingerprint() {
    // If no expected fingerprint is configured, skip validation
    if (expectedFingerprint_.empty()) {
        LOG_INFO("No expected fingerprint configured, skipping CA fingerprint validation.");
        return true;
    }

    if (!file_exists(caBundlePath_)) {
        LOG_ERROR("CA bundle file does not exist: " + caBundlePath_);
        return false;
    }

    std::string actualFingerprint = CalculateCertFingerprint(caBundlePath_);
    if (actualFingerprint.empty()) {
        LOG_ERROR("Failed to calculate CA bundle fingerprint.");
        return false;
    }

    // Convert both fingerprints to lowercase for comparison
    std::string expectedLower = expectedFingerprint_;
    std::string actualLower = actualFingerprint;
    std::transform(expectedLower.begin(), expectedLower.end(), expectedLower.begin(), ::tolower);
    std::transform(actualLower.begin(), actualLower.end(), actualLower.begin(), ::tolower);

    if (expectedLower == actualLower) {
        LOG_INFO("CA bundle fingerprint validation successful.");
        LOG_DEBUG("Expected: " + expectedFingerprint_);
        LOG_DEBUG("Actual: " + actualFingerprint);
        return true;
    } else {
        LOG_ERROR("CA bundle fingerprint mismatch!");
        LOG_ERROR("Expected: " + expectedFingerprint_);
        LOG_ERROR("Actual: " + actualFingerprint);
        return false;
    }
}

/**
 * @brief Calculates the SHA256 fingerprint of a certificate file.
 * 
 * Reads the certificate file and computes its SHA256 hash, returning it
 * as a hexadecimal string. This can be used to verify certificate integrity.
 * Uses the modern OpenSSL 3.0+ EVP API.
 *
 * @param certPath Path to the certificate file
 * @return SHA256 fingerprint as lowercase hex string, empty string on failure
 */
std::string CertificateModule::CalculateCertFingerprint(const std::string& certPath) {
    FILE* fp = fopen(certPath.c_str(), "rb");
    if (!fp) {
        LOG_ERROR("Failed to open certificate file: " + certPath);
        return "";
    }

    // Read the entire file
    fseek(fp, 0, SEEK_END);
    long fileSize = ftell(fp);
    fseek(fp, 0, SEEK_SET);

    if (fileSize <= 0) {
        fclose(fp);
        LOG_ERROR("Certificate file is empty or invalid: " + certPath);
        return "";
    }

    std::vector<unsigned char> buffer(fileSize);
    size_t bytesRead = fread(buffer.data(), 1, fileSize, fp);
    fclose(fp);

    if (bytesRead != static_cast<size_t>(fileSize)) {
        LOG_ERROR("Failed to read complete certificate file: " + certPath);
        return "";
    }

    // Use modern EVP API for SHA256
    EVP_MD_CTX* ctx = EVP_MD_CTX_new();
    if (!ctx) {
        LOG_ERROR("Failed to create EVP context");
        return "";
    }

    if (EVP_DigestInit_ex(ctx, EVP_sha256(), nullptr) != 1) {
        EVP_MD_CTX_free(ctx);
        LOG_ERROR("Failed to initialize SHA256 digest");
        return "";
    }

    if (EVP_DigestUpdate(ctx, buffer.data(), bytesRead) != 1) {
        EVP_MD_CTX_free(ctx);
        LOG_ERROR("Failed to update SHA256 digest");
        return "";
    }

    unsigned char hash[EVP_MAX_MD_SIZE];
    unsigned int hashLen = 0;
    if (EVP_DigestFinal_ex(ctx, hash, &hashLen) != 1) {
        EVP_MD_CTX_free(ctx);
        LOG_ERROR("Failed to finalize SHA256 digest");
        return "";
    }

    EVP_MD_CTX_free(ctx);

    // Convert to hex string
    std::ostringstream hexStream;
    for (unsigned int i = 0; i < hashLen; i++) {
        hexStream << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(hash[i]);
    }

    return hexStream.str();
}

/**
 * @brief Runs the 24-hour renewal loop.
 *
 * This method implements an infinite loop that periodically checks and renews
 * certificates. The loop will:
 * 1. Check if the certificate is valid
 * 2. If invalid, request a new certificate
 * 3. If valid but near expiry (2 days), attempt to renew it
 * 4. Sleep for 24 hours before re-checking, allowing graceful shutdown via running_.load()
 */
void CertificateModule::RunDailyRenewalLoop() {
    // Get configurable intervals from config
    const int kDailyCheckMinutes = ConfigManager::GetInstance().GetCertificate().daily_check_minutes;
    const int kOttRetryMinutes = ConfigManager::GetInstance().GetCertificate().ott_retry_minutes; 

    while (running_.load()) {
        // Check certificate validity
        bool certValid = ValidateCert();
        if (!certValid) {
            LOG_WARNING("⚠️ Certificate missing or invalid. Secure operations will be disabled until a valid certificate is obtained.");
            isValid_ = false;

            // Try to obtain a new certificate but do not stop the app if it fails
            if (RequestCertificateFlow()) {
                isValid_ = true;
                LOG_INFO("Obtained new certificate - secure features enabled.");
            } else {
                LOG_ERROR("Failed to obtain new certificate. Will keep retrying in background; AAS continues to operate with reduced secure features.");
            }
        } else {
            // Certificate currently valid
            isValid_ = true;

            // Warn and attempt renewal if close to expiry
            const int renewal_threshold = ConfigManager::GetInstance().GetCertificate().renewal_threshold_days;
            if (IsCertNearExpiry(renewal_threshold)) {
                LOG_WARNING("⚠️ Certificate is near expiry. Attempting renewal...");
                if (RenewCert()) {
                    LOG_DEBUG(std::string("RenewCert() returned true. lastRenewalPerformed_=") + (lastRenewalPerformed_ ? "true" : "false"));
                    if (lastRenewalPerformed_) {
                        LOG_INFO("✅ Certificate renewed successfully.");
                    } else {
                        LOG_INFO("No renewal performed because existing certificate remains valid.");
                    }
                    isValid_ = true;
                } else {
                    LOG_ERROR("RenewCert() returned false. lastRenewalPerformed_=" + std::string(lastRenewalPerformed_ ? "true" : "false"));
                    // Renewal (step ca renew) failed. If the existing cert is still valid we keep using it,
                    // but attempt OTT-based issuance periodically (every kOttRetryMinutes) until success or cert becomes invalid.
                    if (ValidateCert()) {
                        LOG_INFO("Will continue using existing certificate and retry OTT-based issuance every " + std::to_string(kOttRetryMinutes) + " minute(s) until success or expiry.");

                        // Retry loop: attempt OTT issuance periodically while certificate remains valid
                        while (running_.load() && ValidateCert()) {
                            LOG_DEBUG("Attempting OTT-based issuance retry...");
                            if (RequestCertificateFlow()) {
                                LOG_INFO("✅ OTT-based issuance succeeded during retry.");
                                isValid_ = true;
                                break;
                            }
                            LOG_WARNING("OTT retry failed; sleeping for " + std::to_string(kOttRetryMinutes) + " minute(s) before next attempt...");
                            for (int i = 0; i < kOttRetryMinutes && running_.load(); ++i) {
                                std::this_thread::sleep_for(std::chrono::minutes(1));
                            }
                        }

                        // If we exited because certificate became invalid, try an immediate issuance (will block briefly)
                        if (running_.load() && !ValidateCert()) {
                            LOG_WARNING("Certificate became invalid during retries; attempting immediate OTT issuance...");
                            if (RequestCertificateFlow()) {
                                LOG_INFO("Immediate OTT issuance succeeded.");
                                isValid_ = true;
                            } else {
                                LOG_ERROR("Immediate OTT issuance failed; will resume background retries.");
                            }
                        }
                    } else {
                        // Cert invalid after failed renewal: attempt immediate OTT issuance
                        LOG_ERROR("Certificate invalid after failed renewal; attempting immediate OTT issuance...");
                        if (RequestCertificateFlow()) {
                            isValid_ = true;
                            LOG_INFO("Immediate OTT issuance succeeded.");
                        } else {
                            LOG_ERROR("Immediate OTT issuance failed; will retry in background.");
                        }
                    }
                }
            }
        }

        // Sleep ~24 hours, checking running_.load() every minute to allow prompt shutdown
        for (int i = 0; i < kDailyCheckMinutes && running_.load(); ++i) {
            std::this_thread::sleep_for(std::chrono::minutes(1));
        }
    }
}

/**
 * @brief Executes a shell command and checks its exit code.
 * 
 * Runs the specified command using the system shell and returns whether it
 * completed successfully.
 *
 * @param cmd The command to execute
 * @return `true` if the command executed with exit code 0, `false` otherwise.
 */
bool CertificateModule::RunCommand(const std::string& cmd) {
    return std::system(cmd.c_str()) == 0;
}

/**
 * @brief Executes a shell command and captures stdout and stderr.
 * 
 * Runs the specified command using popen to capture its output. Both stdout
 * and stderr are captured and returned as a single string.
 *
 * @param cmd The command to execute
 * @return The captured output (stdout and stderr) as a string, or an empty string on failure.
 */
std::string CertificateModule::RunCommandCapture(const std::string& cmd) {
    std::array<char, 256> buffer{};
    std::string result;
    FILE* pipe = popen((cmd + " 2>&1").c_str(), "r");
    if (!pipe) return "";
    while (fgets(buffer.data(), buffer.size(), pipe) != nullptr) result += buffer.data();
    pclose(pipe);
    if (!result.empty() && result.back() == '\n') result.pop_back();
    return result;
}

/**
 * @brief Getters for certificate, key, CA, and device ID.
 * 
 * @return The path to the valid certificate, or an empty string if not valid.
 */
std::string CertificateModule::GetValidCert() const { return isValid_ ? certPath_ : ""; }

/**
 * @brief Get the path to the private key file.
 * 
 * @return The absolute path to the private key file.
 */
std::string CertificateModule::GetKeyPath() const { return keyPath_; }

/**
 * @brief Get the path to the CA bundle file.
 * 
 * @return The absolute path to the CA bundle file.
 */
std::string CertificateModule::GetCABundlePath() const { return caBundlePath_; }

/**
 * @brief Get the device identifier used for certificate CN.
 * 
 * @return The device ID string.
 */
std::string CertificateModule::GetDeviceId() const { return deviceId_; }

/**
 * @brief Check if renewal loop is running.
 * @return true if running, false otherwise
 */
bool CertificateModule::IsRunning() const {
    return running_.load();
}
