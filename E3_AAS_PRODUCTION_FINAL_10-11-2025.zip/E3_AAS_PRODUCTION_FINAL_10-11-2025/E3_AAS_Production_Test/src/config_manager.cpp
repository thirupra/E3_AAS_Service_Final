/**
 * @file ConfigManager.cpp
 * @brief Implementation of centralized configuration manager singleton.
 * 
 * Replaces global configuration variables with a thread-safe singleton that
 * loads and provides access to all application configuration data.
 * 
 * @author Code Refactoring Team
 * @date 2025-11-04
 * @copyright Copyright 2025 Wenzel
 */

#include "config_manager.h"
#include "log_manager.h"
#include <nlohmann/json.hpp>
#include <fstream>
#include <sstream>

using json = nlohmann::json;

ConfigManager::ConfigManager() {
    // Initialize with default values (already set in struct definitions)
}

ConfigManager& ConfigManager::GetInstance() {
    static ConfigManager instance;
    return instance;
}

bool ConfigManager::LoadFromFile(const std::string& config_file_path) {
    std::lock_guard<std::mutex> lock(config_mutex_);

    try {
        std::ifstream file(config_file_path);
        if (!file.is_open()) {
            LOG_ERROR("Failed to open config file: " + config_file_path);
            return false;
        }

        json config_json;
        file >> config_json;
        file.close();

        // Load device identity
        if (config_json.contains("device_identity")) {
            const auto& identity = config_json["device_identity"];
            config_.device_identity.product = identity.value("product", "ela");
            config_.device_identity.service = identity.value("service", "aag");
            config_.device_identity.instance = identity.value("instance", "0030646e3de2");
            config_.device_identity.static_ip = identity.value("static_ip", "10.26.1.20");
        }

        // Load audio cache configuration
        if (config_json.contains("audio_cache")) {
            const auto& cache = config_json["audio_cache"];
            config_.audio_cache.directory = cache.value("directory", "./audio_cache");
            config_.audio_cache.max_size_bytes = cache.value("max_size_bytes", 2147483648ULL);
            config_.audio_cache.file_extension = cache.value("file_extension", ".ogg");
        }

        // Load scheduler configuration
        if (config_json.contains("scheduler")) {
            const auto& sched = config_json["scheduler"];
            config_.scheduler.announcement_tick_ms = sched.value("announcement_tick_ms", 500);
            config_.scheduler.min_sleep_ms = sched.value("min_sleep_ms", 50);
            config_.scheduler.elisa_ack_timeout_seconds = sched.value("elisa_ack_timeout_seconds", 30);
            config_.scheduler.max_pending_jobs = sched.value("max_pending_jobs", 4096);
            config_.scheduler.verbose_logging = sched.value("verbose_logging", true);
            config_.scheduler.default_priority = sched.value("default_priority", 5);
        }

        // Load IPC configuration
        if (config_json.contains("ipc")) {
            const auto& ipc = config_json["ipc"];
            config_.ipc.ftok_path = ipc.value("ftok_path", "/tmp/aas_elisa_ipc.key");
            config_.ipc.proj_id = ipc.value("proj_id", 65);
        }

        // Load compression configuration
        if (config_json.contains("compression")) {
            const auto& comp = config_json["compression"];
            config_.compression.gzip_window_bits = comp.value("gzip_window_bits", 31);
            config_.compression.buffer_size_bytes = comp.value("buffer_size_bytes", 32768);
        }

        // Load AMQP configuration
        if (config_json.contains("amqp_config")) {
            const auto& amqp = config_json["amqp_config"];
            config_.amqp.channel_id = amqp.value("channel_id", 1);
            config_.amqp.max_backoff_seconds = amqp.value("max_backoff_seconds", 60);
            config_.amqp.watchdog_interval_seconds = amqp.value("watchdog_interval_seconds", 30);
            config_.amqp.reconnect_timeout_seconds = amqp.value("reconnect_timeout_seconds", 120);
            config_.amqp.max_dedup_cache_size = amqp.value("max_dedup_cache_size", 10000);
            config_.amqp.publish_flags = amqp.value("publish_flags", 0);
            config_.amqp.initial_retry_delay_seconds = amqp.value("initial_retry_delay_seconds", 1);
            config_.amqp.backoff_retry_delay_seconds = amqp.value("backoff_retry_delay_seconds", 5);
        }

        // Load certificate configuration
        if (config_json.contains("certificate")) {
            const auto& cert = config_json["certificate"];
            config_.certificate.device_id = cert.value("deviceId", "");
            config_.certificate.cert_path = cert.value("certPath", "");
            config_.certificate.key_path = cert.value("keyPath", "");
            config_.certificate.ott_url = cert.value("ottUrl", "");
            config_.certificate.ca_bundle_path = cert.value("caBundlePath", "");
            config_.certificate.sign_url = cert.value("signUrl", "");
            config_.certificate.renew_url = cert.value("renewUrl", "");
            config_.certificate.ott_user = cert.value("ottUser", "");
            config_.certificate.ott_pass = cert.value("ottPass", "");
            config_.certificate.fingerprint = cert.value("fingerprint", "");
            config_.certificate.retry_interval_seconds = cert.value("retry_interval_seconds", 300);
            config_.certificate.daily_check_minutes = cert.value("daily_check_minutes", 5);
            config_.certificate.ott_retry_minutes = cert.value("ott_retry_minutes", 5);
            config_.certificate.renewal_threshold_days = cert.value("renewal_threshold_days", 2);
        }

        // Load broker configurations
        if (config_json.contains("amqp")) {
            LoadBrokerConfig(config_json["amqp"], config_.amqp_broker);
        }

        if (config_json.contains("ppm")) {
            LoadBrokerConfig(config_json["ppm"], config_.ppm_broker);
        }

        if (config_json.contains("tdm_broker")) {
            LoadBrokerConfig(config_json["tdm_broker"], config_.tdm_broker);
        }

        // Load MD5 verification flag
        config_.enable_md5_verification = config_json.value("enable_md5_verification", true);

        LOG_INFO("╔════════════════════════════════════════════════════════════════╗");
        LOG_INFO("║    Configuration loaded successfully from: " + config_file_path);
        LOG_INFO("╚════════════════════════════════════════════════════════════════╝");

        return true;

    } catch (const std::exception& e) {
        LOG_ERROR("Failed to load configuration: " + std::string(e.what()));
        return false;
    }
}

void ConfigManager::LoadBrokerConfig(const json& json_broker, BrokerConfig& broker_config) {
    broker_config.host = json_broker.value("host", "localhost");
    broker_config.port = json_broker.value("port", 5672);
    broker_config.username = json_broker.value("username", "guest");
    broker_config.password = json_broker.value("password", "guest");
    broker_config.virtual_host = json_broker.value("virtual_host", "/");
    broker_config.queue_name = json_broker.value("queue_name", "");
    broker_config.exchange = json_broker.value("exchange", "");
    broker_config.routing_key = json_broker.value("routing_key", "");
    broker_config.max_retries = json_broker.value("max_retries", 5);
    broker_config.retry_delay_secs = json_broker.value("retry_delay_secs", 5);
    broker_config.prefetch_count = json_broker.value("prefetch_count", 1);
    broker_config.ca_cert_file = json_broker.value("ca_cert_file", "");
    broker_config.client_cert_file = json_broker.value("client_cert_file", "");
    broker_config.client_key_file = json_broker.value("client_key_file", "");
}

const AppConfig& ConfigManager::GetConfig() const {
    std::lock_guard<std::mutex> lock(config_mutex_);
    return config_;
}

const DeviceIdentityConfig& ConfigManager::GetDeviceIdentity() const {
    std::lock_guard<std::mutex> lock(config_mutex_);
    return config_.device_identity;
}

const AudioCacheConfig& ConfigManager::GetAudioCache() const {
    std::lock_guard<std::mutex> lock(config_mutex_);
    return config_.audio_cache;
}

const SchedulerConfig& ConfigManager::GetScheduler() const {
    std::lock_guard<std::mutex> lock(config_mutex_);
    return config_.scheduler;
}

const IpcConfig& ConfigManager::GetIpc() const {
    std::lock_guard<std::mutex> lock(config_mutex_);
    return config_.ipc;
}

const CompressionConfig& ConfigManager::GetCompression() const {
    std::lock_guard<std::mutex> lock(config_mutex_);
    return config_.compression;
}

const AmqpConfig& ConfigManager::GetAmqp() const {
    std::lock_guard<std::mutex> lock(config_mutex_);
    return config_.amqp;
}

const CertificateConfig& ConfigManager::GetCertificate() const {
    std::lock_guard<std::mutex> lock(config_mutex_);
    return config_.certificate;
}

const BrokerConfig& ConfigManager::GetAmqpBroker() const {
    std::lock_guard<std::mutex> lock(config_mutex_);
    return config_.amqp_broker;
}

const BrokerConfig& ConfigManager::GetPpmBroker() const {
    std::lock_guard<std::mutex> lock(config_mutex_);
    return config_.ppm_broker;
}

const BrokerConfig& ConfigManager::GetTdmBroker() const {
    std::lock_guard<std::mutex> lock(config_mutex_);
    return config_.tdm_broker;
}

bool ConfigManager::IsMd5VerificationEnabled() const {
    std::lock_guard<std::mutex> lock(config_mutex_);
    return config_.enable_md5_verification;
}

void ConfigManager::SetConfig(const AppConfig& config) {
    std::lock_guard<std::mutex> lock(config_mutex_);
    config_ = config;
}
