/**
 * @file AASApp.cpp
 * @brief Implementation of the AASApp class for announcement scheduling and processing.
 * @author Chetana Srinivas
 * @date 2025
 * @copyright Copyright 2025 Wenzel
 */

#include "aas_app.h"
#include "log_manager.h"
#include <algorithm>
#include <fstream>
#include <iostream>
#include <chrono>
#include <ctime>
#include <sstream>
#include <iomanip>


/**
 * @brief Constructs an AASApp instance with the specified configuration and callbacks.
 * 
 * Initializes all internal components including the PDCC queue manager,
 * ELISA3 manager, and scheduler with appropriate callback functions.
 * 
 * @param cfg Configuration settings for the application
 * @param ppm_emit Callback function for emitting PPM messages
 * @param download_fn Callback function for downloading audio files
 * @param status_fn Optional callback for download status notifications
 */

AASApp::AASApp(const Config& cfg, PpmEmitFn ppm_emit, DownloadFn download_fn,
               DownloadStatusFn status_fn)
    : cfg_(cfg),
      ppm_emit_(std::move(ppm_emit)),
      download_fn_(std::move(download_fn)),
      status_fn_(std::move(status_fn)),
      pdcc_queue_(cfg_),
      elisa_(cfg_),
      scheduler_(cfg_, &pdcc_queue_, &elisa_,
           // Final PPM emission after ELISA processing
           [this](const std::string& status, const std::string& event, const AnnouncementJob& job, const std::string& detail) {
               if (ppm_emit_) {
                   ppm_emit_(status, event, job, detail);
               }
           }) {}


void AASApp::Start() {
    LOG_INFO("╔════════════════════════════════════════════════════════════════╗");
    LOG_INFO("║              STARTING AAS APPLICATION                          ║");
    LOG_INFO("╚════════════════════════════════════════════════════════════════╝");
    scheduler_.Start();
    LOG_INFO("Application started successfully");
}

void AASApp::Stop() {
    LOG_INFO("Stopping AAS Application...");
    scheduler_.Stop();
    LOG_INFO("Application stopped");
}

/**
 * @brief Create an AnnouncementJob from a PdccAnnOut message.
 * @param p The PdccAnnOut message.
 * @return AnnouncementJob The constructed job.
 */
AnnouncementJob AASApp::MakeJobFromPdcc(const PdccAnnOut& p) const {
    AnnouncementJob j;
    j.device_command_id = p.device_command_id;
    j.priority = std::clamp(p.priority, 1, 9);
    j.command = CommandKind::kAnnOut;
    j.channel_address = p.channel_address;
    j.valid_until = p.valid_until;
    j.requested_output_time = p.requested_output_time;
    j.sequence_no = p.sequence_no;
    j.announcement_id = p.announcement_id;
    j.announcement_hash = p.announcement_hash;
    j.profile_text = p.profile_text;
    j.profile_language = p.profile_language;
    
    // Handle multiple content URLs
    j.content_urls = p.content_urls;
    j.local_file_paths.resize(p.content_urls.size());
    
    // Maintain backward compatibility
    j.content_url = p.content_url;
    
    j.received_time = std::chrono::system_clock::now();
    j.download_state = DownloadState::kNotStarted;
    return j;
}

/**
 * @brief Notify the status of a download or job.
 * @param j The announcement job.
 * @param st The download state.
 * @param detail Additional detail or error message.
 */
void AASApp::NotifyStatus(const AnnouncementJob& j, DownloadState st, const std::string& detail) const {
    if (status_fn_) status_fn_(j, st, detail);
}

/**
 * @brief Handles an ANNOUT (announcement output) command.
 * 
 * Processes the announcement request by:
 * 1. Creating an AnnouncementJob from the PDCC data
 * . Updating the queue manager with download status
 * 4. Enqueuing the job for scheduling
 * 5. Notifying the scheduler to process new jobs
 * 
 * @param pdcc The ANNOUT command data containing all announcement metadata
 */

void AASApp::HandleAnnOut(const PdccAnnOut& pdcc) {
    LOG_INFO("╔════════════════════════════════════════════════════════════════╗");
    LOG_INFO("║                  PROCESSING ANNOUT COMMAND                     ║");
    LOG_INFO("╚════════════════════════════════════════════════════════════════╝");
    LOG_INFO("AnnouncementID: " + pdcc.announcement_id);
    LOG_INFO("Channel: " + pdcc.channel_address + " | Priority: " + std::to_string(pdcc.priority));
    LOG_INFO("Audio Hash: " + pdcc.announcement_hash);
    
    // Log multi-file information
    if (!pdcc.content_urls.empty()) {
        LOG_INFO("Content Files: " + std::to_string(pdcc.content_urls.size()) + " file(s)");
        for (size_t i = 0; i < pdcc.content_urls.size(); ++i) {
            LOG_INFO("  File " + std::to_string(i + 1) + ": " + pdcc.content_urls[i]);
        }
    } else {
        LOG_INFO("Content File: " + pdcc.content_url);
    }
    
    auto time_t = std::chrono::system_clock::to_time_t(pdcc.requested_output_time);
    std::stringstream ss;
    ss << std::put_time(std::gmtime(&time_t), "%a %b %d %H:%M:%S %Y UTC");
    LOG_INFO("Scheduled Due Time: " + ss.str());

    AnnouncementJob job = MakeJobFromPdcc(pdcc);

    // Set initial download state to pending
    job.download_state = DownloadState::kPending;
    NotifyStatus(job, DownloadState::kPending, "");
    
    // Add job to priority queue immediately (it will be scheduled when due)
    // The scheduler will check download status before processing
    LOG_INFO("📋 Adding to PDCC Priority Queue");
    pdcc_queue_.Push(job);
    LOG_INFO("✓ Job enqueued successfully");
    
    // Notify scheduler that there's a new job
    scheduler_.Nudge();
    LOG_INFO("🔔 Scheduler notified to process new job");
    LOG_INFO("   → Download will be handled by DownloadManager");
    LOG_INFO("   → Job will be scheduled when due and download is ready");
    LOG_INFO("╚════════════════════════════════════════════════════════════════╝");
}

void AASApp::HandleDownloadComplete(const std::string& announcement_id, bool success, const std::string& local_file_path) {
    LOG_INFO("╔════════════════════════════════════════════════════════════════╗");
    LOG_INFO("║              HANDLING DOWNLOAD COMPLETION                      ║");
    LOG_INFO("╚════════════════════════════════════════════════════════════════╝");
    LOG_INFO("AnnouncementID: " + announcement_id);
    
    if (success) {
        LOG_INFO("✓ Download completed successfully");
        LOG_INFO("   → File Path: " + local_file_path);
        
        // Update the download status in the queue manager
        pdcc_queue_.UpdateDownloadStatus(announcement_id, DownloadState::kSuccess, local_file_path);
        
        LOG_INFO("✓ Job ready for scheduling");
        
        // 🔑 CRITICAL: Notify scheduler that download is complete
        scheduler_.Nudge();
        
    } else {
        LOG_ERROR("❌ Download failed");
        
        // Update the download status with error
        pdcc_queue_.UpdateDownloadStatus(announcement_id, DownloadState::kError, "");
        
        LOG_INFO("   → Job will not be scheduled due to download failure");
    }
    
    LOG_INFO("╚════════════════════════════════════════════════════════════════╝");
}

/**
 * @brief Handles an ANNDEL (announcement delete) command.
 * 
 * Cancels a pending announcement by:
 * 1. Removing the job from the PDCC queue
 * 2. Notifying the scheduler to process the cancellation
 * 
 * @param pdcc The ANNDEL command data containing the announcement ID to cancel
 */

void AASApp::HandleAnnDel(const PdccAnnDel& pdcc) {
    LOG_INFO("╔════════════════════════════════════════════════════════════════╗");
    LOG_INFO("║                 PROCESSING ANNDEL COMMAND                      ║");
    LOG_INFO("╚════════════════════════════════════════════════════════════════╝");
    LOG_INFO("🗑️  Cancelling Announcement");
    LOG_INFO("   → AnnouncementID: " + pdcc.announcement_id);
    LOG_INFO("   → Channel: " + pdcc.channel_address);
    
    (void)pdcc.device_command_id;
    pdcc_queue_.CancelByAnnouncement(pdcc.announcement_id, pdcc.channel_address);
    scheduler_.Nudge();
    
    //LOG_INFO("✓ Cancellation processed");
    LOG_INFO("╚════════════════════════════════════════════════════════════════╝");
}

/**
 * @brief Handles a keep-alive message.
 * 
 * Currently implemented as a no-op, but can be extended for health monitoring
 * and connection maintenance purposes.
 */

void AASApp::HandleKeepAlive() {
    // no-op
}
