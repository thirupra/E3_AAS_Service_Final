/**
 * @file LogManager.cpp
 * @brief Implementation of the LogManager class for centralized logging.
 * @author Chetana Srinivas
 * @date 2025
 * @copyright Copyright 2025 Wenzel
 */

#include "log_manager.h"
#include <chrono>
#include <iomanip>
#include <sstream>

LogManager::LogManager() : currentLevel_(LogLevel::Info) {
}

LogManager& LogManager::GetInstance() {
    static LogManager instance;
    return instance;
}

void LogManager::SetLogLevel(LogLevel level) {
    std::lock_guard<std::mutex> lock(logMutex_);
    currentLevel_ = level;
}

LogLevel LogManager::GetLogLevel() const {
    std::lock_guard<std::mutex> lock(logMutex_);
    return currentLevel_;
}

void LogManager::LogError(const std::string& message) {
    LogInternal(LogLevel::Error, "ERROR", message);
}

void LogManager::LogWarning(const std::string& message) {
    LogInternal(LogLevel::Warning, "WARNING", message);
}

void LogManager::LogInfo(const std::string& message) {
    LogInternal(LogLevel::Info, "INFO", message);
}

void LogManager::LogDebug(const std::string& message) {
    LogInternal(LogLevel::Debug, "DEBUG", message);
}

void LogManager::LogInternal(LogLevel level, const std::string& levelName, const std::string& message) {
    std::lock_guard<std::mutex> lock(logMutex_);
    
    // Check if message should be logged based on current level
    if (static_cast<int>(level) > static_cast<int>(currentLevel_)) {
        return;
    }
    
    // Get timestamp
    std::string timestamp = GetTimestamp();
    
    // Format and print the log message
    std::cout << "[" << timestamp << "] [" << levelName << "] " << message << std::endl;
}

std::string LogManager::GetTimestamp() const {
    auto now = std::chrono::system_clock::now();
    auto time_t = std::chrono::system_clock::to_time_t(now);
    auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(
        now.time_since_epoch()) % 1000;
    
    std::stringstream ss;
    ss << std::put_time(std::gmtime(&time_t), "%Y-%m-%d %H:%M:%S");
    ss << "." << std::setfill('0') << std::setw(3) << ms.count();
    ss << " UTC";
    
    return ss.str();
}
