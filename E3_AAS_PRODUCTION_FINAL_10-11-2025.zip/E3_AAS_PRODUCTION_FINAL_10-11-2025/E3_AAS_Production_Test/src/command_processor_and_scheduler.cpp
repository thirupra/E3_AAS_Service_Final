#include "command_processor_and_scheduler.h"
#include "log_manager.h"
#include "ppm_reporter.h"
#include <algorithm>
#include <nlohmann/json.hpp>
#include <iostream>

/**
* @brief Constructs a CommandProcessorAndScheduler instance.
*
* Initializes the scheduler with the provided configuration and dependencies.
* Sets up the internal state but does not start processing threads.
*
* @param cfg Configuration settings for the scheduler
* @param pdcc_queue Pointer to the PDCC priority queue manager
* @param elisa Pointer to the ELISA3 manager for device communication
* @param ppm_emit Callback function for emitting PPM messages
* @param now Function for getting current time (defaults to system clock)
* @param log Function for logging messages (defaults to no-op)
*/
CommandProcessorAndScheduler::CommandProcessorAndScheduler(
        const Config& cfg,
        PDCCPriorityQueueManager* pdcc_queue,
        ELISA3Manager* elisa,
        PpmEmitFn ppm_emit,
        NowFn now,
        LogFn log)
    : cfg_(cfg),
      pdcc_queue_(pdcc_queue),
      elisa_(elisa),
      ppm_emit_(ppm_emit),
      now_(std::move(now)),
      log_(std::move(log)) {}
 
/**
* @brief Destructor that ensures clean shutdown.
*
* Automatically stops all background processing threads and cleans up resources.
*/
CommandProcessorAndScheduler::~CommandProcessorAndScheduler() {
    Stop();
}
 
/**
* @brief Starts the announcement processor and scheduler threads.
*
* Initializes the background processing threads and begins job processing.
* Sets up ELISA3 acknowledgment callbacks and starts the main processing loops.
*/
void CommandProcessorAndScheduler::Start() {
    stop_ = false;
    LOG_INFO("╔════════════════════════════════════════════════════════════════╗");
    LOG_INFO("║  SCHEDULER: Starting CommandProcessor and Scheduler Threads    ║");
    LOG_INFO("╚════════════════════════════════════════════════════════════════╝");
    
    elisa_->SetAckCallback([this](const ElisaAck& ack){ OnElisaAck(ack); });
    ann_thread_ = std::thread([this]{ AnnouncementProcessorLoop(); });
    sch_thread_ = std::thread([this]{ SchedulerLoop(); });
    
    LOG_INFO("[SCHEDULER] ✓ Announcement Processor Thread Started");
    LOG_INFO("[SCHEDULER] ✓ Scheduler Dispatch Thread Started");
}
 
/**
* @brief Stops the announcement processor and scheduler threads.
*
* Gracefully shuts down all background processing and cleans up resources.
* Notifies all waiting threads and waits for them to complete.
*/
void CommandProcessorAndScheduler::Stop() {
    LOG_INFO("[SCHEDULER] Initiating graceful shutdown...");
    stop_ = true;
    ann_cv_.notify_all();
    sch_cv_.notify_all();
    if (ann_thread_.joinable()) ann_thread_.join();
    if (sch_thread_.joinable()) sch_thread_.join();
    LOG_INFO("[SCHEDULER] ✓ All threads stopped successfully");
}
 
/**
* @brief External nudge to wake up processing threads.
*
* Called when new ANNOUT commands arrive or ANNDEL commands occur
* to immediately process new jobs or handle cancellations.
* Notifies both the announcement processor and scheduler threads.
*/
void CommandProcessorAndScheduler::Nudge() {
    ann_cv_.notify_all();
    sch_cv_.notify_all();
}
 
/**
* @brief Main loop for the announcement processor thread.
*
* Periodically wakes up to check for due jobs in the PDCC queue,
* processes them, and distributes them into priority bins.
* Uses intelligent sleep timing based on next due time and configuration.
*/
void CommandProcessorAndScheduler::AnnouncementProcessorLoop() {
    while (!stop_.load()) {
        // Compute sleep until next due time or configuration tick interval
        auto next_due = pdcc_queue_->NextWakeup();
        auto target = now_() + cfg_.announcement_tick;
        if (next_due && *next_due < target) target = *next_due;

        std::unique_lock<std::mutex> lk(ann_mu_);
        ann_cv_.wait_until(lk, target, [this]{ return stop_.load(); });
        lk.unlock();
        if (stop_.load()) break;

        // Drain due jobs and distribute them into priority bins
        auto due = pdcc_queue_->PopDue(now_());
        if (!due.empty()) {
            LOG_INFO("Found " + std::to_string(due.size()) + " due announcement(s)");
            for (const auto& job : due) {
                LOG_INFO("  → AnnouncementID: " + job.announcement_id +
                        " | Priority: " + std::to_string(job.priority) +
                         " | Channel: " + job.channel_address);
            }
            EnqueueDueIntoPriorityBins(due);
            // Signal scheduler to process new jobs
            sch_cv_.notify_all();
        }
    }
}

/**
* @brief Distributes due jobs into priority bins.
*
* Takes a list of due jobs and places them into the appropriate
* priority bins based on their priority levels (1-9).
* Thread-safe operation that requires scheduler mutex.
*
* @param due Vector of jobs that are ready for processing
*/
void CommandProcessorAndScheduler::EnqueueDueIntoPriorityBins(const std::vector<AnnouncementJob>& due) {
    std::lock_guard<std::mutex> lk(sch_mu_);
    for (auto job : due) {
        int p = std::clamp(job.priority, 1, 9);
        prio_bins_[p].push_back(std::move(job));
        LOG_INFO("[SCHEDULER] ✓ Enqueued to priority bin [" + std::to_string(p) + "]: " + job.announcement_id);
    }
}
 
/**
* @brief Main loop for the scheduler thread.
*
* Continuously monitors priority bins for available jobs and
* dispatches them to ELISA3 devices when channels are free.
* Also handles timeout processing for jobs waiting for ELISA3 responses.
*/
void CommandProcessorAndScheduler::SchedulerLoop() {
    while (!stop_.load()) {
        std::unique_lock<std::mutex> lk(sch_mu_);
        // Wait for notification or tick interval, whichever comes first
        sch_cv_.wait_for(lk, cfg_.announcement_tick, [this]{ return stop_.load(); });
        if (stop_.load()) break;

        // Try dispatching until no eligible job is available
        bool dispatched = false;
        while (PickAndDispatchHighPriorityJob()) {
            dispatched = true;
        }

        // OLD CODE: ELISA3 timeout handling (no longer needed)
        /*
        if (!dispatched) {
            // Check for timed out jobs waiting for ELISA3 responses
            auto tnow = now_();
            std::vector<std::string> timeouts;
            for (const auto& kv : waiters_) {
                if (tnow >= kv.second.deadline) timeouts.push_back(kv.first);
            }
            for (const auto& dcid : timeouts) {
                auto it = waiters_.find(dcid);
                if (it == waiters_.end()) continue;
                auto job = it->second.job;
                inflight_by_channel_.erase(job.channel_address);
                inflight_channels_.erase(job.channel_address);
                waiters_.erase(it);
                lk.unlock();
                CompleteJob(job, false, "E_TIMEOUT");
                lk.lock();
            }
        }
        */
        
        // NEW CODE: No timeout handling needed in Python-compatibility mode
        // Jobs get immediate success after ELISA3 dispatch
    }
    LOG_INFO("[SCHEDULER] Scheduler loop ended");
}
/**
* @brief Picks and dispatches the highest priority available job.
* Searches through priority bins (highest to lowest) to find an
* available job for a free channel and dispatches it to ELISA3.
* Enforces per-destination serialization and handles expired jobs.
*
* @return True if a job was dispatched, false if no jobs available
*/
bool CommandProcessorAndScheduler::PickAndDispatchHighPriorityJob() {
    // Caller holds sch_mu_.
    for (int p = 9; p >= 1; --p) {
        auto& q = prio_bins_[p];
        if (q.empty()) continue;
        auto tnow = now_();
        for (auto it = q.begin(); it != q.end(); ++it) {
            if (it->IsExpired(tnow)) {
                // Drop expired with error
                AnnouncementJob job = *it;
                q.erase(it);
                LOG_WARNING("Job EXPIRED (dropped)");
                LOG_WARNING("  → AnnouncementID: " + job.announcement_id);
                LOG_WARNING("  → Channel: " + job.channel_address);
                LOG_WARNING("  → Reason: Exceeded validUntil timestamp");
                // We must not hold the lock while invoking callbacks that can emit/AMQP.
                {
                    // Temporarily drop the scheduler lock to avoid deadlocks.
                    // Lock dance: unlock -> callback -> re-lock.
                    sch_mu_.unlock();
                    CompleteJob(job, /*success=*/false, "E_COMMAND_FAULTY");
                    sch_mu_.lock();
                }
                return true; // consumed one
            }
            // Check if channel is available or can be preempted
            AnnouncementJob job = *it;
            auto ch = job.channel_address;
            auto pr = job.priority;
            
            
            auto itInflight = inflight_by_channel_.find(ch);
            const bool isInflight = (itInflight != inflight_by_channel_.end());
            
            
            if (isInflight) {
                const int inflight_pr = itInflight->second.priority;
                if (pr > inflight_pr) {
                    // --- PREEMPTION ---
                    LOG_INFO("PREEMPTION: Higher priority job taking over channel");
                    LOG_INFO("  → New Job: " + job.announcement_id + " (Priority " + std::to_string(pr) + ")");
                    LOG_INFO("  → Preempting: " + itInflight->second.announcement_id + " (Priority " + std::to_string(inflight_pr) + ")");
                    
                    // Remove from queue and proceed with dispatch
                    q.erase(it);
                    
                    // Before dispatching to ELISA, ensure the audio is available
                    DownloadStatus st;
                    if (!pdcc_queue_->GetDownloadStatus(job.announcement_id, &st)) {
                        LOG_ERROR("[SCHEDULER] No download status found for: " + job.announcement_id);
                        sch_mu_.unlock();
                        CompleteJob(job, /*success=*/false, "E_FILE_MISS:no-download-status");
                        sch_mu_.lock();
                        return true;
                    }
 
                    // Handle different download states
                    switch (st.state) {
                        case DownloadState::kSuccess:
                            LOG_INFO("[SCHEDULER] ✅ Audio ready for: " + job.announcement_id);
                            // Audio is ready, proceed with dispatch
                            break;
                            
                        case DownloadState::kInProgress:
                        case DownloadState::kPending:
                            LOG_INFO("[SCHEDULER] ⏳ Download still in progress for: " + job.announcement_id + ", will retry later");
                            // Download still in progress, don't fail - just skip for now
                            // The job will be retried in the next scheduler cycle
                            return false; // Don't consume the job, try again later
                            
                        case DownloadState::kError:
                        case DownloadState::kNotStarted:
                        default:
                            LOG_ERROR("[SCHEDULER] ❌ Download failed for: " + job.announcement_id);
                            sch_mu_.unlock();
                            CompleteJob(job, /*success=*/false, "E_FILE_MISS:download-failed");
                            sch_mu_.lock();
                            return true; // consumed/drop
                    }
 
                    // At this point, download is successful, proceed with dispatch
                    auto playable = job;
                    playable.local_file_path = st.local_file_path;
                    LOG_INFO("[SCHEDULER] 🎵 Dispatching job with audio file: " + playable.local_file_path);                  
                    // Dispatch the NEW job immediately
                    if (elisa_->SendPlayRequest(playable)) {
                        // NEW CODE: No inflight tracking, immediate success
                        LOG_INFO("📤 Preemption: Sending immediate SUCCESS (Python-compatibility)");
                        
                        // The old job is effectively cancelled/preempted
                        // The new job gets immediate success
                        sch_mu_.unlock();
                        CompleteJob(job, /*success=*/true, "");
                        sch_mu_.lock();
                        
                        LOG_INFO("[SUCCESS] Scheduler: Preempt-dispatched job " + job.announcement_id);
                        return true;
                    } else {
                        LOG_ERROR("[ERROR] Scheduler: Preempt dispatch failed for channel " + ch);
                        return true; // consumed the job even if dispatch failed
                    }
                } else {
                    // No preemption for same/lower priority
                }
            } else {
                // Normal dispatch - channel is free
                q.erase(it);
                inflight_channels_.insert(job.channel_address);
 
                // Before dispatching to ELISA, ensure the audio is available
                DownloadStatus st;
                if (!pdcc_queue_->GetDownloadStatus(job.announcement_id, &st)) {
                    LOG_INFO("[SCHEDULER] ⏳ Download status not found for: " + job.announcement_id + ", will retry later");
                    
                    // Add back to queue for retry later instead of failing
                    q.push_back(job);
                    
                    return false; // Don't consume the job, try again later
                }
 
                // Handle different download states
                switch (st.state) {
                    case DownloadState::kSuccess:
                        LOG_INFO("[SCHEDULER] ✅ Audio ready for: " + job.announcement_id);
                        // Audio is ready, proceed with dispatch
                        break;
                        
                    case DownloadState::kInProgress:
                    case DownloadState::kPending:
                        LOG_INFO("[SCHEDULER] ⏳ Download still in progress for: " + job.announcement_id + ", will retry later");
                        // Download still in progress, don't fail - just skip for now
                        // The job will be retried in the next scheduler cycle
                        return false; // Don't consume the job, try again later
                        
                    case DownloadState::kError:
                    case DownloadState::kNotStarted:
                    default:
                        LOG_ERROR("[SCHEDULER] ❌ Download failed for: " + job.announcement_id);
                        sch_mu_.unlock();
                        CompleteJob(job, /*success=*/false, "E_FILE_MISS:download-failed");
                        sch_mu_.lock();
                        return true; // consumed/drop
                }
 
                // At this point, download is successful, proceed with dispatch
                auto playable = job;
                playable.local_file_path = st.local_file_path;
                LOG_INFO("[SCHEDULER] 🎵 Dispatching job with audio file: " + playable.local_file_path);
 
                // Send to ELISA (we can keep the lock here; SendPlayRequest should be quick)
                if (!elisa_->SendPlayRequest(playable)) {
                    LOG_ERROR("[ERROR] Scheduler: ELISA3Manager::SendPlayRequest failed");
                    inflight_channels_.erase(job.channel_address);
                    // Unlock around the callback
                    sch_mu_.unlock();
                    CompleteJob(job, /*success=*/false, "E_UNKNOWN");
                    sch_mu_.lock();
                    return true;
                }
                LOG_INFO("DISPATCHED to ELISA3");
                LOG_INFO("  → AnnouncementID: " + job.announcement_id);
                LOG_INFO("  → Channel: " + job.channel_address + " | Priority: " + std::to_string(job.priority));
                
                // PYTHON-COMPATIBILITY : Assume success like Python/VLC
                // Comment out ELISA3 ACK waiting and send immediate success
                
                // OLD CODE: Wait for ELISA3 ACK (causes timeout failures)
                /*
                // Update inflight tracking
                inflight_by_channel_[ch] = Inflight{
                    job.device_command_id, pr, ch, job.announcement_id
                };
                
                // Start waiter
                waiters_[job.device_command_id] = Waiter{
                    job, now_() + cfg_.elisa_ack_timeout, BuildPpmMeta(job), false
                };
                */
                
                // NEW CODE: Immediate success like Python client
                LOG_INFO("📤 Sending immediate SUCCESS (Python-compatibility mode)");
                LOG_INFO("  → Skipping ELISA3 ACK wait, assuming success like Python/VLC");
                
                // Free the channel immediately (no waiting)
                inflight_channels_.erase(job.channel_address);
                
                // Send success PPM immediately (like Python after VLC playback)
                sch_mu_.unlock();
                CompleteJob(job, /*success=*/true, "");  // Success with no detail
                sch_mu_.lock();
                
                return true;
            }
        }
    }
    return false;
}
/**
* @brief Handles ELISA3 acknowledgment responses.
*
* Processes incoming ACK/NACK responses from ELISA3 devices
* and completes the corresponding announcement jobs.
* Maps ELISA3 response codes to appropriate PPM error codes.
*
* @param ack The ELISA3 acknowledgment response
*/
 
void CommandProcessorAndScheduler::OnElisaAck(const ElisaAck& ack) {
    
    // Ignore spontaneous TDM
    if (ack.device_command_id.empty()) {
        return;
    }
    
    LOG_INFO("ELISA3 ACK Received");
    LOG_INFO("  → CommandID: " + ack.device_command_id + " | Code: " + std::to_string(ack.code));

    std::unique_lock<std::mutex> lk(sch_mu_);
    auto wit = waiters_.find(ack.device_command_id);
    if (wit == waiters_.end()) {
        return;
    }
    
    Waiter w = wit->second; // copy for logging; we'll erase later

    // Is this ack for the CURRENT inflight on this channel?
    bool is_current = false;
    if (auto it = inflight_by_channel_.find(w.job.channel_address); it != inflight_by_channel_.end()) {
        is_current = (it->second.device_command_id == ack.device_command_id);
    }

    // Map ELISA codes to PPM responses
    auto publish_nack = [&](const char* detail) {
        LOG_INFO("  → Result: NACK (" + std::string(detail) + ")");
        // Use existing CompleteJob method for PPM publishing
        lk.unlock();
        CompleteJob(w.job, false, detail);
        lk.lock();
    };
    auto publish_ack = [&]() {
        LOG_INFO("  → Result: SUCCESS ✓");
        lk.unlock();
        CompleteJob(w.job, true, "");
        lk.lock();
    };

    // Map ELISA codes
    auto publish_from_code = [&]() {
        unsigned long code = ack.codes.empty() ? ack.code : ack.codes[0];
        switch (code) {
            case 2:  publish_ack(); break;                       // NO_ERR_STOP → aag-ack
            case 11: publish_nack("E_NO_DEVICE"); break;         // ERR_NODEVICE → aag-nack E_NO_DEVICE  
            case 14: publish_nack("E_UNKNOWN");   break;         // ERR_UNKNOWN → aag-nack E_UNKNOWN
            case 15: publish_nack("E_NO_LINE");   break;         // ERR_NOLINE → aag-nack E_NO_LINE
            case 21: publish_nack("E_DEST_DEF");  break;         // ERR_DESTDEF → aag-nack E_DEST_DEF
            case 22: publish_nack("E_DEST_OCCU"); break;         // ERR_DESTOCCU → aag-nack E_DEST_OCCU (fixed typo)
            default: publish_nack("E_UNKNOWN");   break;         // Any other code → aag-nack E_UNKNOWN
        }
    };

    if (w.preempted && !is_current) {
        // Old job finished/aborted AFTER we started a new higher-prio.
        // We do NOT free the channel here; the channel belongs to the new job.
        publish_nack("E_PREEMPTED");
        waiters_.erase(wit);
        return;
    }

    // Current inflight's terminal outcome → free the channel
    publish_from_code();

    // Free the channel ONLY if this ack is for the current inflight
    if (is_current) {
        inflight_by_channel_.erase(w.job.channel_address);
        inflight_channels_.erase(w.job.channel_address);
    } else {
        // Not preempted, not current — probably a race; do nothing to channel
    }

    waiters_.erase(wit);
}


/**
* @brief Completes a job with success or failure status.
*
* Finalizes job processing, emits appropriate PPM messages,
* and cleans up job state. This is the final step in job processing.
*
* @param job The job to complete
* @param success Whether the job completed successfully
* @param detail Additional details about the completion
*/
void CommandProcessorAndScheduler::CompleteJob(const AnnouncementJob& job,
                                               bool success,
                                               const std::string& detail) {
    LOG_INFO("📤 Publishing PPM " + std::string(success ? "SUCCESS" : "FAILURE") + " message");
    LOG_INFO("  → AnnouncementID: " + job.announcement_id);
    if (!detail.empty()) {
        LOG_INFO("  → Detail: " + detail);
    }
    
    // Fix the callback call to match the expected signature
    if (ppm_emit_) {
        std::string status = success ? "success" : "error";
        std::string event = success ? "aag-ack" : "aag-nack";
        ppm_emit_(status, event, job, detail);  
    }
    LOG_INFO("");
    LOG_INFO("╔════════════════════════════════════════════════════════════════╗");
    LOG_INFO("║                          JOB DONE                              ║");
    LOG_INFO("╚════════════════════════════════════════════════════════════════╝");

}

/**
* @brief Builds PPM metadata from an announcement job.
*
* Creates PpmMeta structure with job information for PPM publishing.
*
* @param job The announcement job
* @return PpmMeta structure with job metadata
*/
CommandProcessorAndScheduler::PpmMeta CommandProcessorAndScheduler::BuildPpmMeta(const AnnouncementJob& job) {
    PpmMeta meta;
    meta.announcement_id = job.announcement_id;
    meta.device_command_id = job.device_command_id;
    meta.channel_address = job.channel_address;
    meta.priority = job.priority;
    meta.sequence_no = job.sequence_no;
    return meta;
}