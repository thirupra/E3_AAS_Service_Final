#include "message_validator.h"
#include "log_manager.h"
#include "config_manager.h"
#include <regex>
#include <sstream>
#include <iomanip>
#include <ctime>
#include <cstdlib>

// Error message constants
const std::string MessageValidator::kErrorInvalidTimestamp = "E_INVALID_TIMESTAMP";
const std::string MessageValidator::kErrorInvalidPriority = "E_INVALID_PRIORITY";
const std::string MessageValidator::kErrorMissingField = "E_MISSING_FIELD";
const std::string MessageValidator::kErrorTimestampInPast = "E_TIMESTAMP_IN_PAST";
const std::string MessageValidator::kErrorTimestampExpired = "E_TIMESTAMP_EXPIRED";
const std::string MessageValidator::kErrorInvalidCommand = "E_INVALID_COMMAND";
const std::string MessageValidator::kErrorMalformedMessage = "E_COMMAND_FAULTY";

MessageValidator::ValidationResult MessageValidator::ValidateMessage(const nlohmann::json& message) {
    ValidationResult result;
    result.is_valid = false;
    
    try {
        // Check for required top-level fields
        if (!message.contains("physicalDeviceCommands")) {
            result.error_code = "E_COMMAND_FAULTY";
            result.error_message = "Missing 'physicalDeviceCommands' field";
            return result;
        }
        
        // msg-meta is optional - some clients include it, others don't
        if (message.contains("msg-meta")) {
            const auto& msg_meta = message["msg-meta"];
            if (!msg_meta.contains("type") || !msg_meta.contains("version")) {
                result.error_code = "E_COMMAND_FAULTY";
                result.error_message = "Invalid msg-meta structure";
                return result;
            }
            
            // STRICT VALIDATION: msg-meta.created must be UTC with 'Z' suffix if present
            if (msg_meta.contains("created")) {
                std::string created_timestamp = msg_meta.value("created", "");
                if (!created_timestamp.empty()) {
                    auto time_result = ValidateTimestamp(created_timestamp, "msg-meta.created");
                    if (!time_result.is_valid) {
                        result.error_code = time_result.error_code;
                        result.error_message = time_result.error_message;
                        return result;
                    }
                }
            }
        }
        
        // Validate physicalDeviceCommands array
        const auto& commands = message["physicalDeviceCommands"];
        if (!commands.is_array()) {
            result.error_code = "E_COMMAND_FAULTY";
            result.error_message = "physicalDeviceCommands must be an array";
            return result;
        }
        
        // Skip validation for keep-alive messages (empty command arrays)
        if (commands.empty()) {
            result.is_valid = true;
            return result;
        }
        
        // Validate each command
        for (const auto& cmd : commands) {
            if (!cmd.contains("pdevCommand")) {
                result.error_code = "E_COMMAND_FAULTY";
                result.error_message = "Missing 'pdevCommand' field";
                return result;
            }
            
            const auto& pdev_cmd = cmd["pdevCommand"];
            if (!pdev_cmd.contains("cmd-meta")) {
                result.error_code = "E_COMMAND_FAULTY";
                result.error_message = "Missing 'cmd-meta' field";
                return result;
            }
            
            const auto& cmd_meta = pdev_cmd["cmd-meta"];
            
            // Validate required cmd-meta fields
            std::vector<std::string> required_fields = {
                "deviceCommandId", "command", "channelAddress", 
                "sequenceNo", "announcementId"
            };
            
            for (const auto& field : required_fields) {
                if (!cmd_meta.contains(field)) {
                    result.error_code = "E_COMMAND_FAULTY";
                    result.error_message = "Missing required field: " + field;
                    return result;
                }
            }
            
            // Validate command-specific content and all fields
            const std::string command = cmd_meta["command"];
            if (command == "ANNOUT") {
                // Validate ANNOUT command using existing method
                auto annout_result = ValidateAnnoutMandatoryFields(cmd_meta);
                if (!annout_result.is_valid) {
                    result.error_code = annout_result.error_code;
                    result.error_message = annout_result.error_message;
                    return result;
                }
                
                // STRICT TIMESTAMP VALIDATION - Check requestedOutputTime
                if (cmd_meta.contains("requestedOutputTime")) {
                    std::string requested_time = cmd_meta.value("requestedOutputTime", "");
                    if (!requested_time.empty()) {
                        auto time_result = ValidateTimestamp(requested_time, "requestedOutputTime");
                        if (!time_result.is_valid) {
                            result.error_code = time_result.error_code;
                            result.error_message = time_result.error_message;
                            return result;
                        }
                    }
                } else if (cmd_meta.contains("requestedOuputTime")) {
                    std::string requested_time = cmd_meta.value("requestedOuputTime", "");
                    if (!requested_time.empty()) {
                        auto time_result = ValidateTimestamp(requested_time, "requestedOuputTime");
                        if (!time_result.is_valid) {
                            result.error_code = time_result.error_code;
                            result.error_message = time_result.error_message;
                            return result;
                        }
                    }
                }
                
                // STRICT TIMESTAMP VALIDATION - Check validUntil  
                if (cmd_meta.contains("validUntil")) {
                    std::string valid_until = cmd_meta.value("validUntil", "");
                    if (!valid_until.empty()) {
                        auto time_result = ValidateTimestamp(valid_until, "validUntil");
                        if (!time_result.is_valid) {
                            result.error_code = time_result.error_code;
                            result.error_message = time_result.error_message;
                            return result;
                        }
                    }
                }
                
                // CROSS-TIMESTAMP VALIDATION: Both validUntil and requestedOutputTime must not be less than msg-meta.created
                std::string created_time = "";
                if (message.contains("msg-meta") && message["msg-meta"].contains("created")) {
                    created_time = message["msg-meta"].value("created", "");
                }
                
                if (!created_time.empty()) {
                    time_t created_timestamp = ParseISOTimestamp(created_time);
                    
                    if (created_timestamp != -1) {
                        // Check requestedOutputTime against created time
                        std::string requested_time = "";
                        if (cmd_meta.contains("requestedOutputTime")) {
                            requested_time = cmd_meta.value("requestedOutputTime", "");
                        } else if (cmd_meta.contains("requestedOuputTime")) {
                            requested_time = cmd_meta.value("requestedOuputTime", "");
                        }
                        
                        if (!requested_time.empty()) {
                            time_t requested_timestamp = ParseISOTimestamp(requested_time);
                            if (requested_timestamp != -1 && requested_timestamp < created_timestamp) {
                                result.error_code = "E_COMMAND_FAULTY";
                                result.error_message = "requestedOutputTime is Expired";
                                return result;
                            }
                        }
                        
                        // Check validUntil against created time
                        std::string valid_until = cmd_meta.value("validUntil", "");
                        if (!valid_until.empty()) {
                            time_t valid_until_timestamp = ParseISOTimestamp(valid_until);
                            if (valid_until_timestamp != -1 && valid_until_timestamp < created_timestamp) {
                                result.error_code = "E_COMMAND_FAULTY";
                                result.error_message = "validUntil time is Expired";
                                return result;
                            }
                        }
                    }
                }
                
                // CROSS-TIMESTAMP VALIDATION: requestedOutputTime must not be greater than validUntil
                std::string requested_time = "";
                if (cmd_meta.contains("requestedOutputTime")) {
                    requested_time = cmd_meta.value("requestedOutputTime", "");
                } else if (cmd_meta.contains("requestedOuputTime")) {
                    requested_time = cmd_meta.value("requestedOuputTime", "");
                }
                
                std::string valid_until = cmd_meta.value("validUntil", "");
                
                if (!requested_time.empty() && !valid_until.empty()) {
                    time_t requested_timestamp = ParseISOTimestamp(requested_time);
                    time_t valid_until_timestamp = ParseISOTimestamp(valid_until);
                    
                    if (requested_timestamp != -1 && valid_until_timestamp != -1) {
                        if (requested_timestamp > valid_until_timestamp) {
                            result.error_code = "E_COMMAND_FAULTY";
                            result.error_message = "requestedOutputTime cannot be greater than validUntil";
                            return result;
                        }
                    }
                }
                
                if (!pdev_cmd.contains("cmd-content")) {
                    result.error_code = "E_COMMAND_FAULTY";
                    result.error_message = "ANNOUT command missing cmd-content";
                    return result;
                }
                
                const auto& content = pdev_cmd["cmd-content"];
                if (!content.contains("content") || !content.contains("content-type")) {
                    result.error_code = "E_COMMAND_FAULTY";
                    result.error_message = "Invalid cmd-content structure";
                    return result;
                }
                
                const std::string content_type = content["content-type"];
                if (content_type != "text/x-url") {
                    result.error_code = "E_COMMAND_FAULTY";
                    result.error_message = "Invalid content-type: " + content_type;
                    return result;
                }
                
                // Validate URL content (supports both single string and array)
                std::vector<std::string> content_urls;
                if (content.contains("content")) {
                    const auto& content_field = content["content"];
                    if (content_field.is_array()) {
                        // Multiple files: ["url1", "url2", "url3"]
                        for (const auto& uri_elem : content_field) {
                            if (uri_elem.is_string()) {
                                std::string uri_str = uri_elem.get<std::string>();
                                if (!uri_str.empty()) {
                                    content_urls.push_back(uri_str);
                                }
                            }
                        }
                    } else if (content_field.is_string()) {
                        // Single file: "url1" (backward compatibility)
                        std::string uri_str = content_field.get<std::string>();
                        if (!uri_str.empty()) {
                            content_urls.push_back(uri_str);
                        }
                    }
                }
                
                // Validate that we have at least one content URL
                if (content_urls.empty()) {
                    result.error_code = "E_COMMAND_FAULTY";
                    result.error_message = "Empty or invalid URL content";
                    return result;
                }
                
                // Check URL scheme for all URLs - only HTTPS allowed for secure audio downloads
                for (const auto& uri : content_urls) {
                    if (uri.rfind("https://", 0) != 0) {
                        result.error_code = "E_COMMAND_FAULTY";
                        result.error_message = "Invalid URL scheme - must be https://";
                        return result;
                    }
                }
                
            } else if (command == "ANNDEL") {
                // Validate ANNDEL command using existing method
                auto anndel_result = ValidateAnndelMandatoryFields(cmd_meta);
                if (!anndel_result.is_valid) {
                    result.error_code = anndel_result.error_code;
                    result.error_message = anndel_result.error_message;
                    return result;
                }
            } else {
                result.error_code = "E_COMMAND_FAULTY";
                result.error_message = "Unsupported command type: " + command;
                return result;
            }
        }
        
        result.is_valid = true;
        return result;
        
    } catch (const std::exception& ex) {
        result.error_code = "E_COMMAND_FAULTY";
        result.error_message = "JSON parsing error: " + std::string(ex.what());
        return result;
    }
}

MessageValidator::ValidationResult MessageValidator::ValidateCommand(const nlohmann::json& command) {
    // Check if command has required structure
    if (!command.contains("pdevCommand")) {
        return {false, "Missing pdevCommand", kErrorMalformedMessage};
    }

    const auto& pdev_command = command["pdevCommand"];
    if (!pdev_command.contains("cmd-meta")) {
        return {false, "Missing cmd-meta", kErrorMalformedMessage};
    }

    const auto& cmd_meta = pdev_command["cmd-meta"];
    if (!cmd_meta.is_object()) {
        return {false, "Invalid cmd-meta structure", kErrorMalformedMessage};
    }

    // Get command type
    std::string command_type = cmd_meta.value("command", "");
    if (command_type.empty()) {
        return {false, "Missing command field", kErrorMissingField};
    }

    // Validate based on command type
    if (command_type == "ANNOUT") {
        auto result = ValidateAnnoutMandatoryFields(cmd_meta);
        if (!result.is_valid) {
            return result;
        }

        // Check if cmd-content is present for ANNOUT
        if (!pdev_command.contains("cmd-content")) {
            return {false, "ANNOUT command missing cmd-content", kErrorMissingField};
        }

        // Validate timestamps - check if they exist first
        if (cmd_meta.contains("requestedOutputTime")) {
            std::string requested_output_time = cmd_meta.value("requestedOutputTime", "");
            if (!requested_output_time.empty()) {
                auto time_result = ValidateTimestamp(requested_output_time, "requestedOutputTime");
                if (!time_result.is_valid) {
                    return time_result;
                }
                
                // Check if requestedOutputTime is in the past
                if (IsTimestampInPast(requested_output_time)) {
                    return {false, "requestedOutputTime is in the past", kErrorTimestampInPast};
                }
            }
        } else if (cmd_meta.contains("requestedOuputTime")) {
            std::string requested_output_time = cmd_meta.value("requestedOuputTime", "");
            if (!requested_output_time.empty()) {
                auto time_result = ValidateTimestamp(requested_output_time, "requestedOutputTime");
                if (!time_result.is_valid) {
                    return time_result;
                }
                
                // Check if requestedOutputTime is in the past
                if (IsTimestampInPast(requested_output_time)) {
                    return {false, "requestedOutputTime is in the past", kErrorTimestampInPast};
                }
            }
        }

        if (cmd_meta.contains("validUntil")) {
            std::string valid_until = cmd_meta.value("validUntil", "");
            if (!valid_until.empty()) {
                auto time_result = ValidateTimestamp(valid_until, "validUntil");
                if (!time_result.is_valid) {
                    return time_result;
                }
                
                // Check if validUntil is expired
                if (IsTimestampExpired(valid_until)) {
                    return {false, "validUntil is expired", kErrorTimestampExpired};
                }
            }
        }

        // CROSS-TIMESTAMP VALIDATION: requestedOutputTime must not be greater than validUntil
        // NOTE: This method cannot validate against msg-meta.created since it only receives individual commands.
        // Use ValidateMessage() for complete validation including created time checks.
        std::string requested_time = "";
        if (cmd_meta.contains("requestedOutputTime")) {
            requested_time = cmd_meta.value("requestedOutputTime", "");
        } else if (cmd_meta.contains("requestedOuputTime")) {
            requested_time = cmd_meta.value("requestedOuputTime", "");
        }
        
        std::string valid_until = cmd_meta.value("validUntil", "");
        
        if (!requested_time.empty() && !valid_until.empty()) {
            time_t requested_timestamp = ParseISOTimestamp(requested_time);
            time_t valid_until_timestamp = ParseISOTimestamp(valid_until);
            
            if (requested_timestamp != -1 && valid_until_timestamp != -1) {
                if (requested_timestamp > valid_until_timestamp) {
                    return {false, "requestedOutputTime cannot be greater than validUntil", "E_COMMAND_FAULTY"};
                }
            }
        }

    } else if (command_type == "ANNDEL") {
        auto result = ValidateAnndelMandatoryFields(cmd_meta);
        if (!result.is_valid) {
            return result;
        }
    } else {
        return {false, "Invalid command type: " + command_type, kErrorInvalidCommand};
    }

    return {true, "", ""};
}

MessageValidator::ValidationResult MessageValidator::ValidateTimestamp(const std::string& timestamp_str, const std::string& field_name) {
    if (timestamp_str.empty()) {
        return {false, "Missing " + field_name, kErrorMissingField};
    }

    // STRICT UTC-only ISO 8601 format validation - MUST end with 'Z'
    std::regex iso_regex(R"(^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?Z$)");
    if (!std::regex_match(timestamp_str, iso_regex)) {
        return {false, "Invalid " + field_name + " format - must be UTC timezone with 'Z' suffix", kErrorInvalidTimestamp};
    }

    // Try to parse the timestamp
    time_t parsed_time = ParseISOTimestamp(timestamp_str);
    if (parsed_time == -1) {
        return {false, "Invalid " + field_name + " value", kErrorInvalidTimestamp};
    }

    return {true, "", ""};
}

MessageValidator::ValidationResult MessageValidator::ValidatePriority(int priority) {
    if (priority < 1 || priority > 9) {
        return {false, "Priority must be between 1 and 9", kErrorInvalidPriority};
    }
    return {true, "", ""};
}

MessageValidator::ValidationResult MessageValidator::ValidateAnnoutMandatoryFields(const nlohmann::json& cmd_meta) {
    // Check for required fields
    if (!cmd_meta.contains("announcementId") || cmd_meta["announcementId"].is_null()) {
        return {false, "Missing announcementId", kErrorMissingField};
    }

    // Validate announcementId type - must be string, not number
    if (!cmd_meta["announcementId"].is_string()) {
        return {false, "announcementId must be a string, not a number", "E_COMMAND_FAULTY"};
    }

    if (!cmd_meta.contains("channelAddress") || cmd_meta["channelAddress"].is_null()) {
        return {false, "Missing channelAddress", kErrorMissingField};
    }

    // Validate channelAddress type - must be string
    if (!cmd_meta["channelAddress"].is_string()) {
        return {false, "channelAddress must be a string", "E_COMMAND_FAULTY"};
    }

    // Handle priority: use default if missing, validate if present
    int priority;
    if (!cmd_meta.contains("priority")) {
        // Use configured default priority when missing
        priority = ConfigManager::GetInstance().GetScheduler().default_priority;
        std::cout << "[MessageValidator] Priority missing, using default: " << priority << std::endl;
    } else {
        priority = cmd_meta.value("priority", -1);
    }
    
    // Validate priority value (whether provided or default)
    auto priority_result = ValidatePriority(priority);
    if (!priority_result.is_valid) {
        return priority_result;
    }

    // Check for other required fields
    if (!cmd_meta.contains("deviceCommandId") || cmd_meta["deviceCommandId"].is_null()) {
        return {false, "Missing deviceCommandId", kErrorMissingField};
    }

    // Validate deviceCommandId type - must be string
    if (!cmd_meta["deviceCommandId"].is_string()) {
        return {false, "deviceCommandId must be a string", "E_COMMAND_FAULTY"};
    }

    if (!cmd_meta.contains("sequenceNo")) {
        return {false, "Missing sequenceNo", kErrorMissingField};
    }

    // Validate sequenceNo type - must be integer, not string
    if (!cmd_meta["sequenceNo"].is_number_integer()) {
        return {false, "sequenceNo must be an integer, not a string", "E_COMMAND_FAULTY"};
    }

    // Validate sequenceNo value - must be non-negative
    int64_t sequence_no = cmd_meta["sequenceNo"].get<int64_t>();
    if (sequence_no < 0) {
        return {false, "sequenceNo must be non-negative", "E_COMMAND_FAULTY"};
    }

    if (!cmd_meta.contains("announcementHash") || cmd_meta["announcementHash"].is_null()) {
        return {false, "Missing announcementHash", kErrorMissingField};
    }

    // Validate announcementHash type - must be string
    if (!cmd_meta["announcementHash"].is_string()) {
        return {false, "announcementHash must be a string", "E_COMMAND_FAULTY"};
    }

    return {true, "", ""};
}

MessageValidator::ValidationResult MessageValidator::ValidateAnndelMandatoryFields(const nlohmann::json& cmd_meta) {
    // Check for required fields for ANNDEL
    if (!cmd_meta.contains("announcementId") || cmd_meta["announcementId"].is_null()) {
        return {false, "Missing announcementId", kErrorMissingField};
    }

    // Validate announcementId type - must be string, not number
    if (!cmd_meta["announcementId"].is_string()) {
        return {false, "announcementId must be a string, not a number", "E_COMMAND_FAULTY"};
    }

    if (!cmd_meta.contains("channelAddress") || cmd_meta["channelAddress"].is_null()) {
        return {false, "Missing channelAddress", kErrorMissingField};
    }

    // Validate channelAddress type - must be string
    if (!cmd_meta["channelAddress"].is_string()) {
        return {false, "channelAddress must be a string", "E_COMMAND_FAULTY"};
    }

    if (!cmd_meta.contains("deviceCommandId") || cmd_meta["deviceCommandId"].is_null()) {
        return {false, "Missing deviceCommandId", kErrorMissingField};
    }

    // Validate deviceCommandId type - must be string
    if (!cmd_meta["deviceCommandId"].is_string()) {
        return {false, "deviceCommandId must be a string", "E_COMMAND_FAULTY"};
    }

    if (!cmd_meta.contains("sequenceNo")) {
        return {false, "Missing sequenceNo", kErrorMissingField};
    }

    // Validate sequenceNo type - must be integer, not string
    if (!cmd_meta["sequenceNo"].is_number_integer()) {
        return {false, "sequenceNo must be an integer, not a string", "E_COMMAND_FAULTY"};
    }

    // Validate sequenceNo value - must be non-negative
    int64_t sequence_no = cmd_meta["sequenceNo"].get<int64_t>();
    if (sequence_no < 0) {
        return {false, "sequenceNo must be non-negative", "E_COMMAND_FAULTY"};
    }

    // Priority is optional for ANNDEL, but if present, must be valid
    if (cmd_meta.contains("priority")) {
        int priority = cmd_meta.value("priority", -1);
        auto priority_result = ValidatePriority(priority);
        if (!priority_result.is_valid) {
            return priority_result;
        }
    }

    // ANNDEL should not contain ANNOUT-specific fields
    if (cmd_meta.contains("validUntil")) {
        return {false, "ANNDEL command should not contain validUntil field", "E_COMMAND_FAULTY"};
    }

    if (cmd_meta.contains("requestedOutputTime") || cmd_meta.contains("requestedOuputTime")) {
        return {false, "ANNDEL command should not contain requestedOutputTime field", "E_COMMAND_FAULTY"};
    }

    if (cmd_meta.contains("announcementHash")) {
        return {false, "ANNDEL command should not contain announcementHash field", "E_COMMAND_FAULTY"};
    }

    if (cmd_meta.contains("announcementProfile")) {
        return {false, "ANNDEL command should not contain announcementProfile field", "E_COMMAND_FAULTY"};
    }

    return {true, "", ""};
}

bool MessageValidator::IsTimestampInPast(const std::string& timestamp_str) {
    time_t timestamp = ParseISOTimestamp(timestamp_str);
    if (timestamp == -1) return true;
    
    // Get current UTC time for comparison with UTC timestamps
    // std::time(nullptr) returns seconds since epoch in UTC
    time_t now_utc = std::time(nullptr);
    
    // Allow 5 minutes tolerance for network delays and processing time
    const time_t tolerance_seconds = 5 * 60; // 5 minutes
    
    // Convert timestamps to human readable format for debugging
    char timestamp_buf[64], now_utc_buf[64], threshold_buf[64];
    struct tm* timestamp_tm = std::gmtime(&timestamp);
    struct tm* now_utc_tm = std::gmtime(&now_utc);
    time_t threshold_time = now_utc - tolerance_seconds;
    struct tm* threshold_tm = std::gmtime(&threshold_time);
    
    std::strftime(timestamp_buf, sizeof(timestamp_buf), "%Y-%m-%d %H:%M:%S UTC", timestamp_tm);
    std::strftime(now_utc_buf, sizeof(now_utc_buf), "%Y-%m-%d %H:%M:%S UTC", now_utc_tm);
    std::strftime(threshold_buf, sizeof(threshold_buf), "%Y-%m-%d %H:%M:%S UTC", threshold_tm);
    
    std::cout << "=== TIMESTAMP VALIDATION DEBUG ===" << std::endl;
    std::cout << "Input timestamp: " << timestamp_buf << " (epoch: " << timestamp << ")" << std::endl;
    std::cout << "Current UTC time: " << now_utc_buf << " (epoch: " << now_utc << ")" << std::endl;
    std::cout << "Threshold time: " << threshold_buf << " (epoch: " << threshold_time << ")" << std::endl;
    std::cout << "Tolerance: " << tolerance_seconds << " seconds (5 minutes)" << std::endl;
    std::cout << "Is timestamp in past? " << (timestamp < (now_utc - tolerance_seconds)) << std::endl;
    std::cout << "=================================" << std::endl;
    
    return timestamp < (now_utc - tolerance_seconds);
}

bool MessageValidator::IsTimestampExpired(const std::string& timestamp_str) {
    time_t timestamp = ParseISOTimestamp(timestamp_str);
    if (timestamp == -1) return true;
    
    // Get current UTC time for comparison with UTC timestamps
    time_t now_utc = std::time(nullptr);
    return timestamp < now_utc;
}

time_t MessageValidator::ParseISOTimestamp(const std::string& timestamp_str) {
    try {
        // Require UTC timestamps like: 2025-10-03T09:57:11.903000Z
        std::string s = timestamp_str;
        if (s.empty() || (s.back() != 'Z' && s.back() != 'z')) {
            return -1; // not UTC
        }
        s.pop_back(); // drop 'Z'

        // Drop fractional seconds if present
        auto dot = s.find('.');
        if (dot != std::string::npos) {
            s = s.substr(0, dot);
        }

        std::tm tm{};
        std::istringstream ss(s);
        ss >> std::get_time(&tm, "%Y-%m-%dT%H:%M:%S");
        if (ss.fail()) {
            return -1;
        }

        tm.tm_isdst = -1;           // let libc decide; irrelevant for UTC
        time_t t = timegm(&tm);     // interpret tm as UTC
        return (t == static_cast<time_t>(-1)) ? -1 : t;
    } catch (...) {
        return -1;
    }
}
