/**
 * @file AudioFileFetcher.cpp
 * @brief Implementation of the AudioFileFetcher class using CertificateModule.
 *
 * Specification: {S_104} Audio File Fetcher with MD5 checksum verification
 *
 * This module handles fetching audio files either from a local cache
 * (managed by AudioFileCache) or by downloading them securely from a
 * remote HTTPS server using libcurl with dynamic certificate paths.
 *
 * Key Features:
 * - Fetches certificates dynamically from CertificateModule.
 * - Downloads audio files over HTTPS and saves them in the configured cache directory.
 * - Integrates with AudioFileCache to check existing files and store ones.
 * - Thread-safe caching behavior inherited from AudioFileCache.
 * - Uses libcurl with proper TLS validation (peer and host verification).
 */

#include "audio_file_fetcher.h"
#include "log_manager.h"
#include "config_manager.h"
#include <curl/curl.h>
#include <filesystem>
#include <iostream>
#include <mutex>
#include <openssl/evp.h>
#include <fstream>
#include <sstream>
#include <iomanip>

namespace fs = std::filesystem;
namespace {
    constexpr long kTlsVersion = CURL_SSLVERSION_TLSv1_2 | CURL_SSLVERSION_TLSv1_3;
    constexpr long kSslVerifyPeer = 1L;
    constexpr long kSslVerifyHost = 2L;
    constexpr long kCurlVerboseOff = 0L;
}

// Callback function for libcurl to write downloaded data into a file
static size_t WriteFileCallback(void* ptr, size_t size, size_t nmemb, void* stream) {
    FILE* fp = static_cast<FILE*>(stream);
    return fwrite(ptr, size, nmemb, fp);
}

void LogError(const std::string& message) {
    std::cerr << "[ERROR] " << message << std::endl;
}

void LogInfo(const std::string& message) {
    std::cout << "[INFO] " << message << std::endl;
}

// Helper: Calculate MD5 hash of a file and return as hex string (modern EVP API)
std::string CalculateMD5(const std::string& filePath) {
    std::ifstream file(filePath, std::ios::binary); // Open file in binary mode
    if (!file) return ""; // Return empty string if file can't be opened

    EVP_MD_CTX* ctx = EVP_MD_CTX_new(); // Create a new OpenSSL message digest context
    if (!ctx) return ""; // Return empty string if context creation fails

    if (EVP_DigestInit_ex(ctx, EVP_md5(), nullptr) != 1) { // Initialize context for MD5 hashing
        EVP_MD_CTX_free(ctx); // Free context if initialization fails
        return "";
    }

    char buffer[8192]; // Buffer for reading file chunks
    while (file.good()) { // While file is readable
        file.read(buffer, sizeof(buffer)); // Read a chunk into buffer
        auto bytesRead = file.gcount(); // Get number of bytes read
        if (bytesRead > 0) {
            if (EVP_DigestUpdate(ctx, buffer, bytesRead) != 1) { // Update hash context with chunk
                EVP_MD_CTX_free(ctx); // Free context if update fails
                return "";
            }
        }
    }

    unsigned char hash[EVP_MAX_MD_SIZE]; // Buffer for final hash value
    unsigned int hashLen = 0; // Length of hash
    if (EVP_DigestFinal_ex(ctx, hash, &hashLen) != 1) { // Finalize hash calculation
        EVP_MD_CTX_free(ctx); // Free context if finalization fails
        return "";
    }
    EVP_MD_CTX_free(ctx); // Free context after use

    std::ostringstream oss; // String stream for hex conversion
    for (unsigned int i = 0; i < hashLen; i++) {
        oss << std::hex << std::setw(2) << std::setfill('0') << (int)hash[i]; // Convert each byte to hex
    }
    return oss.str(); // Return hex string of MD5 hash
}

// Verify MD5 hash of file matches expected hash string
bool VerifyFileHash(const std::string& filePath, const std::string& expectedHash) {
    std::string calculatedHash = CalculateMD5(filePath);
    if (calculatedHash.empty()) {
        LogError("Failed to compute hash for file: " + filePath);
        return false;
    }
    if (calculatedHash != expectedHash) {
        LogError("Hash mismatch! Expected: " + expectedHash + ", Got: " + calculatedHash);
        return false;
    } 
    // Log success when MD5 hash matches
    LogInfo("✓ MD5 hash verification successful for file: " + filePath);
    LogInfo("  Expected hash: " + expectedHash);
    LogInfo("  Calculated hash: " + calculatedHash);
    return true;
}

AudioFileFetcher::AudioFileFetcher(CertificateModule* certModule, AudioFileCache& cache)
    : certModule_(certModule), cache_(cache) {}

bool AudioFileFetcher::Init() {
    if (!certModule_) {
        LogError("[WARNING]CertificateModule is null. Downloads may fail if mTLS is required.");
    }
    return true;
}

void AudioFileFetcher::Deinit() {}

std::string AudioFileFetcher::FetchAudio(const std::string& uri, const std::string& expectedHash) {
    bool enable_md5 = ConfigManager::GetInstance().IsMd5VerificationEnabled();
    
    std::string cachedFile = cache_.GetAudio(expectedHash);
    if (!cachedFile.empty() && fs::exists(cachedFile)) {
        if (enable_md5) {
            if (VerifyFileHash(cachedFile, expectedHash)) {
                return cachedFile;
            } else {
                fs::remove(cachedFile);
                cache_.RemoveAudio(expectedHash);
                LogError("Removed corrupted cache file: " + cachedFile);
            }
        } else {
            LogInfo("MD5 verification disabled: Skipping hash verification for downloaded file");
            return cachedFile;
        }
    }

    LogInfo("Cache miss or invalid hash for: " + expectedHash + ". Downloading from " + uri);
    const auto& cacheConfig = ConfigManager::GetInstance().GetAudioCache();
    const std::string cacheDir = cacheConfig.directory;
    const std::string cacheFileExt = cacheConfig.file_extension;
    std::string dest_path = cacheDir + "/" + expectedHash + cacheFileExt;

    std::string downloadedFile = DownloadFromNetwork(uri, dest_path);
    
    // TC_57: Check if download returned an error code
    if (downloadedFile.empty() || downloadedFile.find("E_CERT_MISS:") == 0 || downloadedFile.find("E_AUTH_FAIL:") == 0) {
        LogError("Download failed with error: " + downloadedFile);
        return ""; // Return empty string instead of error code
    }
    
    if (!downloadedFile.empty()) {
        if (enable_md5) {
            if (VerifyFileHash(downloadedFile, expectedHash)) {
                cache_.StoreAudio(expectedHash, downloadedFile);
                
                // Verify that caching actually succeeded - CRITICAL for system integrity
                std::string cachedPath = cache_.GetAudio(expectedHash);
                if (cachedPath.empty() || !fs::exists(cachedPath)) {
                    LogError("❌ CRITICAL: Cache storage failed after successful download");
                    // Remove the downloaded file since we can't cache it
                    fs::remove(downloadedFile);
                    return ""; // Return empty to indicate failure
                } else {
                    LogInfo("✓ File successfully downloaded and cached");
                    return downloadedFile;
                }
            } else {
                fs::remove(downloadedFile);
                LogError("Downloaded file hash mismatch and removed: " + downloadedFile);
                std::cout << std::string(60, '=') << std::endl;
                return "";
            }
        } else {
            LogInfo("MD5 verification disabled: Skipping hash verification for downloaded file");
            cache_.StoreAudio(expectedHash, downloadedFile);
            
            // Verify that caching actually succeeded - CRITICAL for system integrity
            std::string cachedPath = cache_.GetAudio(expectedHash);
            if (cachedPath.empty() || !fs::exists(cachedPath)) {
                LogError("❌ CRITICAL: Cache storage failed after successful download");
                // Remove the downloaded file since we can't cache it
                fs::remove(downloadedFile);
                return ""; // Return empty to indicate failure
            } else {
                LogInfo("✓ File successfully downloaded and cached");
                return downloadedFile;
            }
        }
    } else {
        LogError("Failed to download file from: " + uri);
        return "";
    }
}

// Download a file over HTTPS using certificates from CertificateModule
std::string AudioFileFetcher::DownloadFromNetwork(const std::string& url, const std::string& dest_path) {
    if (!certModule_) {
        LogError("[ERROR] CertificateModule not set. Cannot download with mTLS.");
        return "E_CERT_MISS:certificate-module-not-set";
    }

    CURL* curl = curl_easy_init();
    if (!curl) {
        LogError("Failed to initialize curl");
        return "";
    }

    fs::path destFilePath(dest_path);
    fs::path cacheDir = destFilePath.parent_path();
    if (!fs::exists(cacheDir)) {
        fs::create_directories(cacheDir);
        LogInfo("Created cache directory: " + cacheDir.string());
    }

    FILE* fp = fopen(dest_path.c_str(), "wb");
    if (!fp) {
        LogError("Failed to open file: " + dest_path);
        curl_easy_cleanup(curl);
        return "";
    }

    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteFileCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, fp);
    curl_easy_setopt(curl, CURLOPT_SSLVERSION, kTlsVersion);

    // Set cert paths dynamically from CertificateModule
    std::string caCertPath = certModule_->GetCACertPath();
    std::string clientCertPath = certModule_->GetClientCertPath();
    std::string clientKeyPath = certModule_->GetClientKeyPath();

    // Check if client certificate is missing
    if (clientCertPath.empty() || clientKeyPath.empty()) {
        LogError("❌ MISSING CLIENT CERTIFICATE - mTLS authentication required but not available");
        LogError("Client Certificate Path: " + (clientCertPath.empty() ? "MISSING" : clientCertPath));
        LogError("Client Key Path: " + (clientKeyPath.empty() ? "MISSING" : clientKeyPath));
        LogError("Downloading will be aborted due to missing certificate");
        fclose(fp);
        curl_easy_cleanup(curl);
        if (fs::exists(dest_path)) fs::remove(dest_path);
        return "E_CERT_MISS:client-certificate-missing";
    }

    LogInfo("=== Certificate Configuration for Download ===");
    LogInfo("CA Certificate Path: " + (caCertPath.empty() ? "NOT SET" : caCertPath));
    LogInfo("Client Certificate Path: " + (clientCertPath.empty() ? "NOT SET" : clientCertPath));
    LogInfo("Client Key Path: " + (clientKeyPath.empty() ? "NOT SET" : clientKeyPath));

    if (!caCertPath.empty()) {
        curl_easy_setopt(curl, CURLOPT_CAINFO, caCertPath.c_str());
        LogInfo("✓ CA certificate configured for peer verification");
    } else {
        LogInfo("⚠ No CA certificate - using system default CA bundle");
    }
    
    if (!clientCertPath.empty()) {
        curl_easy_setopt(curl, CURLOPT_SSLCERT, clientCertPath.c_str());
        LogInfo("✓ Client certificate configured for mTLS authentication");
    } else {
        LogInfo("⚠ No client certificate - mTLS authentication not available");
    }
    
    if (!clientKeyPath.empty()) {
        curl_easy_setopt(curl, CURLOPT_SSLKEY, clientKeyPath.c_str());
        LogInfo("✓ Client private key configured for mTLS authentication");
    } else {
        LogInfo("⚠ No client private key - mTLS authentication not available");
    }

    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, kSslVerifyPeer);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, kSslVerifyHost);
    curl_easy_setopt(curl, CURLOPT_VERBOSE, kCurlVerboseOff);

    LogInfo("=== SSL/TLS Verification Settings ===");
    LogInfo("Peer verification (CURLOPT_SSL_VERIFYPEER): " + std::to_string(kSslVerifyPeer) + " (1=enabled)");
    LogInfo("Host verification (CURLOPT_SSL_VERIFYHOST): " + std::to_string(kSslVerifyHost) + " (2=enabled)");
    LogInfo("TLS version: TLSv1.2 and TLSv1.3 enforced");
    LogInfo("============================================");

    LogInfo("Starting download from: " + url);

    CURLcode res = curl_easy_perform(curl);
    fclose(fp);

    // Check HTTP status code
    long http_code;
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &http_code);

    // Log download results
    LogInfo("=== Download Results ===");
    LogInfo("CURL result code: " + std::to_string(res) + " (" + (res == CURLE_OK ? "SUCCESS" : curl_easy_strerror(res)) + ")");
    LogInfo("HTTP status code: " + std::to_string(http_code));
    
    if (res == CURLE_OK && http_code < 400) {
        LogInfo("✓ Download completed successfully");
    } else {
        LogInfo("✗ Download failed");
    }
    LogInfo("=======================");

    curl_easy_cleanup(curl);

    if (res != CURLE_OK || http_code >= 400) {
        std::cerr << "[ERROR] Download failed: ";
        if (res != CURLE_OK) {
            std::cerr << curl_easy_strerror(res);
        } else {
            std::cerr << "HTTP " << http_code;
        }
        std::cerr << "\n";
        if (fs::exists(dest_path)) fs::remove(dest_path);
        return "";
    }

    return fs::absolute(destFilePath).string();
}

/**
 * @brief Checks if an audio file exists in the cache.
 * @param hash The unique hash to check in the cache.
 * @return true if file exists in cache, false otherwise.
 */
bool AudioFileFetcher::IsAudioCached(const std::string& hash) {
    // Use the cache's GetAudio method to check if file exists
    // GetAudio returns non-empty path if file exists, empty string if not
    std::string cachedPath = cache_.GetAudio(hash);
    return !cachedPath.empty();
}
