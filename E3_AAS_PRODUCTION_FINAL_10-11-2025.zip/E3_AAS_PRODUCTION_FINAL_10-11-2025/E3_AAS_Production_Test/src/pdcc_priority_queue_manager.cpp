#include "broker_base.h"
#include "pdcc_priority_queue_manager.h"
#include <algorithm>
#include <optional>
#include <iomanip>
#include <sstream>

/**
 * @brief Constructs a PDCCPriorityQueueManager instance.
 *
 * Initializes the priority queue manager with the provided configuration.
 *
 * @param cfg Configuration settings for the queue manager
 */
PDCCPriorityQueueManager::PDCCPriorityQueueManager(const Config& cfg) : cfg_(cfg) {}

/**
 * @brief Comparison operator for priority queue ordering.
 *
 * Defines the ordering: requested_output_time asc, priority desc, sequence_no asc.
 * This creates a min-heap behavior where the earliest job with highest priority
 * and lowest sequence number is at the top.
 *
 * @param a First node to compare
 * @param b Second node to compare
 * @return true if a should come after b in the priority queue
 */
bool PDCCPriorityQueueManager::Cmp::operator()(const Node& a, const Node& b) const {
  const auto& A = a.job;
  const auto& B = b.job;
  if (A.requested_output_time != B.requested_output_time) {
    return A.requested_output_time > B.requested_output_time; // min-heap behavior
  }
  if (A.priority != B.priority) {
    return A.priority < B.priority; // higher priority first (9 > 1)
  }
  return A.sequence_no > B.sequence_no;
}

std::optional<std::chrono::system_clock::time_point>
PDCCPriorityQueueManager::Push(const AnnouncementJob& job) {
    std::lock_guard<std::mutex> lk(mu_);

    if (dedupe_keys_.find(job.DedupeKey()) != dedupe_keys_.end()) {
        std::cout << "[PDCC QUEUE] ⚠ Duplicate job rejected" << std::endl;
        std::cout << "[PDCC QUEUE]    → AnnouncementID: " << job.announcement_id << std::endl;
        return NextWakeupLocked();
    }
    if (heap_.size() >= cfg_.max_pending_jobs) {
        std::cout << "[PDCC QUEUE] ⚠ Queue full - job rejected" << std::endl;
        std::cout << "[PDCC QUEUE]    → Current size: " << heap_.size() << std::endl;
        return NextWakeupLocked();
    }
    
    auto time_t = std::chrono::system_clock::to_time_t(job.requested_output_time);
    std::stringstream ss;
    ss << std::put_time(std::gmtime(&time_t), "%a %b %d %H:%M:%S %Y UTC");
    
    std::cout << "\n[PDCC QUEUE] ➕ Job Added to Priority Queue" << std::endl;
    std::cout << "[PDCC QUEUE]    → AnnouncementID: " << job.announcement_id << std::endl;
    std::cout << "[PDCC QUEUE]    → Priority: " << job.priority << " | Channel: " << job.channel_address << std::endl;
    std::cout << "[PDCC QUEUE]    → Due Time: " << ss.str() << std::endl;
    std::cout << "[PDCC QUEUE]    → Queue Size: " << (heap_.size() + 1) << std::endl;
    
    heap_.push(Node{job});
    dedupe_keys_.insert(job.DedupeKey());
    id_to_channels_.emplace(job.announcement_id, job.channel_address);

    return NextWakeupLocked();
}

size_t PDCCPriorityQueueManager::CancelByAnnouncement(const std::string& announcement_id,
                                                      const std::string& channel_address) {

    std::cout << "\n[PDCC QUEUE] 🗑️  Cancelling job(s)" << std::endl;
    std::cout << "[PDCC QUEUE]    → AnnouncementID: " << announcement_id << std::endl;
    std::lock_guard<std::mutex> lk(mu_);
    // Rebuild-heap strategy (cancel lazily).
    std::vector<Node> nodes;
    nodes.reserve(heap_.size());
    size_t cancelled = 0;

    while (!heap_.empty()) {
        Node n = heap_.top(); heap_.pop();
        bool match = (n.job.announcement_id == announcement_id) &&
                     (channel_address.empty() || n.job.channel_address == channel_address);
        if (match) {
            cancelled++;
            dedupe_keys_.erase(n.job.DedupeKey());
            //id_to_channels_ cleanup below (rebuild).
        } else {
            nodes.push_back(std::move(n));
        }
    }
    for (auto& n : nodes) heap_.push(std::move(n));
    // Rebuild id_to_channels_
    id_to_channels_.clear();
    std::vector<Node> copy;
    copy.reserve(heap_.size());
    while (!heap_.empty()) { copy.push_back(heap_.top()); heap_.pop(); }
    for (auto& n : copy) {
        id_to_channels_.emplace(n.job.announcement_id, n.job.channel_address);
        heap_.push(std::move(n));
    }
    
    if (cancelled > 0) {
        std::cout << "[PDCC QUEUE] ✓ Cancelled " << cancelled << " job(s)" << std::endl;
    } else {
        std::cout << "[PDCC QUEUE] ℹ No matching jobs found to cancel" << std::endl;
    }
    
    return cancelled;
}

std::vector<AnnouncementJob> PDCCPriorityQueueManager::PopDue(
        std::chrono::system_clock::time_point now) {
    std::lock_guard<std::mutex> lk(mu_);
    std::vector<AnnouncementJob> due;
    
    while (!heap_.empty()) {
        const auto& top = heap_.top().job;
        if (top.requested_output_time > now) {
            break;
        }
        auto node = heap_.top(); heap_.pop();
        dedupe_keys_.erase(node.job.DedupeKey());
        if (!node.job.IsExpired(now)) {
            std::cout << "[PDCC QUEUE] ✓ Job is DUE and ready for dispatch" << std::endl;
            std::cout << "[PDCC QUEUE]    → AnnouncementID: " << node.job.announcement_id << std::endl;
            due.push_back(std::move(node.job));
        } else {
            std::cout << "[PDCC QUEUE] ⚠ Job EXPIRED - dropping" << std::endl;
            std::cout << "[PDCC QUEUE]    → AnnouncementID: " << node.job.announcement_id << std::endl;
        }
    }
    // Rebuild id_to_channels_ for remaining nodes (only if we removed any jobs)
    if (!due.empty()) {
        id_to_channels_.clear();
        std::vector<Node> copy;
        copy.reserve(heap_.size());
        while (!heap_.empty()) { copy.push_back(heap_.top()); heap_.pop(); }
        for (auto& n : copy) {
            id_to_channels_.emplace(n.job.announcement_id, n.job.channel_address);
            heap_.push(std::move(n));
        }
    }
    return due;
}

std::optional<std::chrono::system_clock::time_point> PDCCPriorityQueueManager::NextWakeup() const {
    std::lock_guard<std::mutex> lk(mu_);
    return NextWakeupLocked();
}

std::optional<std::chrono::system_clock::time_point> PDCCPriorityQueueManager::NextWakeupLocked() const {
    if (heap_.empty()) return std::nullopt;
    return heap_.top().job.requested_output_time;
}

size_t PDCCPriorityQueueManager::Size() const {
    std::lock_guard<std::mutex> lk(mu_);
    return heap_.size();
}

void PDCCPriorityQueueManager::RegisterJobState(const AnnouncementJob& job) {
    std::lock_guard<std::mutex> lk(state_mu_);
    auto& s = state_by_ann_[job.announcement_id];
    // First observation defaults to queued; do not overwrite a success/error.
    if (s.state == DownloadState::kQueued) {
        s.local_file_path.clear();
    }
}

bool PDCCPriorityQueueManager::UpdateDownloadStatus(const std::string& announcement_id,
                                                    DownloadState state,
                                                    const std::string& local_file_path) {
    std::lock_guard<std::mutex> lk(state_mu_);
    // Always create/update the entry, don't require it to exist first
    auto& status = state_by_ann_[announcement_id];
    status.state = state;
    
    if (state == DownloadState::kSuccess) {
        status.local_file_path = local_file_path;
    } else if (state == DownloadState::kError) {
        status.local_file_path.clear();
    }
    return true;
}

bool PDCCPriorityQueueManager::GetDownloadStatus(const std::string& announcement_id,
                                                 DownloadStatus* out) const {
    if (!out) return false;
    std::lock_guard<std::mutex> lk(state_mu_);
    auto it = state_by_ann_.find(announcement_id);
    if (it == state_by_ann_.end()) return false;
    *out = it->second;
    return true;
}

void PDCCPriorityQueueManager::UpdateAudioStatus(const std::string& announcement_id,
                                    const std::string& status,
                                    const std::string& file_path) {
    std::lock_guard<std::mutex> lk(state_mu_);
    DownloadStatus download_status;
    download_status.local_file_path = file_path;
    
    if (status == "Success") {
        download_status.state = DownloadState::kSuccess;
    } else if (status == "InProgress") {
        download_status.state = DownloadState::kInProgress;
    } else if (status == "Pending") {
        download_status.state = DownloadState::kPending;
    } else {
        download_status.state = DownloadState::kError;
    }
    
    state_by_ann_[announcement_id] = download_status;
}
