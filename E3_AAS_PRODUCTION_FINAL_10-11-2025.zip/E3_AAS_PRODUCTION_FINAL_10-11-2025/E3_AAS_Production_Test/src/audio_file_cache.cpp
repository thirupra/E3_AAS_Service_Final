/**
 * @file AudioFileCache.cpp
 * @brief Thread-safe disk-backed audio cache with asynchronous LRU eviction.
 *
 * @details
 * This module implements a disk-backed audio cache that stores audio files
 * (specifically, `.ogg` files) on the local filesystem. It uses a **Least
 * Recently Used (LRU)** eviction policy based on **total cache size in bytes**
 * to manage storage. The eviction process runs on a dedicated background thread
 * to prevent blocking of the main application logic, ensuring that `StoreAudio`
 * and `GetAudio` operations remain fast and non-blocking.
 *
 * The class is thread-safe, utilizing mutexes and a condition variable to
 * safely coordinate access between the main application thread and the
 * eviction thread, preventing data races. It also handles on-disk persistence
 * by automatically loading existing `.ogg` files from the cache directory on
 * startup.
 *
 * @spec {S_105} Audio Cache Management and Eviction Policy
 * @author Thirupathi Rao
 * @date 2025-09-09
 */

#include "audio_file_cache.h"
#include "config_manager.h"
#include <filesystem>
#include <iostream>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <atomic>
#include <list>
#include <unordered_map>
#include <iomanip>
#include <sstream>

namespace fs = std::filesystem;

/**
 * @brief Anonymous namespace for internal constants and data structures.
 */
namespace {
    /**
     * @brief A structure to hold information about a cached audio file.
     * @details This structure combines the file's path, its size, and an
     * iterator to its position in the LRU list, allowing for efficient
     * updates and lookups.
     */
    struct CacheEntry {
        std::string path;                        ///< Absolute path to the file on disk.
        std::list<std::string>::iterator lruIt;  ///< Iterator to the hash's position in the LRU list.
        size_t sizeBytes;                        ///< Size of the file in bytes.
    };
}

/**
 * @brief Constructs the `AudioFileCache` instance.
 *
 * @details Initializes the cache with a maximum size limit in bytes. It creates
 * the cache directory on disk if it doesn't already exist and launches the
 * dedicated background thread for asynchronous eviction.
 *
 * @param maxBytes The maximum total size in bytes for the cache before eviction begins.
 */
AudioFileCache::AudioFileCache(size_t maxBytes)
    : maxBytes_(maxBytes), currentBytes_(0),
      eviction_requested_(false), stop_eviction_thread_(false) 
{
    const auto& cacheConfig = ConfigManager::GetInstance().GetAudioCache();
    const std::string cacheDir = cacheConfig.directory;
    
    if (!fs::exists(cacheDir)) {
        std::cout << "[Cache] Creating directory " << cacheDir << std::endl;
        fs::create_directory(cacheDir);
    }
    eviction_thread_ = std::thread(&AudioFileCache::EvictionLoop, this);
}

/**
 * @brief Initializes the cache by loading existing audio files from disk.
 *
 * @details This method scans the configured cache directory and populates the
 * internal LRU list and cache map with any existing audio files. It also
 * calculates the total size of the existing files. This ensures that the
 * cache persists across application restarts.
 *
 * @return `true` if the initialization is successful, `false` on a filesystem error.
 */
bool AudioFileCache::Init() {
    std::lock_guard<std::mutex> lock(mutex_);
    try {
        const auto& cacheConfig = ConfigManager::GetInstance().GetAudioCache();
        const std::string cacheDir = cacheConfig.directory;
        const std::string cacheFileExt = cacheConfig.file_extension;
        
        for (const auto &entry : fs::directory_iterator(cacheDir)) {
            if (entry.path().extension() == cacheFileExt) {
                std::string filename = entry.path().filename().string();
                std::string hash = filename.substr(0, filename.size() - cacheFileExt.size());
                size_t fsize = fs::file_size(entry.path());

                lruList_.push_front(hash);
                cacheMap_[hash] = {entry.path().string(), lruList_.begin(), fsize};
                currentBytes_ += fsize;
            }
        }
    } catch (const fs::filesystem_error& e) {
        std::cerr << "[Cache] Error initializing cache: " << e.what() << std::endl;
        return false;
    }
    return true;
}

/**
 * @brief Cleanly stops the eviction thread and releases resources.
 *
 * @details This method sets the `stop_eviction_thread_` flag, notifies the
 * eviction thread via the condition variable, and waits for it to join. This
 * ensures that the thread finishes its work and terminates safely before the
 * application exits.
 */
void AudioFileCache::Deinit() {
    stop_eviction_thread_ = true;
    eviction_cv_.notify_one();
    if (eviction_thread_.joinable()) {
        eviction_thread_.join();
    }
}

/**
 * @brief Retrieves the absolute path of a cached audio file by its hash key.
 *
 * @details This function is thread-safe. If the file is found, it "touches"
 * the entry, marking it as the most recently used to prevent it from being
 * evicted soon.
 *
 * @param hash The unique hash key of the audio file.
 * @return The absolute file path as a string if the file is found, an empty string otherwise.
 */
std::string AudioFileCache::GetAudio(const std::string& hash) {
    std::lock_guard<std::mutex> lock(mutex_);
    auto it = cacheMap_.find(hash);
    if (it != cacheMap_.end()) {
        std::cout << "[Cache] Found audio for hash: " << hash
          << " at " << it->second.path << std::endl;
        std::cout << std::string(60, '=') << std::endl;
        touch(hash);
        return it->second.path;
        
    }
    
    std::cout << "[Cache] No audio found for hash: " << hash << std::endl;
    std::cout << std::string(60, '=') << std::endl;
    return "";
}

/**
 * @brief Adds or updates an audio file in the cache.
 *
 * @details This method is thread-safe. If the file already exists, it updates
 * its path and "touches" it. If it's a new file, it's added to the cache, and
 * the `currentBytes_` count is updated. After adding, it checks if the cache
 * size exceeds the maximum byte limit. If so, it triggers an asynchronous
 * eviction by notifying the eviction thread.
 *
 * @param hash The unique hash key of the audio file.
 * @param filePath The path to the audio file on disk.
 */
void AudioFileCache::StoreAudio(const std::string& hash, const std::string& filePath) {
    std::lock_guard<std::mutex> lock(mutex_);
    std::string absPath = fs::absolute(filePath).string();
    size_t fsize = fs::file_size(absPath);
    std::cout << "[Cache] 📥 Adding new file to cache:" << std::endl;
    std::cout << "[Cache] File size: " << (fsize / 1000) << " KB" << std::endl;
    
    // Check if file is larger than the entire cache limit
    if (fsize > maxBytes_) {
        std::cout << "[Cache] ⚠️  WARNING: File size (" << (fsize / (1000 * 1000)) 
                  << " MB) exceeds cache limit (" << (maxBytes_ / (1000 * 1000)) 
                  << " MB). Rejecting file." << std::endl;
        return; // Don't cache oversized files
    }
    
    auto it = cacheMap_.find(hash);
    if (it != cacheMap_.end()) {
        // Update path & size for an existing file
        currentBytes_ -= it->second.sizeBytes;
        it->second.path = absPath;
        it->second.sizeBytes = fsize;
        currentBytes_ += fsize;
        touch(hash);
    } else {
        lruList_.push_front(hash);
        cacheMap_[hash] = {absPath, lruList_.begin(), fsize};
        currentBytes_ += fsize;
    }

    if (currentBytes_ > maxBytes_) {
        std::cout << "[Cache] ⚠️  Cache limit exceeded! Triggering LRU eviction..." << std::endl;
        {
            std::lock_guard<std::mutex> eviction_lock(eviction_mutex_);
            eviction_requested_ = true;
        }
        eviction_cv_.notify_one();
    }
}

/**
 * @brief Marks a cache entry as recently used.
 *
 * @details This private helper function moves a given key's entry to the front
 * of the `lruList_`. This is the core logic of the LRU policy. It should only be
 * called when the main `mutex_` is already held.
 *
 * @param key The hash key of the entry to "touch".
 */
void AudioFileCache::touch(const std::string& key) {
    auto it = cacheMap_.find(key);
    if (it == cacheMap_.end()) return;

    lruList_.erase(it->second.lruIt);
    lruList_.push_front(key);
    it->second.lruIt = lruList_.begin();
}

/**
 * @brief The background loop that asynchronously evicts files.
 *
 * @details This function is the entry point for the `eviction_thread_`. It
 * waits on the `eviction_cv_` for an eviction request or a stop signal. When
 * an eviction is requested, it acquires the main cache mutex and evicts the
 * least recently used files until the cache size is within the maximum byte limit.
 *
 * The eviction process involves removing the last element from the `lruList_`,
 * deleting the corresponding file from disk, and removing the entry from the
 * `cacheMap_`.
 */
void AudioFileCache::EvictionLoop() {
    std::unique_lock<std::mutex> lock(eviction_mutex_);
    while (!stop_eviction_thread_) {
        eviction_cv_.wait(lock, [this] {
            return eviction_requested_ || stop_eviction_thread_;
        });

        if (stop_eviction_thread_) break;

        {
            std::lock_guard<std::mutex> cache_lock(mutex_);
            while (currentBytes_ > maxBytes_ && !lruList_.empty()) {
                std::string lru_hash = lruList_.back();
                lruList_.pop_back();

                auto it = cacheMap_.find(lru_hash);
                if (it != cacheMap_.end()) {
                    const auto& cacheConfig = ConfigManager::GetInstance().GetAudioCache();
                    const std::string cacheDir = cacheConfig.directory;
                    const std::string cacheFileExt = cacheConfig.file_extension;
                    
                    size_t fsize = it->second.sizeBytes;
                    fs::path fileToRemove = fs::path(cacheDir) / (lru_hash + cacheFileExt);

                    std::cout << "[Cache] 🎯 Evicting LRU file: " << lru_hash.substr(0, 8) << "..." << std::endl;
                    std::cout << "[Cache] File path: " << fileToRemove << std::endl;
                    std::cout << "[Cache] File size: " << (fsize / 1000) << " KB" << std::endl;
                    
                    // Check if file exists BEFORE removal
                    bool file_exists_before = fs::exists(fileToRemove);
                    std::cout << "[Cache] File exists before removal: " << (file_exists_before ? "YES" : "NO") << std::endl;
                    
                    if (file_exists_before) {
                        try {
                            // Get file size before removal for verification
                            size_t actual_size = fs::file_size(fileToRemove);
                            std::cout << "[Cache] Actual file size on disk: " << (actual_size / 1000) << " KB" << std::endl;
                            
                            // Remove the file
                            bool removal_success = fs::remove(fileToRemove);
                            std::cout << "[Cache] File removal success: " << (removal_success ? "YES" : "NO") << std::endl;
                            
                            // Verify file is gone
                            bool file_exists_after = fs::exists(fileToRemove);
                            std::cout << "[Cache] File exists after removal: " << (file_exists_after ? "YES" : "NO") << std::endl;
                            
                            if (file_exists_after) {
                                std::cout << "[Cache] ⚠️  WARNING: File still exists after removal attempt!" << std::endl;
                                // Try to get file size after "removal"
                                try {
                                    size_t size_after = fs::file_size(fileToRemove);
                                    std::cout << "[Cache] File size after 'removal': " << (size_after / 1000) << " KB" << std::endl;
                                } catch (const std::exception& e) {
                                    std::cout << "[Cache] Cannot get file size after 'removal': " << e.what() << std::endl;
                                }
                            }
                            
                        } catch (const std::exception& e) {
                            std::cout << "[Cache] ❌ Exception during file removal: " << e.what() << std::endl;
                        }
                    }

                    // Update cache size
                    currentBytes_ -= fsize;
                    std::cout << "[Cache] Updated cache size: " << (currentBytes_ / (1000 * 1000)) << "/" << (maxBytes_ / (1000 * 1000)) << " MB" << std::endl;

                    // Remove from cache map
                    cacheMap_.erase(it);
                    
                    std::cout << "[Cache] Cache entry removed from memory" << std::endl;
                    std::cout << "[Cache] " << std::string(50, '-') << std::endl;
                }
            }
        }
        eviction_requested_ = false;
    }
    std::cout << std::string(60, '=') << std::endl;
}

/**
 * @brief Removes an audio file from the cache by its hash key.
 *
 * @details Deletes the cached file from disk and erases its record from
 * the internal LRU list and cache map. Thread-safe.
 *
 * @param hash The unique hash key of the audio file.
 */
void AudioFileCache::RemoveAudio(const std::string& hash) {
    std::lock_guard<std::mutex> lock(mutex_);

    auto it = cacheMap_.find(hash);
    if (it != cacheMap_.end()) {
        const auto& cacheConfig = ConfigManager::GetInstance().GetAudioCache();
        const std::string cacheDir = cacheConfig.directory;
        const std::string cacheFileExt = cacheConfig.file_extension;
        
        fs::path fileToRemove = fs::path(cacheDir) / (hash + cacheFileExt);

        if (fs::exists(fileToRemove)) {
            try {
                size_t fsize = it->second.sizeBytes;
                fs::remove(fileToRemove);
                std::cout << "[Cache] Removed cached audio file: " << fileToRemove << " (" << (fsize / 1000) << " KB)" << std::endl;
            } catch (const std::exception& e) {
                std::cerr << "[Cache] Failed to remove file " << fileToRemove << ": " << e.what() << std::endl;
            }
        }

        currentBytes_ -= it->second.sizeBytes;

        // Remove from LRU list
        lruList_.erase(it->second.lruIt);

        // Remove from cache map
        cacheMap_.erase(it);
    } else {
        std::cout << "[Cache] Attempted to remove non-existent hash from cache: " << hash << std::endl;
    }
}