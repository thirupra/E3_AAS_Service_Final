#include "compression_utils.h"
#include "config_manager.h"
#include <zlib.h>
#include <vector>
#include <cstring>
#include <stdexcept>
#include <sstream>

namespace CompressionUtils {

std::string GzipCompress(const std::string& input) {
    if (input.empty()) return std::string();

    const auto& comp_config = ConfigManager::GetInstance().GetCompression();
    
    z_stream zs;
    std::memset(&zs, 0, sizeof(zs));
    if (deflateInit2(&zs, Z_DEFAULT_COMPRESSION, Z_DEFLATED, comp_config.gzip_window_bits, 8, Z_DEFAULT_STRATEGY) != Z_OK) {
        return {};
    }

    zs.next_in = reinterpret_cast<Bytef*>(const_cast<char*>(input.data()));
    zs.avail_in = static_cast<uInt>(input.size());

    std::string out;
    std::vector<char> buffer(comp_config.buffer_size_bytes);
    int ret;
    do {
        zs.next_out = reinterpret_cast<Bytef*>(buffer.data());
        zs.avail_out = static_cast<uInt>(buffer.size());
        ret = deflate(&zs, zs.avail_in ? Z_NO_FLUSH : Z_FINISH);
        if (ret == Z_STREAM_ERROR) { deflateEnd(&zs); return {}; }
        size_t have = buffer.size() - zs.avail_out;
        out.append(buffer.data(), have);
    } while (ret != Z_STREAM_END);

    deflateEnd(&zs);
    return out;
}

std::string DecompressGzip(const uint8_t* data, size_t length) {
    if (length == 0) return "";

    if (length < 2 || data[0] != 0x1f || data[1] != 0x8b) {
        std::stringstream ss; ss << "Invalid Gzip header";
        throw std::runtime_error(ss.str());
    }

    const auto& comp_config = ConfigManager::GetInstance().GetCompression();
    
    z_stream zs;
    std::memset(&zs, 0, sizeof(zs));
    if (inflateInit2(&zs, comp_config.gzip_window_bits) != Z_OK) {
        throw std::runtime_error("inflateInit2 failed");
    }

    zs.next_in = const_cast<Bytef*>(data);
    zs.avail_in = static_cast<uInt>(length);

    std::string out;
    std::vector<char> buffer(comp_config.buffer_size_bytes);
    int ret;
    do {
        zs.next_out = reinterpret_cast<Bytef*>(buffer.data());
        zs.avail_out = static_cast<uInt>(buffer.size());
        ret = inflate(&zs, Z_NO_FLUSH);
        if (ret != Z_OK && ret != Z_STREAM_END) {
            inflateEnd(&zs);
            std::stringstream ss; ss << "inflate error: " << ret;
            throw std::runtime_error(ss.str());
        }
        size_t have = buffer.size() - zs.avail_out;
        out.append(buffer.data(), have);
    } while (ret != Z_STREAM_END);

    inflateEnd(&zs);
    return out;
}

} // namespace CompressionUtils