/**
 * @file AMQPHandler.cpp
 * @brief Manages AMQP message processing and broker communication per {S_102} specification.
 *
 * @details
 * The `AMQPHandler` class is a singleton responsible for handling AMQP-based message
 * processing for Physical Device Command and Control (PDCC) messages. It connects to
 * an AMQP broker, subscribes to a queue, consumes messages, and delegates audio
 * download tasks to a `DownloadManager`. Key responsibilities include:
 * - Establishing and maintaining a robust connection to the AMQP broker with retry logic.
 * - Consuming messages in a dedicated thread, decompressing GZIP-encoded messages if needed.
 * - Parsing and validating JSON PDCC messages, ensuring all commands are valid before processing.
 * - Publishing acknowledgment (info) and error (aag-nack) messages via `PPMReporter`.
 * - Monitoring connection health with a watchdog thread to trigger automatic reconnects.
 *
 * The class uses a singleton pattern to ensure a single instance manages the AMQP connection,
 * avoiding resource conflicts. It employs thread-safe mechanisms (e.g., mutexes, atomic flags)
 * to handle concurrent operations and connection recovery. The design prioritizes reliability
 * and fault tolerance, with exponential backoff for reconnects and comprehensive error handling
 * to prevent message loss or system crashes. Logging uses `LOG_INFO`/`LOG_ERROR` from `BrokerBase`
 * for thread-safe, consistent output.
 *
 * @note This class assumes `BrokerBase` provides core AMQP connection functionality and
 * `PPMReporter` handles publishing responses. If certificates are unavailable, it relies on
 * `BrokerBase` to fall back to plain TCP (port 5672) to address connection issues.
 *
 * @see BrokerBase, PPMReporter, DownloadManager
 * @spec {S_102} AMQP Messaging and PDCC Processing
 * @author Thirupathi Rao
 * @date 2025-09-09
 */

#include "amqp_handler.h"
#include "log_manager.h"
#include "ppm_reporter.h"
#include "message_validator.h"
#include "compression_utils.h"
#include "config_manager.h"
#include <chrono>
#include <iostream>
#include <nlohmann/json.hpp>
#include <thread>
#include <zlib.h>
#include <vector>
#include <stdexcept>
#include <ctime>
#include <unordered_set>
#include "announcement_job.h"


/**
 * @brief Anonymous namespace for message type constants.
 */
namespace {
    const std::string kMsgTypeInfo = "info";            ///< Message type for info events.
    const std::string kMsgTypeError = "error";          ///< Message type for error events.
    const std::string kEventPdcReceived = "pdc-received";///< Event for received commands.
    const std::string kEventAagNack = "aag-nack";       ///< Event for negative acknowledgment.
    const std::string kGzipEncoding = "gzip";           ///< GZIP encoding identifier.
}

/**
 * @brief Static pointer to the singleton instance of `AMQPHandler`.
 *
 * This is initialized to `nullptr` and is managed by the `GetInstance()`
 * and `DestroyInstance()` methods to ensure only one instance of the class exists.
 */
AMQPHandler* AMQPHandler::instance_ = nullptr;

/**
 * @brief Constructs an AMQPHandler instance with a specific broker configuration.
 *
 * This constructor initializes the handler's base class with the provided
 * broker configuration and sets up the initial state for its internal components,
 * including pointers to other modules and atomic flags for thread control.
 *
 * @param config A constant reference to the BrokerConfig struct, which contains
 * all necessary parameters for connecting to the AMQP broker.
 * @param certModule A pointer to the CertificateModule instance, which the
 * handler will use to get certificate paths for mTLS.
 */
AMQPHandler::AMQPHandler(const BrokerConfig& config, CertificateModule* certModule, PDCCPriorityQueueManager* pdccQueueManager)
    : BrokerBase(config, certModule),
      running_(false),
      downloadManager_(nullptr),
      last_message_time_(std::chrono::steady_clock::now()),
      watching_(false),
      pdccQueueManager_(pdccQueueManager) {
    
}

/**
 * @brief Destructor, gracefully stops threads and disconnects.
 *
 * This ensures a clean shutdown of all worker threads and the AMQP connection
 * when the `AMQPHandler` object is destroyed, preventing resource leaks and
 * hung threads. It calls `Stop()` to join all threads before disconnecting.
 */
AMQPHandler::~AMQPHandler() {
    Stop();
    Disconnect();
}

/**
 * @brief Gets the singleton instance, creating it if needed.
 *
 * This method is the primary access point for the `AMQPHandler`. It uses
 * a thread-safe check to create the instance on the first call.
 *
 * @return A pointer to the singleton `AMQPHandler` instance.
 */
AMQPHandler* AMQPHandler::GetInstance(const BrokerConfig& config, CertificateModule* certModule, PDCCPriorityQueueManager* pdccQueueManager) {
    if (!instance_) {
        instance_ = new AMQPHandler(config, certModule, pdccQueueManager);
    }
    return instance_;
}

/**
 * @brief Deletes the singleton instance.
 *
 * This method should be called once at the end of the application's lifetime
 * to deallocate the memory for the singleton and ensure a clean exit.
 */
void AMQPHandler::DestroyInstance() {
    delete instance_;
    instance_ = nullptr;
}

/**
 * @brief Connects to the AMQP broker.
 *
 * This method delegates the connection logic to the base `BrokerBase` class.
 *
 * @return `true` if the connection succeeds, `false` otherwise.
 */
bool AMQPHandler::Connect() { return BrokerBase::Connect(); }

/**
 * @brief Disconnects from the broker after stopping threads.
 *
 * This method first calls `Stop()` to terminate the worker threads, then
 * disconnects the AMQP connection via the base class.
 */
void AMQPHandler::Disconnect() {
    Stop();
    BrokerBase::Disconnect();
}

void AMQPHandler::SetPPMEmitter(PPMEmitter* e) { 
    ppm_ = e; 
}

void AMQPHandler::SetAASApp(AASApp* aas_app) {
    aas_app_ = aas_app;
}
/**
 * @brief Attempts to connect to the broker with a limited number of retries.
 *
 * This provides a robust way to handle temporary network issues. It repeatedly
 * calls `Connect()` with a configurable delay between attempts until a
 * connection is established or the maximum number of retries is reached.
 *
 * @param max_retries The maximum number of connection attempts.
 * @param delay_seconds The delay in seconds between each retry.
 * @return `true` if the connection succeeds within the retry limit, `false` otherwise.
 */
bool AMQPHandler::ConnectWithRetry(int max_retries, int delay_seconds) {
    int attempt = 0;
    while (attempt < max_retries) {
        if (Connect()) return true;
        LOG_INFO("[AMQPHandler] Connect attempt " + std::to_string(attempt + 1) +
                  " failed. Retrying in " + std::to_string(delay_seconds) + " seconds...");
        std::this_thread::sleep_for(std::chrono::seconds(delay_seconds));
        ++attempt;
    }
    return false;
}

/**
 * @brief Sets up the subscription to the configured queue.
 *
 * This function is called after a successful connection to configure the
 * AMQP channel for message consumption. It does not start the consumer thread.
 *
 * @return `true` if the subscription succeeds, `false` otherwise.
 */

bool AMQPHandler::PostConnectSetup() {
    SetMessageCallback(std::bind(&AMQPHandler::ReceivedMessage, this, std::placeholders::_1));
    return true;
}

/**
 * @brief Subscribes to a queue and configures prefetch settings.
 *
 * This method sets the prefetch count to limit the number of unacknowledged
 * messages the client can receive, which is an important flow control mechanism.
 * It also initiates the basic `consume` operation on the specified queue.
 *
 * @param topic The name of the queue to subscribe to.
 * @param callback The function to call for each received message.
 * @return `true` if the subscription succeeds, `false` otherwise.
 */
bool AMQPHandler::Subscribe(const std::string& topic, const MessageCallback& callback) {
    // Store the provided callback function.
    SetMessageCallback(callback);

    // Get channel ID from ConfigManager
    const auto& amqpConfig = ConfigManager::GetInstance().GetAmqp();
    
    // Set the prefetch count to control message flow.
    amqp_basic_qos(conn_, amqpConfig.channel_id, 0, config_.prefetch_count, 0);
    amqp_rpc_reply_t qos_reply = amqp_get_rpc_reply(conn_);
    if (qos_reply.reply_type != AMQP_RESPONSE_NORMAL) {
        LOG_ERROR("[AMQPHandler] Failed to set prefetch count");
        return false;
    }
    
    // Start consuming messages from the queue.
    amqp_basic_consume(conn_, amqpConfig.channel_id, amqp_cstring_bytes(topic.c_str()),
                       amqp_empty_bytes, 0, 0, 0, amqp_empty_table);

    amqp_rpc_reply_t reply = amqp_get_rpc_reply(conn_);
    if (reply.reply_type != AMQP_RESPONSE_NORMAL) {
        LOG_ERROR("[AMQPHandler] Basic consume failed on queue: " + topic);
        return false;
    }
    return true;
}

/**
 * @brief Starts the AMQPHandler worker threads.
 *
 * This function launches three dedicated threads:
 * 1. `consumer_thread_`: Runs the `ConsumeLoop()` to pull messages from the broker.
 * 2. `watch_thread_`: Runs the `WatchdogLoop()` to monitor for stalled connections.
 * 3. `reconnect_thread_`: Runs the `ReconnectHandlerLoop()` to manage reconnections.
 *
 * The function is **idempotent** and **thread-safe** to prevent multiple
 * simultaneous launches. It uses a `std::lock_guard` to protect against
 * race conditions.
 */
void AMQPHandler::Start() {
    std::lock_guard<std::mutex> lk(start_stop_mutex_);

    // If already running, do nothing.
    if (running_.load()) {
        return;
    }

    // Mark handler as running and watching.
    running_.store(true);
    watching_ = true;
    last_message_time_ = std::chrono::steady_clock::now();

    // Consumer thread
    consumer_thread_ = std::thread([this]() {
        try {
            ConsumeLoop();
        } catch (const std::exception& ex) {
            LOG_ERROR("[AMQPHandler] Unhandled exception in consumer thread: " + std::string(ex.what()));
        } catch (...) {
            LOG_ERROR("[AMQPHandler] Unknown exception in consumer thread");
        }
    });

    // Watchdog thread
    watch_thread_ = std::thread([this]() {
        try {
            WatchdogLoop();
        } catch (const std::exception& ex) {
            LOG_ERROR("Unhandled exception in watchdog thread: " + std::string(ex.what()));
        } catch (...) {
            LOG_ERROR("[AMQPHandler] Unknown exception in watchdog thread");
        }
    });

    // Reconnect handler thread
    reconnect_thread_ = std::thread([this]() {
        try {
            ReconnectHandlerLoop();
        } catch (const std::exception& ex) {
            LOG_ERROR("Unhandled exception in reconnect thread: " + std::string(ex.what()));
        } catch (...) {
            LOG_ERROR("[AMQPHandler] Unknown exception in reconnect thread");
        }
    });

}

/**
 * @brief Stops the AMQP consumer threads.
 *
 * This function signals the worker threads to exit and waits for them to
 * terminate gracefully. It uses an atomic flag `running_` and a
 * `std::lock_guard` to ensure a thread-safe shutdown.
 *
 * @param fullShutdown If `true`, also stops the watchdog and reconnect loops.
 * This should be used for a full application shutdown.
 */
void AMQPHandler::Stop(bool fullShutdown) {
    std::lock_guard<std::mutex> lk(start_stop_mutex_); // Ensure thread-safe stop

    running_.store(false); // Signal ConsumeLoop to exit

    if (consumer_thread_.joinable() && consumer_thread_.get_id() != std::this_thread::get_id()) {
        try {
            consumer_thread_.join();
        } catch (const std::system_error& ex) {
            LOG_ERROR("[AMQPHandler] Error joining consumer thread: " + std::string(ex.what())); 
        }
    }

    if (fullShutdown) {
        watching_.store(false);
        reconnect_cv_.notify_all(); // Wake up reconnect thread

        if (watch_thread_.joinable() && watch_thread_.get_id() != std::this_thread::get_id()) {
            try {
                watch_thread_.join();
                LOG_INFO("Watchdog thread stopped");
            } catch (const std::system_error& ex) {
                LOG_ERROR("[AMQPHandler] Error joining watchdog thread: " + std::string(ex.what()));
            }
        }

        if (reconnect_thread_.joinable() && reconnect_thread_.get_id() != std::this_thread::get_id()) {
            try {
                reconnect_thread_.join();
                LOG_INFO("Reconnect thread stopped");
            } catch (const std::system_error& ex) {
                LOG_ERROR("Error joining reconnect thread: " + std::string(ex.what()));
            }
        }
    }

    LOG_INFO("[AMQPHandler] Stop() completed" + std::string(fullShutdown ? " (full shutdown)" : " (consumer only)"));
}


/**
 * @brief Handles broker reconnects in a dedicated loop.
 *
 * This function runs in the `reconnect_thread_` and is responsible for
 * managing connection recovery. It waits on a condition variable (`reconnect_cv_`)
 * for a reconnect request from either the `ConsumeLoop()` or `WatchdogLoop()`.
 * When a request is received, it stops the consumer thread, cleans up the
 * connection, and attempts to re-initialize the connection with a backoff strategy.
 *
 * The loop exits only when a full shutdown is requested.
 */
void AMQPHandler::ReconnectHandlerLoop() {
    std::unique_lock<std::mutex> lock(reconnect_mutex_);
    int retry_count = 0;
    const int max_backoff_seconds = 60;

    while (watching_) {
        reconnect_cv_.wait(lock, [this]() { return reconnect_requested_.load() || !watching_; });

        if (!watching_){
            LOG_INFO("ReconnectHandlerLoop exiting due to shutdown");
            break;
        } 
        

        if (reconnect_requested_.load()) {
            LOG_INFO("Handling reconnect (attempt " + std::to_string(retry_count + 1) + ")");

            // Ensure consumer thread is stopped and joined.
            {
                std::lock_guard<std::mutex> lk(start_stop_mutex_);
                Stop(false); // Stop consumer only.
            }

            // Disconnect and clean up the AMQP connection.
            try {
                Disconnect();
            } catch (const std::exception& ex) {
                LOG_ERROR("Error during disconnect: " + std::string(ex.what()));
            }

            // Retry connection with exponential backoff.
            int backoff = std::min(config_.retry_delay_secs * (1 << retry_count), max_backoff_seconds);
            while (watching_ && !Init()) {
                LOG_ERROR("Reconnect failed, retrying in " + std::to_string(backoff) + " seconds...");
                std::this_thread::sleep_for(std::chrono::seconds(backoff));
                //retry_count++;
                retry_count = std::min(retry_count + 1, 6); // cap to avoid overflow
                backoff = std::min(config_.retry_delay_secs * (1 << retry_count), max_backoff_seconds);
            }

            // Start new consumer thread only if connection succeeded.
            if (watching_) {
                std::lock_guard<std::mutex> lk(start_stop_mutex_);
                try {
                    if (consumer_thread_.joinable()) {
                        LOG_ERROR("Warning: consumer_thread_ still joinable before restart");
                        consumer_thread_.join(); // Ensure old thread is fully terminated.
                    }
                    consumer_thread_ = std::thread([this]() {
                        try {
                            ConsumeLoop();
                        } catch (const std::exception& ex) {
                            LOG_ERROR("Unhandled exception in consumer thread: " + std::string(ex.what()));
                        }
                    });
                    LOG_INFO("[AMQPHandler] ConsumeLoop restarted after reconnect");
                    retry_count = 0; // Reset retry count on success.
                } catch (const std::system_error& ex) {
                    LOG_ERROR("Failed to start consumer thread: " + std::string(ex.what()));
                    reconnect_requested_.store(true); // Retry on next iteration.
                    continue;
                }
            }

            reconnect_requested_.store(false);
        }
    }

    LOG_INFO("[AMQPHandler] ReconnectHandlerLoop exiting.");
}

/**
 * @brief Initializes the AMQP connection and starts consumer/watchdog threads.
 *
 * This function provides a robust initialization sequence. It first connects
 * to the broker with a retry mechanism, then sets up the subscription. Finally,
 * it launches the worker threads if they are not already running. This makes the
 * function idempotent and safe to call multiple times.
 *
 * @return `true` if initialization succeeded, `false` otherwise.
 */
bool AMQPHandler::Init() {
    LOG_INFO("Initializing AMQPHandler...");
    // Connect to RabbitMQ with retries.
    if (!ConnectWithRetry(config_.max_retries, config_.retry_delay_secs)) {
        LOG_ERROR("Failed to connect to RabbitMQ after retries");
        return false;
    }
    LOG_INFO("╔════════════════════════════════════════════════════════════════╗");
    LOG_INFO("║    [AMQP] ✓ Connected to RabbitMQ Broker: " + config_.host + ":" + std::to_string(config_.port));
    LOG_INFO("╚════════════════════════════════════════════════════════════════╝");
  
    // Set message callback and subscribe to the configured queue.
    SetMessageCallback(std::bind(&AMQPHandler::ReceivedMessage, this, std::placeholders::_1));
    if (!Subscribe(config_.queue_name, message_callback_)) {
        LOG_ERROR("Failed to subscribe to queue: " + config_.queue_name);
        BrokerBase::Disconnect();
        return false;
    }

    // Start threads only if they are not already running.
    std::lock_guard<std::mutex> lk(start_stop_mutex_);
    if (running_.load()) {
        LOG_INFO("Threads already running, skipping Start()");
        return true;
    }
    running_.store(true);
    watching_.store(true);
    last_message_time_ = std::chrono::steady_clock::now();
    consumer_thread_ = std::thread([this]() { ConsumeLoop(); });
    watch_thread_ = std::thread([this]() { WatchdogLoop(); });
    reconnect_thread_ = std::thread([this]() { ReconnectHandlerLoop(); });
    return true;
}

/**
 * @brief De-initializes the handler by calling `Disconnect()`.
 */
void AMQPHandler::Deinit() { Disconnect(); }

/** @brief Sets the callback function for processing messages.
 * @param cb The callback function to handle received messages.
 */
void AMQPHandler::SetMessageCallback(const MessageCallback& cb) {
    message_callback_ = cb;
}
/** @brief Decompresses GZIP-encoded message data.
 *  @param data Input data to decompress.
 *  @param length Length of input data.
 *  @return Decompressed string.
 *  @throws std::runtime_error If decompression fails.
 */

std::string AMQPHandler::DecompressGzip(const uint8_t* data, size_t length) {
    LOG_INFO("╔════════════════════════════════════════════════════════════════╗");
    LOG_INFO("║ [AMQPHandler] Attempting to decompress GZIP message...         ║");
    LOG_INFO("║ [AMQPHandler] Compressed size: " + std::to_string(length) + " bytes" + std::string(50 - std::to_string(length).size(), ' ') + "║");
    LOG_INFO("╚════════════════════════════════════════════════════════════════╝");
    return CompressionUtils::DecompressGzip(data, length);
}
/** @brief Handles a received message from the `ConsumeLoop`.
 *
 * This is the first function called after a message is successfully consumed.
 * It updates the last message time and logs the reception of the message before
 * passing it on for further processing.
 *
 * @param subscribe_message The raw message body as a string.
 */
void AMQPHandler::ReceivedMessage(const std::string& subscribe_message) {
    last_message_time_ = std::chrono::steady_clock::now();

    try {
        // Parse JSON safely
        nlohmann::json msg_json = nlohmann::json::parse(subscribe_message);

        LOG_INFO("╔════════════════════════════════════════════════════════════════╗");
        LOG_INFO("║           PDCC MESSAGE RECEIVED FROM PUBRabbitMQ BROKER        ║");
        LOG_INFO("╚════════════════════════════════════════════════════════════════╝");
        
        // Count commands
        if (msg_json.contains("physicalDeviceCommands")) {
            int cmd_count = msg_json["physicalDeviceCommands"].size();
            LOG_INFO("[AMQP] 📨 Received " + std::to_string(cmd_count) + " command(s)");
        }
        
        // Pretty print the full JSON message
        LOG_INFO("[AMQP] Parsed JSON:");
        LOG_INFO(msg_json.dump(2)); // print with 2-space indentation
        
        LOG_INFO("Received PDCC message");

        LOG_INFO("-------------------------------------------------------");
    }
    catch (const nlohmann::json::parse_error& e) {
        // If it's not valid JSON, fall back to raw output
        LOG_ERROR("Received message (invalid JSON): " + subscribe_message);
        LOG_ERROR(std::string("JSON parse error: ") + e.what());
    }

    ProcessMessage(subscribe_message);
}



/** @brief Processes and validates the content of a received JSON message from the broker.
 *
 * This function parses the incoming JSON message, validates its structure and commands,
 * and handles different message types (keep-alive, error, or command). If all commands are valid,
 * it sends an acknowledgment and processes the commands. If any command is invalid, it sends a single
 * error (nack) for the entire payload. For valid commands, it also submits download jobs to the DownloadManager.
 *
 * Key behaviors:
 * - Skips keep-alive messages (empty command list).
 * - Handles incoming error (aag-nack) messages.
 * - Validates all commands before processing; sends a single nack if any are invalid.
 * - Sends a single ack if all commands are valid.
 * - Submits download jobs for each valid command.
 *
 * @param process_message The JSON message string to be processed.
 */
void AMQPHandler::ProcessMessage(const std::string& process_message) {
    LOG_INFO("[AMQP] ProcessMessage called with message length: " + std::to_string(process_message.length()));
    try {
        auto j = nlohmann::json::parse(process_message);

        // Skip keep-alive messages (which have empty command lists).
        if (j.contains("physicalDeviceCommands") && j["physicalDeviceCommands"].empty()) {
            LOG_INFO("Skipping empty command list (keep-alive)");
            return;
        }

        // DEDUPLICATION: Check for duplicate messages
        std::string message_id = GenerateMessageId(j);
        LOG_INFO("[AMQP] Generated message ID: " + message_id);

        if (IsDuplicateMessage(message_id)) {
            LOG_WARNING("[AMQP] 🚫 DUPLICATE MESSAGE DROPPED - ID: " + message_id);
            LOG_WARNING("[AMQP] Sending duplicate detection acknowledgment");

            // Send PPM info message for duplicate detection (not an error, just acknowledgment)
            nlohmann::json duplicate_ack;
            duplicate_ack["type"] = "info";
            duplicate_ack["event"] = "pdc-received";
            duplicate_ack["message_id"] = message_id;
            duplicate_ack["status"] = "duplicate_detected";
            duplicate_ack["detail"] = "Message already processed, duplicate dropped";

            SendPpmInfoMessage(duplicate_ack.dump());
            return;
        }

        // Handle incoming error messages (aag-nack) from the broker.
        if (j.contains("type") && j["type"] == kMsgTypeError &&
            j.contains("event") && j["event"] == kEventAagNack) {
            SendPpmErrorMessage(j);
            return;
        }

        // COMPREHENSIVE VALIDATION: Use MessageValidator for all validation
        LOG_INFO("[AMQP] Starting message validation...");
        auto validation_result = MessageValidator::ValidateMessage(j);
        
        //Proper boolean to string conversion
        std::string validation_status = validation_result.is_valid ? "true" : "false";
        LOG_INFO("[AMQP] Validation completed. Valid: " + validation_status);     
        if (!validation_result.is_valid) {
            LOG_ERROR("[AMQP] Error code: " + validation_result.error_code);

            // Send PPM error message with validation details and metadata
            nlohmann::json error_msg;
            error_msg["type"] = kMsgTypeError;
            error_msg["event"] = kEventAagNack;
            error_msg["error_code"] = validation_result.error_code;
            error_msg["detail"] = validation_result.error_code + ":" + validation_result.error_message;
            
            // Extract metadata from original message if available
            try {
                if (j.contains("physicalDeviceCommands") && j["physicalDeviceCommands"].is_array() && 
                    !j["physicalDeviceCommands"].empty()) {
                    const auto& cmd = j["physicalDeviceCommands"][0];
                    if (cmd.contains("pdevCommand") && cmd["pdevCommand"].contains("cmd-meta")) {
                        const auto& cmd_meta = cmd["pdevCommand"]["cmd-meta"];
                        
                        // Filter known attributes only
                        static const std::unordered_set<std::string> allowed_fields = {
                            "deviceCommandId", "priority", "command", "channelAddress",
                            "validUntil", "requestedOutputTime", "requestedOuputTime",
                            "sequenceNo", "announcementId", "announcementHash", "announcementProfile"
                        };
                        nlohmann::json filtered_meta;
                        for (auto it = cmd_meta.begin(); it != cmd_meta.end(); ++it) {
                            if (allowed_fields.count(it.key())) {
                                filtered_meta[it.key()] = it.value();
                            }
                        }
                        error_msg["metaData"] = filtered_meta;
                    }
                }
            } catch (const std::exception& ex) {
                LOG_WARNING("[AMQP] Could not extract metadata for error message: " + std::string(ex.what()));
            }
            
            SendPpmErrorMessage(error_msg);
            return;
        }

        // ✅ All validation passed - no need for duplicate validation
        LOG_INFO("[AMQP] 📤 Sending PPM Info (pdc-received) message");
        SendPpmInfoMessage(process_message);

        LOG_INFO("[AMQP] Message validation passed, proceeding with processing...");
        ProcessAmqpCommands(process_message);

        MarkMessageAsProcessed(message_id);

    } catch (const std::exception& ex) {
        LOG_ERROR("[AMQPHandler] JSON parse error: " + std::string(ex.what()));
        LOG_ERROR("[AMQPHandler] 🗑️ Processing garbage message for workflow completion");

        nlohmann::json error_msg;
        error_msg["type"] = kMsgTypeError;
        error_msg["event"] = kEventAagNack;
        error_msg["detail"] = "E_COMMAND_FAULTY:invalid-json - " + std::string(ex.what());
        error_msg["raw_message_length"] = process_message.length();
        SendPpmErrorMessage(error_msg);

        if (aas_app_) {
            LOG_INFO("[AMQPHandler] 🗑️ Directly emitting PPM completion for garbage message");
            // Create a minimal fake job for the PPM message
            AnnouncementJob fake_job;
            fake_job.device_command_id = "garbage-test-" + std::to_string(std::chrono::duration_cast<std::chrono::milliseconds>(
                std::chrono::system_clock::now().time_since_epoch()).count());
            fake_job.priority = 1;
            fake_job.command = CommandKind::kAnnOut;
            fake_job.channel_address = "test-channel";
            fake_job.valid_until = std::chrono::system_clock::now() + std::chrono::hours(1);
            fake_job.requested_output_time = std::chrono::system_clock::now() + std::chrono::minutes(1);
            fake_job.sequence_no = 999;
            fake_job.announcement_id = "garbage-test";
            fake_job.announcement_hash = "garbage-hash";
            fake_job.profile_text = "Test garbage message";
            fake_job.profile_language = "en";
            
            // Get PPMReporter instance and emit success message directly
            auto ppm_reporter = PPMReporter::GetInstance();
            if (ppm_reporter) {
                auto& configManager = ConfigManager::GetInstance();
                const auto& deviceId = configManager.GetDeviceIdentity();

                nlohmann::json ppm_msg;
                ppm_msg["timestamp"] = std::chrono::duration_cast<std::chrono::milliseconds>(
                    std::chrono::system_clock::now().time_since_epoch()).count();
                ppm_msg["product"] = deviceId.product;
                ppm_msg["service"] = deviceId.service;
                ppm_msg["instance"] = deviceId.instance;
                ppm_msg["type"] = "error";
                ppm_msg["event"] = "aag-nack";

                // Build metaData block
                nlohmann::json metaData;
                metaData["deviceCommandId"] = fake_job.device_command_id;
                metaData["priority"] = fake_job.priority;
                metaData["command"] = "annout";
                metaData["channelAddress"] = fake_job.channel_address;
                
                // Simple ISO8601 formatting inline
                auto toIso8601 = [](const std::chrono::system_clock::time_point& tp) -> std::string {
                    std::time_t t = std::chrono::system_clock::to_time_t(tp);
                    std::tm tm = *std::gmtime(&t);
                    char buf[32];
                    std::strftime(buf, sizeof(buf), "%Y-%m-%dT%H:%M:%S.000Z", &tm);
                    return std::string(buf);
                };
                
                metaData["validUntil"] = toIso8601(fake_job.valid_until);
                metaData["requestedOuputTime"] = toIso8601(fake_job.requested_output_time);
                metaData["sequenceNo"] = fake_job.sequence_no;
                metaData["announcementId"] = fake_job.announcement_id;
                metaData["announcementHash"] = fake_job.announcement_hash;
                metaData["announcementProfile"] = {
                    {"text", fake_job.profile_text},
                    {"language", fake_job.profile_language}
                };
                ppm_msg["metaData"] = metaData;

                // Publish the PPM message directly
                ppm_reporter->PublishPPM("error", "aag-nack", ppm_msg.dump(4));
                
                // Print "Job done" to stdout for external test system
                std::cout << "Job done" << std::endl;
                std::cout.flush();
                
            }
        }
    }
    LOG_INFO("-------------------------------------------------------");
}

/**
 * @brief Processes validated AMQP commands and sends PPM info acknowledgments.
 *
 * This function parses the JSON message, iterates over all device commands, and for each:
 * - Validates required fields and expiry.
 * - Handles ANNOUT (announcement) and ANNDEL (delete) commands.
 * - Schedules jobs or cancels them via the PDCCPriorityQueueManager.
 * - Sends PPM success or error messages as appropriate.
 * - Publishes a PPM info (pdc-received) message for each processed command.
 *
 * @param subscribe_message The original JSON message string containing commands.
 */
void AMQPHandler::ProcessAmqpCommands(const std::string& subscribe_message) {
    try {
        auto j = nlohmann::json::parse(subscribe_message);

        if (!j.contains("physicalDeviceCommands")) {
            LOG_INFO("[AMQPHandler] No physicalDeviceCommands to acknowledge.\n");
            return;
        }

        auto ppm_reporter = PPMReporter::GetInstance();

        bool anyAccepted = false;   // at least 1 command we decided to process
        bool allRejected = true;    // all commands were malformed/expired/duplicate

        for (const auto& cmd : j["physicalDeviceCommands"]) {
            // Validate command structure
            if (!cmd.contains("pdevCommand") || !cmd["pdevCommand"].contains("cmd-meta")) {
                LOG_INFO("[AMQPHandler] Skipping invalid command in ack.\n");
                continue;
            }
            
            // Safe access to cmd-meta
            if (!cmd["pdevCommand"]["cmd-meta"].is_object()) {
                LOG_INFO("[AMQPHandler] Skipping command with invalid cmd-meta structure.\n");
                continue;
            }
            const auto& cmd_meta = cmd["pdevCommand"]["cmd-meta"];

            // Extract timestamp values for expiry checking
            const std::string valid_until = cmd_meta.value("validUntil", "");
            
            // ✅ Handle both correct and typo key for requestedOutputTime
            std::string requested_time;
            if (cmd_meta.contains("requestedOutputTime"))
                requested_time = cmd_meta["requestedOutputTime"].get<std::string>();
            else if (cmd_meta.contains("requestedOuputTime")) // typo from Python client
                requested_time = cmd_meta["requestedOuputTime"].get<std::string>();
            else
                requested_time = "";

            // Check expiry window - check validUntil first (usually the more restrictive)
            if (!valid_until.empty() && IsExpired(valid_until)) {
                LOG_ERROR("[AMQPHandler] Command expired: validUntil is in the past for deviceCommandId: " + cmd_meta.value("deviceCommandId", ""));
                SendPpmErrorMessage(cmd_meta, "E_COMMAND_FAULTY:expired-validUntil");
                continue;
            }
            
            // Check requestedOutputTime expiry
            if (!requested_time.empty() && IsExpired(requested_time)) {
                LOG_ERROR("[AMQPHandler] Command expired: requestedOutputTime is in the past for deviceCommandId: " + cmd_meta.value("deviceCommandId", ""));
                SendPpmErrorMessage(cmd_meta, "E_COMMAND_FAULTY:expired-requestedOutputTime");
                continue;
            }

            const auto& pdc = cmd["pdevCommand"];
            if (!pdc.contains("cmd-meta") || !pdc["cmd-meta"].is_object()) {
                SendPpmErrorMessage(cmd);
                continue;
            }
            const auto& meta = pdc["cmd-meta"];

            // Required minimal fields
            const std::string command = meta.value("command", "");
            const std::string device_cmd_id = meta.value("deviceCommandId", "");
            const int64_t sequence_no = meta.value("sequenceNo", 0);

            // Dispatch by command type
            if (command == "ANNOUT") {
                // Ensure content is present and valid
                if (!pdc.contains("cmd-content") || !pdc["cmd-content"].is_object()) {
                    SendPpmErrorMessage(meta, "E_COMMAND_FAULTY:no-content");
                    continue;
                }
                const auto& content = pdc["cmd-content"];
                
                // Extract content URLs (supports both single string and array)
                std::vector<std::string> content_uris;
                if (content.contains("content")) {
                    const auto& content_field = content["content"];
                    if (content_field.is_array()) {
                        // Multiple files: ["url1", "url2", "url3"]
                        for (const auto& uri_elem : content_field) {
                            if (uri_elem.is_string()) {
                                std::string uri_str = uri_elem.get<std::string>();
                                if (!uri_str.empty()) {
                                    content_uris.push_back(uri_str);
                                }
                            }
                        }
                    } else if (content_field.is_string()) {
                        // Single file: "url1" (backward compatibility)
                        std::string uri_str = content_field.get<std::string>();
                        if (!uri_str.empty()) {
                            content_uris.push_back(uri_str);
                        }
                    }
                }
                
                // Validate that we have at least one content URL
                if (content_uris.empty()) {
                    SendPpmErrorMessage(meta, "E_COMMAND_FAULTY:no-content-urls: No valid content URLs found");
                    continue;
                }
                
                // Maintain backward compatibility - use first URL as primary
                const std::string uri = content_uris[0];

                // -------- Priority validation --------
                int priority;
                if (!meta.contains("priority")) {
                    // Use configured default priority when missing
                    priority = ConfigManager::GetInstance().GetScheduler().default_priority;
                    LOG_INFO("[AMQP] Priority missing, using default: " + std::to_string(priority));
                } else if (!meta["priority"].is_number_integer()) {
                    SendPpmErrorMessage(meta, "E_COMMAND_FAULTY:bad-priority: Priority must be an integer");
                    continue;
                } else {
                    priority = meta["priority"].get<int>();
                }
                
                if (priority < 1 || priority > 9) {
                    SendPpmErrorMessage(meta, "E_COMMAND_FAULTY:bad-priority: Priority out of range (1-9)");
                    continue;
                }

                // -------- Build the scheduling job (AnnouncementJob) --------
                if (aas_app_) {
                    PdccAnnOut pdcc_ann_out;
                    pdcc_ann_out.device_command_id = device_cmd_id;
                    pdcc_ann_out.sequence_no = sequence_no;
                    pdcc_ann_out.channel_address = cmd_meta.value("channelAddress", "");
                    pdcc_ann_out.priority = priority; // <-- use validated priority
                    pdcc_ann_out.announcement_id = cmd_meta.value("announcementId", "");
                    pdcc_ann_out.announcement_hash = meta.value("announcementHash", "");
                    
                    // Set multiple content URLs
                    pdcc_ann_out.content_urls = content_uris;
                    // Maintain backward compatibility
                    pdcc_ann_out.content_url = uri;

                    // ✅ Use the requested_time already extracted above for expiry checking
                    // (No need to re-extract requestedOutputTime since we got it earlier)

                    // Parse and set requestedOutputTime and validUntil
                    pdcc_ann_out.requested_output_time = ParseIso8601(requested_time);
                    pdcc_ann_out.valid_until = ParseIso8601(valid_until);

                    // Extract announcementProfile fields
                    if (meta.contains("announcementProfile") && meta["announcementProfile"].is_object()) {
                        const auto& profile = meta["announcementProfile"];
                        pdcc_ann_out.profile_text = profile.value("text", "");
                        pdcc_ann_out.profile_language = profile.value("language", "");
                    } else {
                        pdcc_ann_out.profile_text = "";
                        pdcc_ann_out.profile_language = "";
                    }

                    // Check for invalid requestedOutputTime
                    if (pdcc_ann_out.requested_output_time == std::chrono::system_clock::time_point::min()) {
                        SendPpmErrorMessage(meta, "E_COMMAND_FAULTY:bad-timestamp-format: Invalid requestedOutputTime");
                        continue; // Do not queue the job
                    }

                    // All validation passed, submit download job(s)
                    if (downloadManager_) {
                        PDCCJob job;
                        job.announcementId = pdcc_ann_out.announcement_id;
                        
                        // Set multiple URIs and hashes
                        job.audioUris = content_uris;
                        // Generate hashes for each URI (simple approach: use same base hash + index)
                        for (size_t i = 0; i < content_uris.size(); ++i) {
                            std::string file_hash = pdcc_ann_out.announcement_hash;
                            if (content_uris.size() > 1) {
                                file_hash += "_" + std::to_string(i);  // Append index for multi-file
                            }
                            job.announcementHashes.push_back(file_hash);
                        }
                        
                        // Maintain backward compatibility
                        job.audioUri = pdcc_ann_out.content_url;
                        job.announcementHash = pdcc_ann_out.announcement_hash;
                        
                        downloadManager_->SubmitTask(job);
                    }
                    // Call AASApp to handle the announcement
                    aas_app_->HandleAnnOut(pdcc_ann_out);
                
                } else {
                LOG_ERROR("[ERROR] AMQPHandler: AASApp not set, cannot process ANNOUT command");
                LOG_ERROR("AASApp not set, cannot process ANNOUT command");
                }
                anyAccepted = true;
                allRejected = false;

            } else if (command == "ANNDEL") {
                // Cancel/remove job by announcementId
                const std::string ann_id = cmd_meta.value("announcementId", "");
                if (!cmd_meta["announcementId"].is_string()) {
                    SendPpmErrorMessage(meta, "E_COMMAND_FAULTY:bad-announcementId-type");
                    continue;
                }
                // Check for extra fields
                static const std::unordered_set<std::string> allowed_fields = {
                    "command", "deviceCommandId", "announcementId", "channelAddress", "sequenceNo"
                };
                for (auto it = cmd_meta.begin(); it != cmd_meta.end(); ++it) {
                    if (allowed_fields.find(it.key()) == allowed_fields.end()) {
                        SendPpmErrorMessage(meta, "E_COMMAND_FAULTY:bad-field:" + it.key());
                        continue;
                    }
                }
                const std::string channel_addr = cmd_meta.value("channelAddress", "");
                
                if (aas_app_) {
                    // Build PdccAnnDel struct for AASApp
                    PdccAnnDel pdcc_ann_del;
                    pdcc_ann_del.device_command_id = device_cmd_id;
                    pdcc_ann_del.announcement_id = ann_id;
                    pdcc_ann_del.channel_address = channel_addr;
                    
                    // Call AASApp to handle the deletion
                    aas_app_->HandleAnnDel(pdcc_ann_del);
                } else {
                    LOG_ERROR("[ERROR] AMQPHandler: AASApp not set, cannot process ANNDEL command");
                    LOG_ERROR("AASApp not set, cannot process ANNDEL command");
                }
                
                // signal scheduler about cancellation
                anyAccepted = true;
                allRejected = false;
            } else {
                // Unsupported command type
                SendPpmErrorMessage(meta, "E_COMMAND_FAULTY:unsupported-command");
            }

        }
        if (allRejected && !anyAccepted) {
            LOG_ERROR("All commands in message were rejected - garbage message");
            
        } else if (anyAccepted) {
        }
    } catch (const std::exception& ex) {
        LOG_ERROR("Failed to send PPM info: " + std::string(ex.what()));
    }
}

std::chrono::system_clock::time_point AMQPHandler::ParseIso8601(const std::string& iso) {
    std::tm tm{}; int year, mon, day, hh, mm, ss;
    char tz = 'Z';
    if (std::sscanf(iso.c_str(), "%d-%d-%dT%d:%d:%d%c", &year, &mon, &day, &hh, &mm, &ss, &tz) >= 6) {
        tm.tm_year = year - 1900; tm.tm_mon = mon - 1; tm.tm_mday = day;
        tm.tm_hour = hh; tm.tm_min = mm; tm.tm_sec = ss;
        auto t = timegm(&tm); // timegm for UTC
        return std::chrono::system_clock::from_time_t(t);
    }
    return std::chrono::system_clock::time_point::min();
}

bool AMQPHandler::IsExpired(const std::string& iso) {
    auto tp = ParseIso8601(iso);
    if (tp == std::chrono::system_clock::time_point::min()) return false; // unknown -> let it pass
    
    // Add 2-second grace period for processing delays
    auto grace_time = tp + std::chrono::seconds(2);
    
    return std::chrono::system_clock::now() > grace_time;
}

/** @brief Sends a PPM error message (NACK) back to the broker.
 *
 * This function is called when an invalid or malformed message is received.
 * It constructs and publishes a `nack` message to inform the broker of the
 * processing failure, preventing the same invalid message from being re-delivered.
 *
 * @param msg_json The JSON object containing the error details or metadata from the original message.
 */
void AMQPHandler::SendPpmErrorMessage(const nlohmann::json& msg_json) {
    try {
        nlohmann::json ppm_error_msg;
        ppm_error_msg["timestamp"] = std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();
        ppm_error_msg["type"] = kMsgTypeError;
        ppm_error_msg["event"] = kEventAagNack;

        // Include metadata or error details if present in the original message.
        if (msg_json.contains("metaData")) {
            const auto& cmd_meta = msg_json["metaData"];
            ppm_error_msg["metaData"] = cmd_meta;
        }
        if (msg_json.contains("detail")) {
            ppm_error_msg["detail"] = msg_json["detail"];
        }
        // Get device identity from ConfigManager
        const auto& deviceId = ConfigManager::GetInstance().GetDeviceIdentity();
        ppm_error_msg["product"] = deviceId.product;
        ppm_error_msg["service"] = deviceId.service;
        ppm_error_msg["instance"] = deviceId.instance;

        // Publish the error message using the singleton PPMReporter.
        auto ppm_reporter = PPMReporter::GetInstance();
        
	    ppm_reporter->PublishPPM("error", "aag-nack", ppm_error_msg.dump(4));

        LOG_INFO("[AMQPHandler] Published PPM error aag-nack message\n");
    } catch (const std::exception& ex) {
        LOG_ERROR("Failed to publish PPM error message: " + std::string(ex.what()));
    }
}

/** @brief Sets the `DownloadManager` for submitting audio download jobs.
 *
 * This is a setter method that establishes the link between the `AMQPHandler`
 * and the `DownloadManager`, allowing the handler to delegate download tasks.
 *
 * @param dm A pointer to the `DownloadManager` instance.
 */
void AMQPHandler::SetDownloadManager(DownloadManager* dm) {
    downloadManager_ = dm;
}


/**
 * @brief The main message consumption loop.
 *
 * This function runs in a dedicated thread and is the heart of the AMQP consumer.
 * It continuously polls for new messages from the broker, processes them, and
 * handles all exceptions and connection failures. The loop continues until the
 * atomic `running_` flag is set to `false`.
 *
 * The loop's core logic is as follows:
 * 1. It waits for a message using `amqp_consume_message`.
 * 2. If a message is received (`AMQP_RESPONSE_NORMAL`), it updates a timestamp,
 * checks for Gzip compression, and decompresses the message body if needed.
 * 3. It then safely calls the `message_callback_` to process the message content.
 * 4. The message is then reliably acknowledged with `amqp_basic_ack`, and its
 * envelope is destroyed to prevent memory leaks.
 * 5. If the broker returns a timeout (`AMQP_STATUS_TIMEOUT`), the loop simply
 * continues, as this is expected behavior.
 * 6. For any other unrecoverable error, it initiates a **reconnection sequence**
 * by calling `Disconnect()` and then a nested `while` loop with `Init()`.
 * This ensures the consumer can recover from network instability or broker issues.
 *
 * @note This function is designed to be self-healing and will attempt to
 * reconnect indefinitely until the application is shut down.
 */


void AMQPHandler::ConsumeLoop() {
    while (running_.load()) {
        amqp_envelope_t envelope;
        bool have_envelope = false;

        try {
            // Release AMQP buffers to prevent excessive memory usage.
            amqp_maybe_release_buffers(conn_);

            // Consume a single message. The timeout is NULL, so it will wait indefinitely.
            amqp_rpc_reply_t reply = amqp_consume_message(conn_, &envelope, NULL, 0);

            if (reply.reply_type == AMQP_RESPONSE_NORMAL) {
                have_envelope = true;
                last_message_time_ = std::chrono::steady_clock::now();

                // Check for GZIP encoding using the message properties.
                bool is_gzip = false;
                amqp_basic_properties_t* props = &envelope.message.properties;
                if (props && (props->_flags & AMQP_BASIC_CONTENT_ENCODING_FLAG) &&
                    props->content_encoding.bytes && props->content_encoding.len > 0) {
                    std::string encoding(reinterpret_cast<char*>(props->content_encoding.bytes),
                                         props->content_encoding.len);
                    // Case-insensitive comparison for gzip
                    std::transform(encoding.begin(), encoding.end(), encoding.begin(), ::tolower);
                    if (encoding == kGzipEncoding) {
                        is_gzip = true;
                        // Only log when GZIP is actually detected
                        LOG_INFO("╔════════════════════════════════════════════════════════════════╗");
                        LOG_INFO("║ [AMQPHandler] Detected GZIP encoding in incoming message       ║");
                        LOG_INFO(std::string("    content_encoding: ") +
                                std::string(reinterpret_cast<char*>(props->content_encoding.bytes), props->content_encoding.len));
                        LOG_INFO("╚════════════════════════════════════════════════════════════════╝");
                    }
                }

                // Decompress the message body if necessary.
                std::string body;
                bool decompression_failed = false;
                if (is_gzip) {
                    try {
                        body = DecompressGzip(
                            reinterpret_cast<const uint8_t*>(envelope.message.body.bytes),
                            envelope.message.body.len);
                    } catch (const std::exception& ex) {
                        // ✅ LOG the error but DON'T return - process as 
                        LOG_ERROR("[AMQPHandler] Gzip decompression failed: " + std::string(ex.what()));
                        LOG_ERROR("[AMQPHandler] 🗑️ Processing as garbage message for workflow completion");
                        decompression_failed = true;
                        // ✅ Use raw bytes as fallback for garbage processing
                        body.assign(reinterpret_cast<const char*>(envelope.message.body.bytes),
                                    envelope.message.body.len);
                    }
                } else {
                    // If not compressed, copy the raw message body.
                    body.assign(reinterpret_cast<const char*>(envelope.message.body.bytes),
                                envelope.message.body.len);
                }

                // ✅ ALWAYS process the message, even if decompression failed
                try {
                    if (message_callback_) {
                        if (decompression_failed) {
                            LOG_INFO("[AMQPHandler] 🗑️ Processing garbage message to ensure workflow completion");
                        }
                        message_callback_(body);
                    }
                } catch (const std::exception& cbex) {
                    LOG_ERROR("Exception in message callback: " + std::string(cbex.what()));
                } catch (...) {
                    LOG_ERROR("[AMQPHandler] Unknown exception in message callback");
                }

                // Acknowledge the message and destroy its envelope.
                try {
                    const auto& amqpConfig = ConfigManager::GetInstance().GetAmqp();
                    amqp_basic_ack(conn_, amqpConfig.channel_id, envelope.delivery_tag, 0);
                } catch (const std::exception& ackex) {
                    LOG_ERROR("[AMQPHandler] Exception while acking message: " + std::string(ackex.what()));
                }
                amqp_destroy_envelope(&envelope);

            } else if (reply.reply_type == AMQP_RESPONSE_LIBRARY_EXCEPTION &&
                       reply.library_error == AMQP_STATUS_TIMEOUT) {
                // This is a normal timeout and not an error. Continue waiting.
                continue;

            } else {
                // A fatal error has occurred (e.g., connection lost).
                LOG_ERROR("[AMQPHandler] Consume failed or connection lost. Attempting reconnect...");
                std::this_thread::sleep_for(std::chrono::seconds(1));

                Disconnect();

                while (running_.load() && !Init()) {
                    LOG_ERROR("[AMQPHandler] Re-init failed, retrying in 5 seconds...");
                    std::this_thread::sleep_for(std::chrono::seconds(5));
                }

                if (!running_.load()) {
                    LOG_ERROR("Shutting down ConsumeLoop during reconnect");
                    break;
                }

                continue; // Restart the ConsumeLoop with the new connection.
            }

        } catch (const std::system_error& se) {
            LOG_ERROR("[AMQPHandler] system_error in ConsumeLoop: " + std::string(se.what()));
            running_.store(false);
            break;

        } catch (const std::exception& ex) {
            LOG_ERROR("Exception in ConsumeLoop: " + std::string(ex.what()));
            running_.store(false);
            break;

        } catch (...) {
            running_.store(false);
            break;
        }
    }

    LOG_INFO("ConsumeLoop exiting");
}

/**
 * @brief Monitors connection health and triggers reconnects if stalled.
 *
 * @details Runs in `watch_thread_` and checks every configurable watchdog interval
 * whether the time since the last message exceeds configurable reconnect timeout.
 * If stalled, signals `ReconnectHandlerLoop` to reconnect, addressing connection issues.
 * Waits 5 seconds after signaling to avoid rapid retries. Exits when
 * `watching_` is false. Uses `LOG_INFO`/`LOG_ERROR` for thread-safe logging.
 */
void AMQPHandler::WatchdogLoop() {
    const int watchdogInterval = ConfigManager::GetInstance().GetAmqp().watchdog_interval_seconds;
    const int reconnectTimeout = ConfigManager::GetInstance().GetAmqp().reconnect_timeout_seconds;
    
    while (watching_) {
        std::this_thread::sleep_for(std::chrono::seconds(watchdogInterval));
        auto now = std::chrono::steady_clock::now();
        auto last = last_message_time_.load();
        auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(now - last).count();

        if (elapsed > reconnectTimeout) {
            LOG_ERROR("No message received for " + std::to_string(elapsed) + " seconds, requesting reconnect...");

            // Signal that a reconnect is needed.
            reconnect_requested_.store(true);
            reconnect_cv_.notify_one();

            // Wait briefly to prevent rapid, unnecessary retry attempts.
            std::this_thread::sleep_for(std::chrono::seconds(5));
        }
    }
    LOG_INFO("WatchdogLoop exiting");
}



/**
 * @brief Publishes a PPM info (pdc-received) message for valid PDCC messages.
 *
 * @details This method sends a PPM "pdc-received" acknowledgment message when a valid
 * PDCC message is received. It extracts the command metadata and creates a properly
 * formatted PPM message with all required fields including deviceCommandId, priority,
 * command, channelAddress, validUntil, requestedOutputTime, sequenceNo, announcementId,
 * announcementHash, and announcementProfile.
 *
 * @param subscribe_message The original JSON message string that is being acknowledged.
 */
void AMQPHandler::SendPpmInfoMessage(const std::string& subscribe_message) {
    try {
        auto j = nlohmann::json::parse(subscribe_message);

        if (!j.contains("physicalDeviceCommands")) {
            LOG_ERROR("No physicalDeviceCommands to acknowledge.");
            return;
        }

        auto ppm_reporter = PPMReporter::GetInstance();

        for (const auto& cmd : j["physicalDeviceCommands"]) {
            if (!cmd.contains("pdevCommand") || !cmd["pdevCommand"].contains("cmd-meta")) {
                LOG_ERROR("Skipping invalid command in ack.");
                continue;
            }
            
            // Safe access to cmd-meta
            if (!cmd["pdevCommand"]["cmd-meta"].is_object()) {
                LOG_ERROR("Skipping command with invalid cmd-meta structure in ack.");
                continue;
            }
            const auto& cmd_meta = cmd["pdevCommand"]["cmd-meta"];
            
            // Filter known attributes only
            static const std::unordered_set<std::string> allowed_fields = {
                "deviceCommandId", "priority", "command", "channelAddress",
                "validUntil", "requestedOutputTime", "requestedOuputTime",
                "sequenceNo", "announcementId", "announcementHash", "announcementProfile"
            };
            nlohmann::json filtered_meta;
            for (auto it = cmd_meta.begin(); it != cmd_meta.end(); ++it) {
                if (allowed_fields.count(it.key())) {
                    filtered_meta[it.key()] = it.value();
                }
            }

            // Create PPM info message
            const auto& deviceId = ConfigManager::GetInstance().GetDeviceIdentity();
            nlohmann::json ppm_info;
            ppm_info["timestamp"] = std::chrono::duration_cast<std::chrono::milliseconds>(
                std::chrono::system_clock::now().time_since_epoch()).count();
            ppm_info["type"] = "info";
            ppm_info["event"] = "pdc-received";
            ppm_info["product"] = deviceId.product;
            ppm_info["service"] = deviceId.service;
            ppm_info["instance"] = deviceId.instance;
            
            // Use filtered metadata
            ppm_info["metaData"] = filtered_meta;

            // Publish the PPM info message
            ppm_reporter->PublishPPM("info", "pdc-received", ppm_info.dump());
            LOG_INFO("[AMQP] ✓ Published PPM info (pdc-received) for AnnouncementID: " + filtered_meta.value("announcementId", "unknown"));
            LOG_INFO("-------------------------------------------------------");
        }
    } catch (const std::exception& ex) {
        LOG_ERROR("Failed to publish PPM info message: " + std::string(ex.what()));
    }
}

/**
 * @brief Publishes a PPM success (aag-ack) message after successful processing.
 *
 * @details This method sends a PPM "aag-ack" success message when a PDCC command
 * has been successfully processed. It includes all the original command metadata
 * and indicates successful completion.
 *
 * @param cmd_meta The command metadata from the original PDCC message.
 */
void AMQPHandler::SendPpmSuccessMessage(const nlohmann::json& cmd) {
    try {
        auto ppm_reporter = PPMReporter::GetInstance();
        const auto& deviceId = ConfigManager::GetInstance().GetDeviceIdentity();

        nlohmann::json ppm_success;
        ppm_success["timestamp"] = std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();
        ppm_success["type"] = "success";
        ppm_success["event"] = "aag-ack";
        ppm_success["product"] = deviceId.product;
        ppm_success["service"] = deviceId.service;
        ppm_success["instance"] = deviceId.instance;

        // Filter known attributes only
        static const std::unordered_set<std::string> allowed_fields = {
            "deviceCommandId", "priority", "command", "channelAddress",
            "validUntil", "requestedOutputTime", "requestedOuputTime",
            "sequenceNo", "announcementId", "announcementHash", "announcementProfile"
        };
        nlohmann::json filtered_meta;
        if (cmd.contains("pdevCommand") && cmd["pdevCommand"].contains("cmd-meta")) {
            const auto& cmd_meta = cmd["pdevCommand"]["cmd-meta"];
            for (auto it = cmd_meta.begin(); it != cmd_meta.end(); ++it) {
                if (allowed_fields.count(it.key())) {
                    filtered_meta[it.key()] = it.value();
                }
            }
        } else if (cmd.contains("cmd-meta")) {
            const auto& cmd_meta = cmd["cmd-meta"];
            for (auto it = cmd_meta.begin(); it != cmd_meta.end(); ++it) {
                if (allowed_fields.count(it.key())) {
                    filtered_meta[it.key()] = it.value();
                }
            }
        } else {
            for (auto it = cmd.begin(); it != cmd.end(); ++it) {
                if (allowed_fields.count(it.key())) {
                    filtered_meta[it.key()] = it.value();
                }
            }
        }
        ppm_success["metaData"] = filtered_meta;

        ppm_reporter->PublishPPM("success", "aag-ack", ppm_success.dump());
        LOG_INFO("[AMQP] ✓ Published PPM success (aag-ack) for AnnouncementID: " +
                 filtered_meta.value("announcementId", "unknown"));
    } catch (const std::exception& ex) {
        LOG_ERROR("Failed to publish PPM success message: " + std::string(ex.what()));
    }
}

void AMQPHandler::SendPpmErrorMessage(const nlohmann::json& cmd, const std::string& error_detail) {
    try {
        auto ppm_reporter = PPMReporter::GetInstance();
        const auto& deviceId = ConfigManager::GetInstance().GetDeviceIdentity();

        nlohmann::json ppm_error;
        ppm_error["timestamp"] = std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();
        ppm_error["type"] = "error";
        ppm_error["event"] = "aag-nack";
        ppm_error["product"] = deviceId.product;
        ppm_error["service"] = deviceId.service;
        ppm_error["instance"] = deviceId.instance;

        // Filter known attributes only
        static const std::unordered_set<std::string> allowed_fields = {
            "deviceCommandId", "priority", "command", "channelAddress",
            "validUntil", "requestedOutputTime", "requestedOuputTime",
            "sequenceNo", "announcementId", "announcementHash", "announcementProfile"
        };
        nlohmann::json filtered_meta;
        if (cmd.contains("pdevCommand") && cmd["pdevCommand"].contains("cmd-meta")) {
            const auto& cmd_meta = cmd["pdevCommand"]["cmd-meta"];
            for (auto it = cmd_meta.begin(); it != cmd_meta.end(); ++it) {
                if (allowed_fields.count(it.key())) {
                    filtered_meta[it.key()] = it.value();
                }
            }
        } else if (cmd.contains("cmd-meta")) {
            const auto& cmd_meta = cmd["cmd-meta"];
            for (auto it = cmd_meta.begin(); it != cmd_meta.end(); ++it) {
                if (allowed_fields.count(it.key())) {
                    filtered_meta[it.key()] = it.value();
                }
            }
        } else {
            for (auto it = cmd.begin(); it != cmd.end(); ++it) {
                if (allowed_fields.count(it.key())) {
                    filtered_meta[it.key()] = it.value();
                }
            }
        }
        ppm_error["metaData"] = filtered_meta;

        ppm_error["detail"] = error_detail;

        ppm_reporter->PublishPPM("error", "aag-nack", ppm_error.dump());
        LOG_INFO("Published PPM error aag-nack message: " + error_detail);
    } catch (const std::exception& ex) {
        LOG_ERROR("Failed to publish PPM error message: " + std::string(ex.what()));
    }
}

/**
 * @brief Generates a unique message ID for deduplication based on message content.
 * 
 * Creates a deterministic hash from the message content to identify duplicates.
 * Uses deviceCommandId and announcementId as primary identifiers.
 * 
 * @param message The JSON message to generate ID from.
 * @return A unique string identifier for the message.
 */
std::string AMQPHandler::GenerateMessageId(const nlohmann::json& message) {
    try {
        std::string message_id;
        
        // Extract key identifiers from the message
        if (message.contains("physicalDeviceCommands") && message["physicalDeviceCommands"].is_array()) {
            const auto& commands = message["physicalDeviceCommands"];
            if (!commands.empty() && commands[0].contains("pdevCommand")) {
                const auto& pdev_cmd = commands[0]["pdevCommand"];
                if (pdev_cmd.contains("cmd-meta") && pdev_cmd["cmd-meta"].is_object()) {
                    const auto& cmd_meta = pdev_cmd["cmd-meta"];
                    
                    // Use deviceCommandId as primary identifier
                    if (cmd_meta.contains("deviceCommandId")) {
                        message_id += cmd_meta["deviceCommandId"].get<std::string>();
                    }
                    
                    // Add announcementId if present
                    if (cmd_meta.contains("announcementId")) {
                        message_id += "|" + cmd_meta["announcementId"].get<std::string>();
                    }
                    
                    // Add sequence number for additional uniqueness
                    if (cmd_meta.contains("sequenceNo")) {
                        message_id += "|" + std::to_string(cmd_meta["sequenceNo"].get<int>());
                    }
                    
                    // Add timestamp for temporal uniqueness
                    if (message.contains("timestamp")) {
                        message_id += "|" + std::to_string(message["timestamp"].get<long long>());
                    }
                }
            }
        }
        
        // Fallback to full message hash if no specific identifiers found
        if (message_id.empty()) {
            message_id = std::to_string(std::hash<std::string>{}(message.dump()));
        }
        
        return message_id;
    } catch (const std::exception& ex) {
        LOG_ERROR("[AMQPHandler] Error generating message ID: " + std::string(ex.what()));
        // Fallback to message hash
        return std::to_string(std::hash<std::string>{}(message.dump()));
    }
}

/**
 * @brief Checks if a message is a duplicate and handles it appropriately.
 * 
 * Thread-safe check for duplicate messages. If a duplicate is found,
 * logs the duplicate detection and returns true.
 * 
 * @param message_id The unique message identifier.
 * @return true if the message is a duplicate, false otherwise.
 */
bool AMQPHandler::IsDuplicateMessage(const std::string& message_id) {
    std::lock_guard<std::mutex> lock(dedup_mutex_);
    
    if (processed_message_ids_.find(message_id) != processed_message_ids_.end()) {
        LOG_WARNING("[AMQPHandler] 🚫 DUPLICATE MESSAGE DETECTED: " + message_id);
        LOG_WARNING("[AMQPHandler] Dropping duplicate message to prevent reprocessing");
        return true;
    }
    
    return false;
}

/**
 * @brief Adds a message ID to the processed set for deduplication.
 * 
 * Thread-safe addition of message ID to the processed set.
 * Maintains cache size limit by removing oldest entries if needed.
 * 
 * @param message_id The unique message identifier to add.
 */
void AMQPHandler::MarkMessageAsProcessed(const std::string& message_id) {
    std::lock_guard<std::mutex> lock(dedup_mutex_);
    
    // Add the message ID to processed set
    processed_message_ids_.insert(message_id);
    
    // Maintain cache size limit using configuration
    const size_t maxDedupCacheSize = ConfigManager::GetInstance().GetAmqp().max_dedup_cache_size;
    if (processed_message_ids_.size() > maxDedupCacheSize) {
        // Remove oldest entries (simple FIFO approach)
        auto it = processed_message_ids_.begin();
        processed_message_ids_.erase(it);
        LOG_INFO("[AMQPHandler] Deduplication cache size limit reached, removed oldest entry");
    }
    
    LOG_DEBUG("[AMQPHandler] Message marked as processed: " + message_id);
}

