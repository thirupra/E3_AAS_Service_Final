#include "elisa3_manager.h"
#include "log_manager.h"

#include <algorithm>
#include <cerrno>
#include <chrono>
#include <cctype>
#include <cstring>
#include <fcntl.h>
#include <iomanip>
#include <iostream>
#include <limits>
#include <sstream>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/stat.h>
#include <unistd.h>
#include <poll.h>

namespace {

/// Wire message structures (must match ELISA side)
struct SizeMsg {
  long mtype;                  ///< Message type (must be 1)
  unsigned long buffer_size;   ///< Payload size in bytes
};

struct PayloadMsg {
  long mtype;                  ///< Message type (must be 99)
  char mdata[4096];            ///< Message data buffer
};

constexpr long kSizeMsgType      = 1;    // AAS -> ELISA (size header)
constexpr long kTxPayloadMsgType = 99;   // AAS -> ELISA (ANNOUT payload)
constexpr long kRxPayloadMsgType = 199;  // ELISA -> AAS (replies)

namespace {
  /// Split string into lines, preserving empty lines and not dropping
/// the last segment if the payload doesn't end with '\n'.
static std::vector<std::string> SplitLinesPreserveEmpty(const std::string& s) {
  std::vector<std::string> out;
  std::string cur;
  for (char c : s) {
    if (c == '\n') {
      out.push_back(cur);
      cur.clear();
    } else if (c != '\r') {
      cur.push_back(c);
    }
  }
  out.push_back(cur);  // keep last segment
  return out;
}
}
/**
 * @brief Ensures ftok token file exists and generates IPC key.
 *
 * Creates the necessary directories and token file, then generates a System V IPC key using ftok.
 * Handles both directory paths (creates .k file inside) and file paths (uses path directly).
 * Matches the Python ensure_token logic for compatibility.
 *
 * @param ftok_path Directory path or file path for the token file
 * @param proj_id Project ID for ftok (truncated to 8 bits)
 * @return Generated System V IPC key, or -1 on failure
 */
key_t MakeKey(const std::string& ftok_path, int proj_id) {
  std::string token;
  
  // Check if path has a suffix (like .key) - treat as file path
  size_t last_dot = ftok_path.find_last_of('.');
  size_t last_slash = ftok_path.find_last_of('/');
  
  bool has_suffix = (last_dot != std::string::npos && 
                     (last_slash == std::string::npos || last_dot > last_slash));
  
  if (has_suffix) {
    // Treat as file path (like Python ensure_token logic)
    ::mkdir(ftok_path.substr(0, ftok_path.find_last_of('/')).c_str(), 0700);
    token = ftok_path;
  } else {
    // Treat as directory path (original behavior)
    ::mkdir(ftok_path.c_str(), 0700);
    token = ftok_path + "/.k";
  }
  
  int fd = ::open(token.c_str(), O_CREAT | O_WRONLY | O_TRUNC, 0600);
  if (fd >= 0) {
    const char* content = "elisa3_ipc_token";
    ::write(fd, content, strlen(content));
    ::close(fd);
  }
  const int proj8 = (proj_id & 0xFF);
  key_t k = ::ftok(token.c_str(), proj8);
  // IPC key generated
  return k;
}

/**
 * @brief Converts a system_clock::time_point to epoch seconds.
 *
 * Converts the time point to Unix epoch seconds as required by
 * the ELISA wire format specification.
 *
 * @param tp Time point to convert
 * @return Epoch seconds since Unix epoch
 */
static inline long long ToEpochSeconds(const std::chrono::system_clock::time_point& tp) {
  using namespace std::chrono;
  return duration_cast<seconds>(tp.time_since_epoch()).count();
}

/**
 * @brief Safely checks if a string contains only ASCII digits.
 *
 * Performs a safe digit check that works correctly with signed char types.
 *
 * @param s String to check
 * @return true if all characters are ASCII digits, false otherwise
 */
static inline bool IsAllDigits(const std::string& s) {
  return std::all_of(s.begin(), s.end(), [](unsigned char c){ return std::isdigit(c); });
}

}  // namespace

/**
 * @brief Constructs an ELISA3Manager instance.
 *
 * Initializes the manager with the provided configuration and
 * automatically opens the message queue and starts the listener thread.
 *
 * @param cfg Configuration settings for the manager
 */
ELISA3Manager::ELISA3Manager(const Config& cfg) : cfg_(cfg) {
  // Match existing behavior: open queue and start listener in ctor.
  (void)OpenQueues();
  Start();
}

/**
 * @brief Destructs the ELISA3Manager instance.
 *
 * Ensures proper cleanup by stopping the listener thread.
 */
ELISA3Manager::~ELISA3Manager() { Stop(); }

/**
 * @brief Starts the ELISA3 listener thread.
 *
 * Launches the background thread that monitors for incoming
 * messages from ELISA3 devices. Does nothing if already running.
 */
void ELISA3Manager::Start() {
  if (listener_.joinable()) return;
  stop_.store(false);
  listener_ = std::thread(&ELISA3Manager::ListenerLoop, this);
  LOG_INFO("Message receiving loop started");
}

/**
 * @brief Stops the ELISA3 listener thread.
 *
 * Signals the listener thread to stop and waits for it to complete.
 * This is a blocking operation that ensures clean shutdown.
 */
void ELISA3Manager::Stop() {
  stop_.store(true);
  if (listener_.joinable()) listener_.join();
}

/**
 * @brief Sets the acknowledgment callback function.
 *
 * @param cb Callback function to invoke when ELISA3 acknowledgments are received
 */
void ELISA3Manager::SetAckCallback(AckCallback cb) { 
    ack_cb_ = std::move(cb); 
}

/**
 * @brief Sets the status callback function.
 *
 * @param cb Callback function to invoke when ELISA3 status updates are received
 */
void ELISA3Manager::SetStatusCallback(StatusCallback cb) { status_cb_ = std::move(cb); }

/**
 * @brief Sets the PPM error callback function.
 *
 * @param cb Callback function to invoke when ELISA3 error responses are received
 */
void ELISA3Manager::SetPpmErrorCallback(PpmErrorCallback cb) { ppm_error_cb_ = std::move(cb); }

/**
 * @brief Opens the System V message queue for ELISA3 communication.
 *
 * Creates the necessary IPC key and opens the message queue using
 * the configuration settings. Handles errors gracefully.
 *
 * @return true if queue opened successfully, false otherwise
 */
bool ELISA3Manager::OpenQueues() {
  // Idempotent: if already open, return success
  if (qid_ != -1) return true;
  
  key_t key = MakeKey(cfg_.ipc_ftok_path, cfg_.ipc_proj_id);
  if (key == -1) {
    LOG_ERROR("[ELISA3] ❌ IPC key generation failed");
    return false;
  }
  int qid = ::msgget(key, 0666 | IPC_CREAT);
  if (qid == -1) {
    LOG_ERROR("[ELISA3] ❌ Message queue creation failed");
    return false;
  }
  LOG_INFO("[IPC] AAS: seed=" + cfg_.ipc_ftok_path + " proj_id=" + std::to_string(cfg_.ipc_proj_id) + " key=0x" + std::to_string(key) + " msqid=" + std::to_string(qid));
  LOG_INFO("[ELISA3] ✓ IPC message queue ready");
  qid_ = qid;
  return true;
}

/**
 * @brief Sends a size header message to ELISA3.
 *
 * Sends the size header that precedes the actual payload message.
 * This is required by the ELISA3 communication protocol.
 *
 * @param payload_size Size of the payload that will follow
 * @return true if size header sent successfully, false otherwise
 */
bool ELISA3Manager::SendSizeHeader(unsigned long payload_size) {
  if (qid_ == -1 && !OpenQueues()) return false;
  SizeMsg sm{};
  sm.mtype = kSizeMsgType;
  sm.buffer_size = payload_size;  // exact payload size expected by simulator
  LOG_DEBUG("IPC AAS: msgsnd qid=" + std::to_string(qid_) + " mtype=" + std::to_string(sm.mtype) + " bytes=" + std::to_string(sm.buffer_size) + " (size header)");
  if (::msgsnd(qid_, &sm, sizeof(sm.buffer_size), 0) == -1) {
    LOG_ERROR("[ELISA3] ❌ Size header send failed");
    return false;
  }
  return true;
}

/**
 * @brief Sends a payload message to ELISA3.
 *
 * Sends the actual payload data to the ELISA3 device.
 * The payload must fit within the message buffer size.
 *
 * @param payload The payload data to send
 * @return true if payload sent successfully, false otherwise
 */
bool ELISA3Manager::SendPayload(const std::string& payload) {
  LOG_INFO("📤 Sending payload to ELISA3 device via IPC");
  if (qid_ == -1 && !OpenQueues()) return false;
  PayloadMsg pm{};
  pm.mtype = kTxPayloadMsgType;
  if (payload.size() + 1 > sizeof(pm.mdata)) {
    LOG_ERROR("Payload too large (" + std::to_string(payload.size()) + " bytes)");
    return false;
  }
  std::memcpy(pm.mdata, payload.c_str(), payload.size() + 1);
  size_t bytes = std::min(payload.size() + 1, sizeof(pm.mdata));
  LOG_DEBUG("IPC AAS: msgsnd qid=" + std::to_string(qid_) + " type=" + std::to_string(pm.mtype) + " bytes=" + std::to_string(bytes) + " (payload)");
  if (::msgsnd(qid_, &pm, bytes, 0) == -1) {
    LOG_ERROR("Send failed: " + std::string(std::strerror(errno)));
    return false;
  }
  LOG_INFO("Payload sent successfully to ELISA3");
  return true;
}

/**
 * @brief Receives a reply message from ELISA3 with timeout.
 *
 * Waits for an incoming message from ELISA3 devices with a 5-second timeout.
 * Uses poll() to avoid blocking indefinitely.
 *
 * @param out_payload Output parameter for the received payload
 * @return true if message received successfully, false on timeout or error
 */

/**
 * @brief Receives a reply message from ELISA3 with timeout.
 *
 * NOTE: This implementation is simplified to use the ListenerLoop's existing 
 * sleep/retry mechanism for a robust non-blocking read.
 *
 * @param out_payload Output parameter for the received payload
 * @return true if message received successfully, false on timeout or error
 */
bool ELISA3Manager::ReceiveReply(std::string* out_payload) {
    // Note: We deliberately skip the logging of ReceiveReply to declutter the logs 
    // when using this in a tight loop with a 50ms sleep. 
    
    if (qid_ == -1 && !OpenQueues()) return false;

    // Use IPC_NOWAIT to check for a message immediately.
    // The ListenerLoop handles the waiting/sleeping.
    PayloadMsg msg{};
    ssize_t n = ::msgrcv(qid_, &msg, sizeof(msg.mdata), kRxPayloadMsgType, IPC_NOWAIT);

    if (n < 0) {
        // Only log errors that are NOT "No message available" (EAGAIN/ENOMSG)
        if (errno != EAGAIN && errno != ENOMSG) {
            LOG_ERROR("[ELISA3Manager] msgrcv(reply) failed: " + std::string(std::strerror(errno)));
        }
        // In the context of the ListenerLoop, this is NOT a fatal failure, 
        // it just means "no message available right now."
        return false;
    }
    
    // Message successfully received.
    
    // Extract the payload data into the output string
    if (n > 0) {
        // If the last byte is the null terminator we sent, exclude it from the string length.
        if (n > 0 && msg.mdata[n - 1] == '\0') n--;
        *out_payload = std::string(msg.mdata, n);
    }
    
    // Log success before returning
    return true;
}

/**
 * @brief Builds the outgoing payload for ELISA3 communication.
 *
 * Constructs the payload message according to the ELISA3 protocol specification.
 * The control map must be in exact order as specified in section 4.2.1.1.18.
 *
 * @param job The announcement job to build payload for
 * @return Formatted payload string for ELISA3
 */
std::string ELISA3Manager::BuildOutgoingPayload(const AnnouncementJob& job) const {
  // Control map lines must be in exact order (see spec 4.2.1.1.18):
  // status, magic, ablaufid, prio, ziel, start, stop, intervall, connstatus
  std::ostringstream os;
  os << "status\nstart\n";                            // start an announcement
  os << job.device_command_id << '\n';                // magic
  os << job.announcement_id << '\n';                  // ablaufid
  os << job.priority << '\n';                         // prio
  os << job.channel_address << '\n';                  // ziel

  // Convert time_points to epoch seconds before writing
  os << ToEpochSeconds(job.requested_output_time) << '\n'; // start timestamp
  os << ToEpochSeconds(job.valid_until) << '\n';           // stop timestamp

  os << "0\n";  // intervall
  os << "0\n";  // connstatus

  // Content vector
  os << "1\n";                             // number of files
  os << job.announcement_id << '\n';
  os << job.local_file_path << '\n';
  return os.str();
}

/**
 * @brief Sends a play request for an announcement job.
 *
 * Builds the payload from the job and sends it to ELISA3.
 * This is the main method for initiating announcement playback.
 *
 * @param job The announcement job to send
 * @return true if request sent successfully, false otherwise
 */
bool ELISA3Manager::SendPlayRequest(const AnnouncementJob& job) {
  const std::string payload = BuildOutgoingPayload(job);
  if (!SendSizeHeader(payload.size())) return false;
  return SendPayload(payload);
}

/**
 * @brief Sends a play request with a pre-built SES payload.
 *
 * Sends a raw SES (SES-Parser) payload to ELISA3.
 * This method is used when the payload is already formatted.
 *
 * @param ses_payload Pre-formatted SES payload string
 * @return true if request sent successfully, false otherwise
 */
bool ELISA3Manager::SendPlayRequest(const std::string& ses_payload) {
  if (!SendSizeHeader(ses_payload.size())) return false;
  return SendPayload(ses_payload);
}


/**
 * @brief Dispatches incoming messages from ELISA3.
 *
 * Parses incoming ELISA3 messages and routes them to appropriate callbacks.
 * Handles both acknowledgment messages and spontaneous TDM status updates.
 *
 * @param payload The incoming message payload to process
 */
void ELISA3Manager::DispatchIncoming(const std::string& payload) {
    auto lines = SplitLinesPreserveEmpty(payload);

    int code = 0;
    std::string par2 = "";
    
    // --- 1. Basic Payload Check ---
    if (lines.empty() || lines[0] != std::string("status")) {
        // This handles incomplete or improperly formatted payloads
        LOG_ERROR("Dispatch: Invalid or missing 'status' header. Payload: [" + 
                  payload.substr(0, 80) + "]");
        // Call status_cb_ with default/error code if available
        if (status_cb_) status_cb_(TdmStatus{0, par2});
        return;
    }

    // --- 2. Extract Data ---
    // Expected reply layout from elisa3_sim / device:
    // 0: "status"
    // 1: magic (deviceCommandId) or empty for spontaneous/TDM
    // 2: code (decimal)
    // 3: par1 (may be empty; we ignore because ElisaAck doesn't have it)
    // 4: par2 (often the channel)
    // 5: par3 (ignored)
    const std::string magic = (lines.size() > 1) ? lines[1] : "";
    
    if (lines.size() > 2 && !lines[2].empty()) {
        try {
            code = std::stoi(lines[2]);
        } catch (...) {
            LOG_WARNING("Dispatch: Failed to parse code from line 2: '" + lines[2] + "'");
            code = 0;
        }
    }
    // Par2 is line 4
    par2 = (lines.size() > 4) ? lines[4] : "";
    
    // --- 3. Determine Message Type and Dispatch ---

    // Spontaneous status (magic empty) -> Status Callback
    if (magic.empty()) {
        
        if (status_cb_) {
            status_cb_(TdmStatus{static_cast<unsigned long>(code), par2});
        }
        return;
    }

    // Reply to a command (magic present) -> Acknowledgment Callback
    { // Use a block for cleaner variable scope
        ElisaAck ack{};
        ack.device_command_id = magic;
        ack.code = code;
        ack.par2 = par2;
        
        LOG_INFO("Dispatch: -> ACK Reply. Magic: " + ack.device_command_id + 
                 ", Code: " + std::to_string(ack.code) + ", Par2: " + ack.par2);

        // Check if this is an error response that should be sent as PPM error
        bool is_error = false;
        std::string error_detail;
        
        switch (code) {
            case 2:
                // Code 2 is success, call ack_cb_ for CommandProcessorAndScheduler
                if (ack_cb_) {
                    ack_cb_(ack);
                } else {
                    LOG_WARNING("Dispatch: ACK received (code 2), but ack_cb_ not set!");
                }
                break;
            case 11:
                is_error = true;
                error_detail = "E_NO_DEVICE";
                break;
            case 15:
                is_error = true;
                error_detail = "E_NO_LINE";
                break;
            case 21:
                is_error = true;
                error_detail = "E_DEST_DEF";
                break;
            case 22:
                is_error = true;
                error_detail = "E_DEST_OCC";
                break;
            case 500:
                is_error = true;
                error_detail = "E_UNKNOWN";
                break;
            default:
            if (status_cb_) {
              TdmStatus status;
              status.code = ack.code;
              status.par2 = ack.par2;
              status_cb_(status);
            }else {
              LOG_WARNING("Message from ELISA received, but status_cb_ not set!");
            }
                  break;
        }
        
        // Send PPM error message directly for error codes
        if (is_error && ppm_error_cb_) {
            LOG_INFO("Sending PPM error for code " + std::to_string(code) + ": " + error_detail);
            ppm_error_cb_(ack.device_command_id, error_detail);
        }
        
        // For error responses, also call ack_cb_ to notify the scheduler that the command was processed
        // This prevents E_TIMEOUT errors since the scheduler knows the command was handled
        // NOTE: We still need to call ack_cb_ to remove the waiter from the scheduler's timeout mechanism
        if (is_error && ack_cb_) {
            LOG_INFO("Notifying scheduler of error response for command: " + ack.device_command_id);
            ack_cb_(ack);
        }
    }
}
/**
 * @brief Main loop for the ELISA3 listener thread.
 *
 * Continuously monitors for incoming messages from ELISA3 devices
 * and dispatches them to appropriate handlers. Runs until stopped.
 */
void ELISA3Manager::ListenerLoop() {
  // Always attempt to open at start to detect failure early
  OpenQueues();

  while (!stop_.load()) {
    std::string reply;
    if (!ReceiveReply(&reply)) {
      // Sleep a little to avoid a tight loop on failure
      ::usleep(50 * 1000);
            continue;
        }
    DispatchIncoming(reply);
    }
}
