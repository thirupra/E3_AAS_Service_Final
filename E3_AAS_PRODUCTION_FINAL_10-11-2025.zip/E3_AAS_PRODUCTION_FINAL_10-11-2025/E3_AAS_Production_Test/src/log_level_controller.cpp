/**
 * @file LogLevelController.cpp
 * @brief Runtime log level control for production debugging.
 * @author Chetana Srinivas
 * @date 2025
 */

#include "log_level_controller.h"
#include "log_manager.h"
#include <csignal>
#include <iostream>
#include <fstream>
#include <thread>
#include <chrono>
#include <ctime>
#include <sstream>
#include <iomanip>

LogLevelController& LogLevelController::GetInstance() {
    static LogLevelController instance;
    return instance;
}

void LogLevelController::Initialize() {
    // Set up signal handlers for runtime log level control
    signal(SIGUSR1, LogLevelController::SignalHandler);  // Cycle to next log level
    signal(SIGUSR2, LogLevelController::SignalHandler);  // Enable debug logging
    
    std::cout << "[LogLevelController] ✓ Signal handlers registered:" << std::endl;
    std::cout << "  SIGUSR1 (kill -USR1 <pid>) → Cycle to next log level" << std::endl;
    std::cout << "  SIGUSR2 (kill -USR2 <pid>) → Enable DEBUG logging" << std::endl;
}

void LogLevelController::SignalHandler(int signum) {
    auto& controller = GetInstance();
    std::lock_guard<std::mutex> lock(controller.mutex_);
    
    auto now = std::chrono::system_clock::now();
    auto time_t = std::chrono::system_clock::to_time_t(now);
    auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(
        now.time_since_epoch()) % 1000;
    
    std::stringstream ss;
    ss << std::put_time(std::gmtime(&time_t), "%Y-%m-%d %H:%M:%S");
    ss << "." << std::setfill('0') << std::setw(3) << ms.count();
    ss << " UTC";
    std::string timestamp = ss.str();
    
    switch (signum) {
        case SIGUSR1: {
            // Cycle through log levels: Error -> Warning -> Info -> Debug -> Error
            LogLevel current = LogManager::GetInstance().GetLogLevel();
            LogLevel next;
            switch (current) {
                case LogLevel::Error:   next = LogLevel::Warning; break;
                case LogLevel::Warning: next = LogLevel::Info; break;
                case LogLevel::Info:    next = LogLevel::Debug; break;
                case LogLevel::Debug:   next = LogLevel::Error; break;
            }
            LogManager::GetInstance().SetLogLevel(next);
            std::cout << "[" << timestamp << "] [LogLevelController] 🔄 Log level cycled to: " << 
                         static_cast<int>(next) << std::endl;
            break;
        }
        case SIGUSR2:
            LogManager::GetInstance().SetLogLevel(LogLevel::Debug);
            std::cout << "[" << timestamp << "] [LogLevelController] 🔍 DEBUG logging ENABLED" << std::endl;
            break;
        default:
            std::cout << "[" << timestamp << "] [LogLevelController] Unknown signal: " << signum << std::endl;
    }
    
    // Log current level
    LogLevel current = LogManager::GetInstance().GetLogLevel();
    std::cout << "[" << timestamp << "] [LogLevelController] Current log level: " << 
                 static_cast<int>(current) << std::endl;
}

void LogLevelController::SetLogLevel(LogLevel level) {
    std::lock_guard<std::mutex> lock(mutex_);
    LogManager::GetInstance().SetLogLevel(level);
    
    auto now = std::chrono::system_clock::now();
    auto time_t = std::chrono::system_clock::to_time_t(now);
    auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(
        now.time_since_epoch()) % 1000;
    
    std::stringstream ss;
    ss << std::put_time(std::gmtime(&time_t), "%Y-%m-%d %H:%M:%S");
    ss << "." << std::setfill('0') << std::setw(3) << ms.count();
    ss << " UTC";
    std::string timestamp = ss.str();
    
    std::cout << "[" << timestamp << "] [LogLevelController] Log level set to: " << 
                 static_cast<int>(level) << std::endl;
}

LogLevel LogLevelController::GetLogLevel() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return LogManager::GetInstance().GetLogLevel();
}
