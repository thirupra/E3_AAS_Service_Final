/**
 * @file SignalManager.cpp
 * @brief Implementation of SignalManager to replace global signal handling.
 */

#include "signal_manager.h"
#include "certificate_module.h"
#include "status_feedback_module.h"
#include "log_manager.h"

// Initialize static instance pointer
SignalManager* SignalManager::instance_ = nullptr;

SignalManager& SignalManager::GetInstance() {
    static SignalManager instance;
    return instance;
}

void SignalManager::SignalHandler(int signum) {
    if (instance_) {
        instance_->HandleSignal(signum);
    }
}

void SignalManager::HandleSignal(int signum) {
    LOG_INFO("Signal " + std::to_string(signum) + " received. Initiating graceful shutdown...");
    
    // Stop certificate module renewal loop
    if (certModule_) {
        certModule_->StopRenewalLoop();
    }
    
    // Stop status feedback module
    if (statusModule_) {
        statusModule_->Stop();
    }
    
    // Notify waiting threads
    {
        std::lock_guard<std::mutex> lock(exitMtx_);
        exitCv_.notify_all();
    }
}

void SignalManager::SetCertModule(CertificateModule* cert) {
    certModule_ = cert;
}

void SignalManager::SetStatusModule(StatusFeedbackModule* status) {
    statusModule_ = status;
}

void SignalManager::InstallHandlers() {
    instance_ = this;
    signal(SIGINT, &SignalHandler);
    signal(SIGTERM, &SignalHandler);
}

void SignalManager::WaitForExit() {
    std::unique_lock<std::mutex> lock(exitMtx_);
    exitCv_.wait(lock);
}

void SignalManager::TriggerExit() {
    {
        std::lock_guard<std::mutex> lock(exitMtx_);
        exitCv_.notify_all();
    }
}