/**
 * @file DownloadManager.cpp
 * @brief Implementation of the DownloadManager class, which manages concurrent
 * audio download tasks using a thread pool.
 *
 * @details
 * This module is responsible for scheduling and managing multiple audio downloads
 * in parallel, following the {S_103} Download Manager specification. It uses a
 * producer-consumer model where tasks are submitted to a thread-safe queue and
 * processed by a pool of worker threads. This design ensures that the main
 * application thread is not blocked by long-running download operations, enabling
 * efficient handling of Physical Device Command and Control (PDCC) jobs.
 *
 * Key features:
 * - **Thread-safe Task Queue**: Uses a mutex and condition variable to safely
 *   handle task submission and retrieval from multiple threads.
 * - **Multi-threaded Worker Pool**: Spawns a configurable number of threads
 *   to process download jobs concurrently, leveraging available CPU cores.
 * - **Asynchronous Status Reporting**: Utilizes a callback function to
 *   report download success or failure, providing loose coupling with
 *   other components like AMQPHandler.
 * - **Graceful Shutdown**: The `Deinit` method ensures all worker threads
 *   are stopped and cleaned up properly, preventing resource leaks.
 * - **Thread-safe Logging**: Uses `LogInfo` and `LogError` with a mutex to
 *   ensure consistent, non-interleaved logging across worker threads, aligning
 *   with the logging strategy in AMQPHandler and BrokerBase.
 *
 * @note This class depends on `AudioFileFetcher` for downloading audio files and
 * a status callback to report outcomes to components like AMQPHandler. Logging is
 * thread-safe to support debugging in a multithreaded environment.
 *
 * @see AudioFileFetcher, AMQPHandler
 * @spec {S_103} Download Manager
 * @author Thirupathi Rao
 * @date 2025-09-09
 */

#include "download_manager.h"
#include "log_manager.h"
#include <iostream>
#include <mutex>
#include <unordered_map>
#include <string>

/**
 * @brief Anonymous namespace for internal logging utilities.
 *
 * @details Defines thread-safe logging functions `LogInfo` and `LogError` to

/**
 * @brief Constructs a DownloadManager.
 *
 * @details Initializes the DownloadManager instance with the necessary components.
 * It stores a reference to an `AudioFileFetcher` to delegate the actual file
 * fetching logic and a callback function for status updates. The `running_` flag
 * is set to false until `Init` is called.
 *
 * @param fetcher Reference to the `AudioFileFetcher` instance used for handling
 * the actual download process.
 * @param statusCb A `DownloadStatusCallback` that will be invoked to report the
 * status of each download job (e.g., success or failure).
 */
DownloadManager::DownloadManager(AudioFileFetcher& fetcher, DownloadStatusCallback statusCb)
    : fetcher_(fetcher)
    , statusCallback_(std::move(statusCb))
    , running_(false) {}

/**
 * @brief Initializes the DownloadManager and starts the worker thread pool.
 *
 * @details Sets up the DownloadManager for operation by creating and launching
 * a number of worker threads that continuously process download jobs from the
 * task queue. The number of threads defaults to the system's hardware concurrency
 * to optimize performance, with a fallback to 1 thread if undetermined. Logs
 * initialization using `LogInfo` for debugging.
 *
 * @param numThreads The desired number of worker threads to spawn. If `0`,
 * defaults to `std::thread::hardware_concurrency()`.
 * @return `true` if initialization was successful.
 */
bool DownloadManager::Init(size_t numThreads) {
    if (numThreads == 0) {
        numThreads = std::thread::hardware_concurrency();
        if (numThreads == 0) numThreads = 1; // Fallback to 1 thread if hardware_concurrency() is 0
    }

    running_ = true;
    for (size_t i = 0; i < numThreads; ++i) {
        // Create and launch a new worker thread, passing a pointer to this object
        // to allow the thread to access member functions.
        workerThreads_.emplace_back(&DownloadManager::WorkerThread, this);
    }
    return true;
}

/**
 * @brief Gracefully stops all worker threads and waits for them to complete.
 *
 * @details Performs a clean shutdown by setting the `running_` flag to `false`
 * to signal worker threads to exit their processing loop. Uses `cv_.notify_all()`
 * to wake up waiting threads, then joins each thread to ensure completion. Clears
 * the thread vector to free resources. Logs shutdown using `LogInfo`.
 */
void DownloadManager::Deinit() {
    {
        std::lock_guard<std::mutex> lock(mutex_);
        running_ = false; // Signal all worker threads to stop
    }
    cv_.notify_all(); // Wake up all waiting threads
    for (auto& thread : workerThreads_) {
        if (thread.joinable()) {
            thread.join(); // Wait for the thread to finish its work
        }
    }
    workerThreads_.clear();
    this->LogInfo("Deinitialized, all worker threads stopped");
}

/**
 * @brief Submits a new download job to the task queue.
 *
 * @details Adds a download job to the thread-safe task queue, using a
 * `std::lock_guard` to protect access. Notifies one waiting worker thread
 * via `cv_.notify_one()` to process the new task. Logs submission for
 * traceability.
 *
 * @param job The `PDCCJob` struct containing details for the download task,
 * such as the audio URI and hash.
 */
void DownloadManager::SubmitTask(const PDCCJob& job) {
    std::lock_guard<std::mutex> lock(mutex_); // Lock for thread safety
    
    // Handle multiple audio files per announcement
    if (!job.audioUris.empty() && !job.announcementHashes.empty()) {
        // Multi-file announcement
        LogInfo("Submitting multi-file download for announcement: " + job.announcementId + 
               " (" + std::to_string(job.audioUris.size()) + " files)");
        
        // Initialize announcement download state
        AnnouncementDownloadState& state = announcementStates_[job.announcementId];
        state.announcementId = job.announcementId;
        state.audioUris = job.audioUris;
        state.announcementHashes = job.announcementHashes;
        state.localFilePaths.resize(job.audioUris.size());
        state.downloadCompleted.resize(job.audioUris.size(), false);
        state.downloadErrors.resize(job.audioUris.size());
        state.completedCount = 0;
        state.failedCount = 0;
        state.startTime = std::chrono::system_clock::now();
        
        // Create individual download jobs for each file
        for (size_t i = 0; i < job.audioUris.size(); ++i) {
            InternalDownloadJob internalJob;
            internalJob.announcementId = job.announcementId;
            internalJob.audioUri = job.audioUris[i];
            internalJob.announcementHash = job.announcementHashes[i];
            internalJob.fileIndex = i;
            
            taskQueue_.push(internalJob);
            cv_.notify_one(); // Notify worker for each file
        }
    } else if (!job.audioUri.empty()) {
        // Single file (backward compatibility)
        LogInfo("Submitting single-file download for announcement: " + job.announcementId);
        
        // Convert to internal job format
        InternalDownloadJob internalJob;
        internalJob.announcementId = job.announcementId;
        internalJob.audioUri = job.audioUri;
        internalJob.announcementHash = job.announcementHash;
        internalJob.fileIndex = 0;
        
        // Initialize announcement state for single file
        AnnouncementDownloadState& state = announcementStates_[job.announcementId];
        state.announcementId = job.announcementId;
        state.audioUris = {job.audioUri};
        state.announcementHashes = {job.announcementHash};
        state.localFilePaths.resize(1);
        state.downloadCompleted.resize(1, false);
        state.downloadErrors.resize(1);
        state.completedCount = 0;
        state.failedCount = 0;
        state.startTime = std::chrono::system_clock::now();
        
        taskQueue_.push(internalJob);
        cv_.notify_one();
    } else {
        LogError("Invalid download job: no audio URIs provided for announcement " + job.announcementId);
    }
}

/**
 * @brief Sends download status updates to the registered listener via a callback.
 *
 * @details Invokes the provided callback to report the outcome of a download job
 * (e.g., success or failure). Ensures the callback is valid before invocation to
 * prevent crashes. Used by worker threads to communicate results to components
 * like AMQPHandler.
 *
 * @param job The `PDCCJob` that was just processed.
 * @param status A string describing the status, typically "SUCCESS" or "FAILED".
 * @param filePath The local path to the downloaded file. Empty if the download failed.
 */
void DownloadManager::SetAudioStatus(const PDCCJob& job,
                                    const std::string& status,
                                    const std::string& filePath) {
    // This method is kept for backward compatibility but not used in multi-file implementation
    if (statusCallback_) {
        std::vector<std::string> filePaths;
        if (!filePath.empty()) {
            filePaths.push_back(filePath);
        }
        statusCallback_(job.announcementId, status, filePaths);
    } else {
        LogError("Warning: Status callback is not set.");
    }
}

void DownloadManager::HandleSingleFileCompletion(const std::string& announcementId, size_t fileIndex, 
                                               bool success, const std::string& localFilePath, 
                                               const std::string& errorMessage) {
    std::lock_guard<std::mutex> lock(mutex_);
    
    auto it = announcementStates_.find(announcementId);
    if (it == announcementStates_.end()) {
        LogError("Received completion for unknown announcement: " + announcementId);
        return;
    }
    
    AnnouncementDownloadState& state = it->second;
    
    // Validate file index
    if (fileIndex >= state.audioUris.size()) {
        LogError("Invalid file index " + std::to_string(fileIndex) + 
                " for announcement " + announcementId);
        return;
    }
    
    // Update completion status
    if (!state.downloadCompleted[fileIndex]) {  // Prevent double counting
        state.downloadCompleted[fileIndex] = true;
        
        if (success) {
            state.localFilePaths[fileIndex] = localFilePath;
            state.completedCount++;
            LogInfo("File " + std::to_string(fileIndex + 1) + "/" + 
                   std::to_string(state.audioUris.size()) + " completed for announcement " + announcementId);
        } else {
            state.downloadErrors[fileIndex] = errorMessage;
            state.failedCount++;
            LogError("File " + std::to_string(fileIndex + 1) + "/" + 
                    std::to_string(state.audioUris.size()) + " failed for announcement " + announcementId + 
                    ": " + errorMessage);
        }
        
        // Check if all files are processed
        if (state.IsAllProcessed()) {
            std::string finalStatus;
            std::vector<std::string> completedFilePaths;
            
            if (state.IsAllSuccessful()) {
                finalStatus = "SUCCESS";
                completedFilePaths = state.localFilePaths;
                LogInfo("All files completed successfully for announcement " + announcementId);
            } else if (state.completedCount > 0) {
                finalStatus = "PARTIAL_SUCCESS";
                // Only include successful downloads in file paths
                for (size_t i = 0; i < state.localFilePaths.size(); ++i) {
                    if (state.downloadCompleted[i] && !state.localFilePaths[i].empty()) {
                        completedFilePaths.push_back(state.localFilePaths[i]);
                    }
                }
                LogError("Partial success for announcement " + announcementId + ": " + 
                        std::to_string(state.completedCount) + "/" + std::to_string(state.audioUris.size()) + 
                        " files downloaded successfully");
            } else {
                finalStatus = "FAILED";
                LogError("All files failed for announcement " + announcementId);
            }
            
            // Report final status via callback
            if (statusCallback_) {
                statusCallback_(announcementId, finalStatus, completedFilePaths);
            }
            
            // Clean up state
            announcementStates_.erase(it);
        }
    }
}

/**
 * @brief The main function for each worker thread in the pool.
 *
 * @details Executes in a continuous loop for each worker thread, following the
 * producer-consumer pattern:
 * 1. Acquires a lock and waits on the condition variable until a job is available
 *    or the manager is shutting down (`running_ = false`).
 * 2. Exits if shutting down and the queue is empty.
 * 3. Retrieves and removes a job from the queue, releasing the lock.
 * 4. Performs the download using `fetcher_.FetchAudio`.
 * 5. Reports the status via `SetAudioStatus`, logging success or failure with
 *    `LogInfo` or `LogError` for thread-safe debugging.
 * The loop prevents busy-waiting by using `cv_.wait`, saving CPU cycles.
 */
void DownloadManager::WorkerThread() {
    while (true) {
        InternalDownloadJob job;
        {
            // Use std::unique_lock to allow for waiting on the condition variable
            std::unique_lock<std::mutex> lock(mutex_);

            // Wait until the queue has a job or the manager is shutting down
            cv_.wait(lock, [this] {
                return !taskQueue_.empty() || !running_;
            });

            // Check for shutdown condition
            if (!running_ && taskQueue_.empty()) {
                break; // Exit the thread gracefully
            }

            // Get the next job from the queue and remove it
            job = taskQueue_.front();
            taskQueue_.pop();
        }

        LOG_INFO("🔄 Processing download request");
        LOG_INFO("  → AnnouncementID: " + job.announcementId + 
                 " (File " + std::to_string(job.fileIndex + 1) + ")");

        // Perform the actual download using the dedicated file fetcher
        std::string filePath = fetcher_.FetchAudio(job.audioUri, job.announcementHash);

        // Report the status of the individual file download
        if (!filePath.empty()) {
            this->LogInfo("Downloaded path: " + filePath);
            LOG_INFO("[DOWNLOAD] ✓ Download SUCCESS");
            LOG_INFO("  → File: " + filePath);
            HandleSingleFileCompletion(job.announcementId, job.fileIndex, true, filePath);
        } else {
            this->LogError("[DOWNLOAD] ❌ Download FAILED");
            this->LogError("  → AnnouncementID: " + job.announcementId);
            HandleSingleFileCompletion(job.announcementId, job.fileIndex, false, "", "Download failed");
        }
    }
}

/**
 * @brief Thread-safe logging methods (replaces global namespace functions)
 */
void DownloadManager::LogInfo(const std::string& message) const {
    std::lock_guard<std::mutex> lock(logMutex_);
    LOG_INFO("[DownloadManager] " + message);
}

void DownloadManager::LogError(const std::string& message) const {
    std::lock_guard<std::mutex> lock(logMutex_);
    LOG_ERROR(message);
}

/**
 * @brief Checks if an audio file already exists in the cache.
 * @param hash Hash of the audio file to check.
 * @return true if file exists in cache, false otherwise.
 */
bool DownloadManager::IsAudioCached(const std::string& hash) {
    // Use the AudioFileFetcher's IsAudioCached method
    return fetcher_.IsAudioCached(hash);
}