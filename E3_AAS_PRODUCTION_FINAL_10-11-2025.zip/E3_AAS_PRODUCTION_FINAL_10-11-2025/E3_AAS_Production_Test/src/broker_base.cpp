/**
 * @file BrokerBase.cpp
 * @brief Implementation of BrokerBase utilities and connection handling.
 *
 * Specification: {S_101} Broker Connectivity and Configuration
 *
 * Features:
 *  - Implements utility function to generate formatted timestamps.
 *  - Complements connection lifecycle defined in BrokerBase.h.
 *  - Provides AMQP publishing functionality.
 *
 * Author: Thirupathi Rao
 * Date: 2025-09-10
 */

#include "broker_base.h"
#include "log_manager.h"
#include <iomanip>
#include <chrono>
#include <mutex>
#include <cstring>

/**
 * @brief Get the current local timestamp as a formatted string.
 * @return Timestamp in "YYYY-MM-DD HH:MM:SS" format.
 */
std::string BrokerBase::currentTimestamp() {
    auto now = std::chrono::system_clock::now();
    std::time_t now_c = std::chrono::system_clock::to_time_t(now);
    std::tm utc_tm = *std::gmtime(&now_c);

    std::ostringstream oss;
    oss << std::put_time(&utc_tm, "%Y-%m-%d %H:%M:%S UTC");
    return oss.str();
}

/**
 * @brief Establishes a connection to the AMQP broker.
 * @return true if connection is successful, false otherwise.
 */
bool BrokerBase::Connect() {
    conn_ = amqp_new_connection();
    if (!conn_) {
        LOG_ERROR("Failed to create AMQP connection object");
        return false;
    }

    bool useTLS = false;
    std::string certFile, keyFile, caFile;

    if (certModule_) {
        // TLS using CertificateModule
        useTLS = true;
        certFile = certModule_->GetValidCert();
        keyFile = certModule_->GetKeyPath();
        caFile = certModule_->GetCABundlePath();
        if (certFile.empty() || keyFile.empty() || caFile.empty()) {
            LOG_ERROR("CertificateModule provided empty cert paths");
            return false;
        }
        LOG_INFO("Using CertificateModule for TLS");
    } else if (!config_.client_cert_file.empty() &&
               !config_.client_key_file.empty() &&
               !config_.ca_cert_file.empty()) {
        // TLS using cert paths from config
        useTLS = true;
        certFile = config_.client_cert_file;
        keyFile = config_.client_key_file;
        caFile = config_.ca_cert_file;
        LOG_INFO("Using certificate files from config for TLS");
    } else {
        // Plain TCP
        useTLS = false;
        LOG_INFO("No certificates provided. Using plain TCP.");
    }

    if (useTLS) {
        // SSL/TLS socket
        socket_ = amqp_ssl_socket_new(conn_);
        if (!socket_) {
            LOG_ERROR("Failed to create SSL socket");
            return false;
        }
        if (amqp_ssl_socket_set_cacert(socket_, caFile.c_str()) != AMQP_STATUS_OK) {
            LOG_ERROR("Failed to set CA certificate");
            return false;
        }
        if (amqp_ssl_socket_set_key(socket_, certFile.c_str(), keyFile.c_str()) != AMQP_STATUS_OK) {
            LOG_ERROR("Failed to set client certificate/key");
            return false;
        }
    } else {
        // Plain TCP socket
        socket_ = amqp_tcp_socket_new(conn_);
        if (!socket_) {
            LOG_ERROR("Failed to create TCP socket");
            return false;
        }
    }

    // Open the socket
    if (amqp_socket_open(socket_, config_.host.c_str(), config_.port) != AMQP_STATUS_OK) {
        LOG_ERROR("Failed to open socket to " + config_.host + ":" + std::to_string(config_.port));
        return false;
    }

    // Login
    amqp_rpc_reply_t reply = amqp_login(conn_, config_.virtual_host.c_str(),
                                        0, 131072, 0, AMQP_SASL_METHOD_EXTERNAL,
                                        config_.username.c_str(), config_.password.c_str());
    if (reply.reply_type != AMQP_RESPONSE_NORMAL) {
        LOG_ERROR("Login failed");
        return false;
    }

    // Open channel
    amqp_channel_open(conn_, 1);
    reply = amqp_get_rpc_reply(conn_);
    if (reply.reply_type != AMQP_RESPONSE_NORMAL) {
        LOG_ERROR("Channel open failed");
        return false;
    }

    // Declare exchange
    amqp_exchange_declare(conn_, 1, amqp_cstring_bytes(config_.exchange.c_str()),
                          amqp_cstring_bytes("direct"), 1, 1, 0, 0, amqp_empty_table);
    reply = amqp_get_rpc_reply(conn_);
    if (reply.reply_type != AMQP_RESPONSE_NORMAL) {
        LOG_ERROR("Exchange declare failed");
        return false;
    }

    // Declare queue only if queue_name is not empty
    if (!config_.queue_name.empty()) {
        amqp_queue_declare(conn_, 1, amqp_cstring_bytes(config_.queue_name.c_str()),
                           1, 1, 0, 0, amqp_empty_table);
        reply = amqp_get_rpc_reply(conn_);
        if (reply.reply_type != AMQP_RESPONSE_NORMAL) {
            LOG_ERROR("Queue declare failed");
            return false;
        }
        // Bind queue, only if a queue was declared
        amqp_queue_bind(conn_, 1, amqp_cstring_bytes(config_.queue_name.c_str()),
                        amqp_cstring_bytes(config_.exchange.c_str()),
                        amqp_cstring_bytes(config_.routing_key.c_str()), amqp_empty_table);
        reply = amqp_get_rpc_reply(conn_);
        if (reply.reply_type != AMQP_RESPONSE_NORMAL) {
            LOG_ERROR("Queue bind failed");
            return false;
        }
    }
    connected_ = true;
    //LOG_INFO("Connected to " + config_.host + ":" + std::to_string(config_.port));
    return PostConnectSetup();
}

/**
 * @brief Disconnects from the AMQP broker.
 */
void BrokerBase::Disconnect() {
    if (connected_) {
        amqp_channel_close(conn_, 1, AMQP_REPLY_SUCCESS);
        amqp_connection_close(conn_, AMQP_REPLY_SUCCESS);
        amqp_destroy_connection(conn_);
        conn_ = nullptr;
        socket_ = nullptr;
        connected_ = false;
        LOG_INFO("Disconnected from " + config_.host + ":" + std::to_string(config_.port));
    }
}

/**
     * @brief Publishes a message to a specific exchange with a routing key.
    *
    * This virtual method is intended to be overridden by a publishing-focused
     * derived class. It sends the given message to the specified AMQP exchange
     * and routing key. The base implementation does nothing and returns false.
     *
     * @param exchange The name of the AMQP exchange to publish to.
     * @param routing_key The routing key used by the exchange to route the message.
     * @param message The content of the message to be published.
    * @return `true` if the message was successfully published, `false` otherwise.
    */
   bool BrokerBase::Publish(const std::string& exchange, const std::string& routing_key, const std::string& message) {
    return false;
}
