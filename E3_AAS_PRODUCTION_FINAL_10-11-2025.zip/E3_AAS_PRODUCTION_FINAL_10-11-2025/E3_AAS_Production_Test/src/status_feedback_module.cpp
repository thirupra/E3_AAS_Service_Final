/**
 * @file StatusFeedbackModule.cpp
 * @author Thirupathi Rao
 * @date 2025-09-22
 * @brief Implementation of the StatusFeedbackModule for periodic and event-driven
 *        status publishing to the TDM broker, as per IRIS+ TDM specification.
 *
 * @details
 * This module is responsible for:
 * - Establishing and maintaining a connection to the TDM broker (RabbitMQ, AMQP 0.9.1).
 * - Managing device state transitions according to the TDM spec.
 * - Periodically publishing "RUNNING" and "DEGRADED" heartbeat messages.
 * - Publishing event-driven "STARTED", "FAULT", and "RESTARTING" messages.
 * - Tracking defective destinations and device errors as reported by ELISA III-IP.
 * - Building and publishing JSON messages that conform to the IRIS+ backend TDM specification.
 *
 * @spec
 */

#include "status_feedback_module.h"
#include "log_manager.h"
#include "compression_utils.h"
#include "config_manager.h"
#include <nlohmann/json.hpp>
#include <chrono>
#include <iomanip>
#include <sstream>
#include <iostream>
#include <unordered_set>
#include <mutex>
#include <zlib.h>

using json = nlohmann::json;

/**
 * @class StatusFeedbackModule
 * @brief Singleton module to manage device state feedback towards the TDM broker.
 *
 * @details
 * Handles connection to the TDM broker, tracks device and channel errors,
 * and publishes status messages as required by the IRIS+ TDM specification.
 */
 
// -------------------- Singleton -------------------
/**
 * @brief Get the singleton instance of StatusFeedbackModule.
 * @param cfg Reference to the configuration object.
 * @param elisaManager Shared pointer to the ELISA3Manager instance.
 * @param certModule Pointer to the CertificateModule instance.
 * @return Reference to the singleton StatusFeedbackModule.
 */
StatusFeedbackModule& StatusFeedbackModule::GetInstance(
    Config& cfg,
    std::shared_ptr<ELISA3Manager> elisaManager,
    CertificateModule* certModule)
{
    static StatusFeedbackModule instance(cfg, elisaManager, certModule);
    return instance;
}

// -------------------- Constructor --------------------
/**
 * @brief Constructor for StatusFeedbackModule.
 * @param cfg Reference to the configuration object.
 * @param elisaManager Shared pointer to the ELISA3Manager instance.
 * @param certModule Pointer to the CertificateModule instance.
 */
StatusFeedbackModule::StatusFeedbackModule(
    Config& cfg,
    std::shared_ptr<ELISA3Manager> elisaManager,
    CertificateModule* certModule)
    : BrokerBase(cfg.tdm_broker, certModule),
      elisaManager_(elisaManager),
      certModule_(certModule),
      currentState_(State::kUninitialized),
      shutdown_requested_(false)
{
}

// -------------------- Destructor --------------------
/**
 * @brief Destructor for StatusFeedbackModule. Stops the module and disconnects from the broker.
 */
StatusFeedbackModule::~StatusFeedbackModule() {
    Stop();
}

// -------------------- Connect Override --------------------
/**
 * @brief Establishes a connection to the TDM broker.
 * @return True if connection is successful, false otherwise.
 */
bool StatusFeedbackModule::Connect() {
    if (!BrokerBase::Connect()) {
        LOG_ERROR("Failed to connect to TDM broker");
        return false;
    }
    LOG_INFO("╔════════════════════════════════════════════════════════════════╗");
    LOG_INFO("║    [TDM] ✓ Connected to TDM broker: " + config_.host + ":" + std::to_string(config_.port));
    LOG_INFO("╚════════════════════════════════════════════════════════════════╝");

    return true;
}

// -------------------- Start --------------------
/**
 * @brief Starts the StatusFeedbackModule.
 *
 * - Connects to the TDM broker.
 * - Registers ELISA ACK callback.
 * - Starts the periodic status publishing thread.
 * Determines the current state for the periodic message:
 * If in FAULT, send FAULT.
 * If any defective destinations, send DEGRADED.Otherwise, send RUNNING.
 * Uses a mutex to safely access defective_destinations_
 */
void StatusFeedbackModule::Start() {
    LOG_INFO("Starting StatusFeedbackModule...");
    if (!Connect()) {
        LOG_ERROR("Failed to connect to TDM broker. Status feedback will not be available.");
    }
    
    // Register STATUS callback for TDM status messages (including ACK responses)
    elisaManager_->SetStatusCallback([this](const TdmStatus& status) {
        OnTdmStatus(status);
    });

    // Start periodic status thread
    shutdown_requested_ = false;
    periodicThread_ = std::thread([this] {
        bool firstMessage = true;
        auto lastPublishTime = std::chrono::steady_clock::now();
        
        while (!shutdown_requested_) {
            if (firstMessage) {
                BuildAndPublishStatus(State::kStarted, ElisaAck());
                currentState_ = State::kRunning;
                firstMessage = false;
                lastPublishTime = std::chrono::steady_clock::now();
            } else {
                // Check if enough time has passed since last publish (dedupe guard)
                auto now = std::chrono::steady_clock::now();
                auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(now - lastPublishTime).count();
                
                if (elapsed >= 30) {
                    State periodicState;
                    {
                        std::lock_guard<std::mutex> lock(defective_mutex_);
                        if (currentState_ == State::kFault) {
                            periodicState = State::kFault;
                        } else if (!defective_destinations_.empty()) {
                            periodicState = State::kDegraded;
                        } else {
                            periodicState = State::kRunning;
                        }
                    }
                    BuildAndPublishStatus(periodicState, ElisaAck());
                    lastPublishTime = now;
                }
            }
            std::this_thread::sleep_for(std::chrono::seconds(1)); // Check every second
        }
    });
}

// -------------------- Stop --------------------
/**
 * @brief Stops the StatusFeedbackModule.
 *
 * - Signals the periodic thread to stop.
 * - Waits for the thread to join.
 * - Disconnects from the TDM broker.
 */
void StatusFeedbackModule::Stop() {
    LOG_INFO("Stopping StatusFeedbackModule.");
    shutdown_requested_ = true;
    if (periodicThread_.joinable()) {
        periodicThread_.join();
    }
    Disconnect();
    currentState_ = State::kUninitialized;
}

// -------------------- ELISA ACK Handler --------------------
/**
 * @brief Handles ELISA ACK messages and updates device/channel state.
 * @param ack The ELISA ACK message containing error codes and parameters.
 *
 * @details
 * - Updates the set of defective destinations based on error codes.
 * - Transitions device state according to the TDM spec:
 *   - ERR_DESTDEF (21): Add defective channel.
 *   - NO_ERR_DEST (6): Remove defective channel.
 *   - ERR_DEVICEDEF (30): Set state to FAULT.
 *   - NO_ERR_DEVICE (7): Clear FAULT if possible.
 * - Publishes a status message if the state changes.
 */

// -------------------- TDM Status Handler --------------------
/**
 * @brief Handles spontaneous ELISA TDM status messages.
 * @param status The TDM status message containing code and parameters.
 * 
 * @details
 * Processes spontaneous status messages from ELISA (magic field empty).
 * Updates defective destinations and device state, then publishes to TDM broker.
 */
void StatusFeedbackModule::OnTdmStatus(const TdmStatus& status) {
    std::lock_guard<std::mutex> lock(defective_mutex_);
    const int received_code = status.code;
    State newState = currentState_;

    LOG_INFO("Handling ACK. Magic: [TDM], Code: " + std::to_string(received_code) + ", Par2: " + status.par2);

    // Update defective destinations based on status code
    if (received_code == 21 && !status.par2.empty()) { // ERR_DESTDEF
        defective_destinations_.insert(status.par2);
        LOG_INFO("-> TDM: Added defective destination: " + status.par2);
    } else if (received_code == 6 && !status.par2.empty()) { // NO_ERR_DEST
        auto erased = defective_destinations_.erase(status.par2);
        if (erased > 0) {
            LOG_INFO("-> TDM: Removed defective destination: " + status.par2);
        } else {
            LOG_INFO("-> TDM: Attempted to remove " + status.par2 + " but it wasn't in defective list");
        }
    }

    // Determine new state based on received code
    if (received_code == 30) { // ERR_DEVICEDEF
        newState = State::kFault;
    } else if (received_code == 7) { // NO_ERR_DEVICE
        newState = defective_destinations_.empty() ? State::kRunning : State::kDegraded;
    } else if (received_code == 21 || received_code == 6) {
        // Channel-specific codes: update based on remaining defective destinations
        if (currentState_ != State::kFault) {
            newState = defective_destinations_.empty() ? State::kRunning : State::kDegraded;
        }
    }

    // Publish if state changed
    if (newState != currentState_) {
        std::cout << "\n[TDM STATUS] 🔄 State Transition: " << StateToString(currentState_) 
                  << " → " << StateToString(newState) << std::endl;
        // Create a dummy ElisaAck for BuildAndPublishStatus
        ElisaAck dummy_ack;
        dummy_ack.code = received_code;
        dummy_ack.par2 = status.par2;
        BuildAndPublishStatus(newState, dummy_ack);
        currentState_ = newState;
    } else {
    }
}

// -------------------- ELISA ACK Handler (Final Refinement) --------------------
void StatusFeedbackModule::OnElisaAck(const ElisaAck& ack) {
    std::lock_guard<std::mutex> lock(defective_mutex_);
    //Flush output buffer to prevent logs from being skipped
    //std::cout << std::flush;
    const int received_code = ack.code; 
    State newState = currentState_; // Start with current state

    LOG_INFO("Handling ACK. Magic: " + ack.device_command_id + ", Code: " + std::to_string(received_code) + ", Par2: " + ack.par2);

    // Step 1: Update the defective destinations list first.
    if (received_code == 21 && !ack.par2.empty()) { // ERR_DESTDEF
        defective_destinations_.insert(ack.par2);
        LOG_INFO("-> Added defective destination: " + ack.par2);
    } else if (received_code == 6 && !ack.par2.empty()) { // NO_ERR_DEST
        defective_destinations_.erase(ack.par2);
        LOG_INFO("-> Removed defective destination: " + ack.par2);
    }

    // Step 2: Determine the new state based on the received code AND the current system state.
    
    // Check for global device errors (FAULT or NO_FAULT)
    if (received_code == 30) { // ERR_DEVICEDEF: Highest priority, unconditionally moves to FAULT
        newState = State::kFault;
    } else if (received_code == 7) { // NO_ERR_DEVICE: Clears global fault, moves to highest state based on channels
        newState = defective_destinations_.empty() ? State::kRunning : State::kDegraded;
    } 
    // If we're already in FAULT and didn't get a "clear fault" (Code 7), remain in FAULT.
    else if (currentState_ == State::kFault) {
        newState = State::kFault;
    }
    // Handle channel-related codes (21/6) or any other code: state depends purely on channel errors.
    else { 
        newState = defective_destinations_.empty() ? State::kRunning : State::kDegraded;
    }


    // Step 3: Publish if the state changes.
    if (newState != currentState_) {
        std::cout << "\n[TDM STATUS] 🔄 State Transition: " << StateToString(currentState_) 
                  << " → " << StateToString(newState) << std::endl;
        BuildAndPublishStatus(newState, ack);
        currentState_ = newState;
    }
}
// -------------------- Map ELISA codes --------------------
/**
 * @brief Maps an ELISA error code to a device state.
 * @param code The ELISA error code.
 * @return The corresponding device state.
 */
StatusFeedbackModule::State StatusFeedbackModule::MapElisaCodeToState(unsigned long code) {
    switch (code) {
        case 30: return State::kFault; //device definition error (all speaker circuits defective).
        case 21: return State::kDegraded; //some speaker circuits are defective.
        case 6:  return defective_destinations_.empty() ? State::kRunning : State::kDegraded; //no speaker circuit errors.
        case 7:  return defective_destinations_.empty() ? State::kRunning : State::kDegraded; //no device errors.
        default: return State::kRunning;
    }
}

// -------------------- Publish Status --------------------
/**
 * @brief Builds and publishes a TDM status message to the broker.
 * @param newState The new device state to report.
 * @param ack The ELISA ACK message (for error/channel details).
 *
 * @details
 * - Constructs a JSON message as per the IRIS+ TDM spec.
 * - Populates meta and data fields, including stateInfo and stateInfoDetails for errors.
 * - Publishes the message to the configured exchange and routing key.
 */
void StatusFeedbackModule::BuildAndPublishStatus(State newState, const ElisaAck& ack) {
    json j;
    // --- Timestamp with milliseconds (UTC RFC3339) ---
    auto now = std::chrono::system_clock::now();
    auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(now.time_since_epoch()) % 1000;
    std::time_t now_c = std::chrono::system_clock::to_time_t(now);
    std::tm utc_tm = *std::gmtime(&now_c);
    std::stringstream ss;
    ss << std::put_time(&utc_tm, "%Y-%m-%dT%H:%M:%S") << "." << std::setw(3) << std::setfill('0') << ms.count() << "Z";
    
    // Get the actual Device ID from certificate config (as per TDM spec)
    const auto& certConfig = ConfigManager::GetInstance().GetCertificate();
    std::string deviceId = certConfig.device_id;  //  Device ID
    
    // Get other info from device identity
    const auto& deviceIdentity = ConfigManager::GetInstance().GetDeviceIdentity();
    std::string staticIp = deviceIdentity.static_ip;

    // According to TDM specification {S_501}, sourcePhysicalDeviceUUID is REQUIRED
    if (deviceId.empty()) {
        LOG_ERROR("[TDM] Cannot publish TDM message: sourcePhysicalDeviceUUID is required");
        LOG_ERROR("[TDM] Device ID is empty. Skipping TDM message publication.");
        return; // Don't publish invalid message
    }
    j["meta"]["message"]["type"] = "ipm_device_state";
    j["meta"]["message"]["version"] = "2";
    j["meta"]["message"]["source"] = "aag." + deviceId;
    j["meta"]["message"]["creationTime"] = ss.str();

    j["data"]["state"]["state"] = StateToString(newState);
    j["data"]["state"]["staticIp"] = staticIp;
    j["data"]["state"]["sourcePhysicalDeviceUUID"] = deviceId;

    // If DEGRADED: Adds stateInfo and a list of defective channels.
    // If FAULT: Adds stateInfo for all channels defective.
    // If RESTARTING: Adds stateInfo for power failure.
    if (newState == State::kDegraded) {
        j["data"]["state"]["stateInfo"] = "E_DEST_DEF: Lautsprecherkreise defekt";
        json details = json::array();
        for (const auto& ch : defective_destinations_) {
            details.push_back({{"code", "E_DEST_DEF"}, {"info", ch}});
        }
        j["data"]["state"]["stateInfoDetails"] = details;
    } else if (newState == State::kFault) {
        j["data"]["state"]["stateInfo"] = "E_DEST_DEF: Alle Lautsprecherkreise defekt";
    } else if (newState == State::kRestarting) {
        j["data"]["state"]["stateInfo"] = "E_POWERFAIL: Ausfall der Spannungsversorgung";
    }

    // Printing
    // Emit info logs similar to Python client
    std::string state_str = StateToString(newState);
    std::string state_info;
    if (j.contains("data") && j["data"].contains("state") && j["data"]["state"].contains("stateInfo")) {
        state_info = j["data"]["state"]["stateInfo"].get<std::string>();
    } else {
        state_info = "";
    }
    LOG_INFO("📡 STARTING TDM MESSAGE SEND");
    LOG_INFO("📡 State: " + state_str);
    // print the pretty JSON payload to stdout for visibility
    //std::cout << j.dump(2) << std::endl;

    bool published = Publish(config_.exchange, config_.routing_key, j.dump());
    if (published) {
        std::cout << "[TDM STATUS] ✓ Published " << StateToString(newState) << " status to TDM broker" << std::endl;
    } else {
        std::cout << "[TDM STATUS] ❌ Failed to publish " << StateToString(newState) << " status" << std::endl;
    }
}

// -------------------- State to String --------------------
/**
 * @brief Converts a State enum value to its string representation.
 * @param state The state enum value.
 * @return The corresponding string.
 */
std::string StatusFeedbackModule::StateToString(State state) {
    switch (state) {
        case State::kUninitialized: return "UNINITIALIZED";
        case State::kRunning: return "RUNNING";
        case State::kStarted: return "STARTED";
        case State::kDegraded: return "DEGRADED";
        case State::kFault: return "FAULT";
        case State::kRestarting: return "RESTARTING";
        default: return "UNKNOWN";
    }
}

/**
 * @brief Publishes a message to a specific exchange with a routing key.
 * @param exchange The AMQP exchange to publish to.
 * @param routing_key The routing key for message routing.
 * @param message The message content to publish.
 * @return true if the message was successfully published, false otherwise.
 */
bool StatusFeedbackModule::Publish(const std::string& exchange, const std::string& routing_key, const std::string& message) {
    if (!connected_ || !conn_) {
        LOG_ERROR("Cannot publish: not connected to broker");
        return false;
    }

    amqp_bytes_t message_bytes;
    message_bytes.len = message.size();
    message_bytes.bytes = (void*)message.c_str();

    amqp_basic_properties_t props;
    memset(&props, 0, sizeof(props));
    props._flags = AMQP_BASIC_CONTENT_TYPE_FLAG;
    props.content_type = amqp_cstring_bytes("application/json");

    int status = amqp_basic_publish(
        conn_, 1, amqp_cstring_bytes(exchange.c_str()),
        amqp_cstring_bytes(routing_key.c_str()), 0, 0,
        &props, message_bytes);

    if (status != AMQP_STATUS_OK) {
        LOG_ERROR("Failed to publish message: " + std::string(amqp_error_string2(status)));
        return false;
    }

    return true;
}