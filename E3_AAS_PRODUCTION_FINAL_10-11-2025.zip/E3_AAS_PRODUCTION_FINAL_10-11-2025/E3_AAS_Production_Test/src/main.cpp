/**
 * @file main.cpp
 * @brief Main entry point for the Audio Announcement System integrating Certificate Management, AMQP Handler, PPM, Download Manager, Audio File Fetcher, and Status Feedback Module.
 *
 * @details
 * This application initializes and orchestrates all major modules required for the Audio Announcement System:
 * - Loads configuration from a merged JSON file.
 * - Initializes and manages the CertificateModule for device authentication and renewal.
 * - Sets up the AMQPHandler for broker communication.
 * - Initializes the PPMReporter for Physical Device Command and Control (PDCC) reporting.
 * - Sets up the DownloadManager and AudioFileFetcher for audio asset management.
 * - Initializes the StatusFeedbackModule and ELISA3Manager for device state feedback.
 * - Handles graceful shutdown and resource cleanup.
 *
 * @author Thirupathi Rao
 * @date 2025-09-23
 */

#include <iostream>
#include <string>
#include <thread>
#include <chrono>
#include <csignal>
#include <mutex>
#include <condition_variable>
#include <fstream>
#include <memory>
#include <iomanip>
#include <sstream>
#include <ctime>
#include "certificate_module.h"
#include "amqp_handler.h"
#include "ppm_emitter.h"
#include "ppm_reporter.h"
#include "download_manager.h"
#include "audio_file_fetcher.h"
#include "audio_file_cache.h"
#include "status_feedback_module.h"
#include "elisa3_manager.h"
#include "broker_base.h"
#include "pdcc_priority_queue_manager.h"
#include "nlohmann/json.hpp"
#include "aas_app.h"
#include "command_processor_and_scheduler.h"
#include "log_level_controller.h"
#include "log_manager.h"
#include "config_manager.h"
#include <algorithm>  // for std::transform
#include <cctype>     // for ::tolower
#include "announcement_job.h"
#include "signal_manager.h"
#include "version.h"

// Config file name
const std::string kBrokerConfigFile = "broker_config.json";

// Callback for download status
void DownloadStatusHandler(const std::string& announcementId, const std::string& status, const std::string& filePath) {
    LOG_INFO("Download Status: AnnouncementId=" + announcementId +
             ", Status=" + status +
             ", FilePath=" + filePath);
}

std::string ToIso8601(const std::chrono::system_clock::time_point& tp) {
    std::time_t t = std::chrono::system_clock::to_time_t(tp);
    std::tm tm = *std::gmtime(&t);
    char buf[32];
    std::strftime(buf, sizeof(buf), "%Y-%m-%dT%H:%M:%S.000Z", &tm);
    return std::string(buf);
}

int main() {
    // ---------------- Version Information ----------------
    LOG_INFO("╔════════════════════════════════════════════════════════════════╗");
    LOG_INFO("║  Automatic Announcement Service (AAS) v1.0.0 (Built: Nov 7 2025)");
    LOG_INFO("                     Copyright 2025 Wenzel");
    LOG_INFO("╚════════════════════════════════════════════════════════════════╝");
    
    LOG_INFO("Starting " + Version::GetVersionInfo() + " - Production Release");
    
    // ---------------- Load Configuration using ConfigManager ----------------
    auto& configManager = ConfigManager::GetInstance();
    if (!configManager.LoadFromFile(kBrokerConfigFile)) {
        LOG_ERROR("Failed to load configuration from " + kBrokerConfigFile);
        return 1;
    }

    // ---------------- CertificateModule Initialization ----------------
    // Initialize signal handling with SignalManager
    auto& signalMgr = SignalManager::GetInstance();
    signalMgr.InstallHandlers();

    // Get certificate config from ConfigManager (already loaded)
    const auto& certConfig = ConfigManager::GetInstance().GetCertificate();
    CertificateModule certModule(
        certConfig.device_id,
        certConfig.cert_path,
        certConfig.key_path,
        certConfig.ott_url,
        certConfig.ca_bundle_path,
        certConfig.sign_url,
        certConfig.renew_url,
        certConfig.ott_user,
        certConfig.ott_pass,
        certConfig.fingerprint
    );
    // Register certificate module with SignalManager for shutdown coordination
    signalMgr.SetCertModule(&certModule);

    if (!certModule.Init()) {
        LOG_ERROR("Certificate initialization/renewal failed!");
        return 1;
    }

    std::this_thread::sleep_for(std::chrono::seconds(1));

    // Run certificate renewal in a separate thread to not block audio system
    std::thread certThread([&certModule]() {
        certModule.RunDailyRenewalLoop();
    });

    std::this_thread::sleep_for(std::chrono::seconds(1));

    // ---------------------------------------------------
    // ----- Runtime Log Level Control Initialization -----
    // ---------------------------------------------------
    LogLevelController::GetInstance().Initialize();
    LOG_INFO("Runtime log level control initialized");

    // ---------------------------------------------------
    // ----- Audio Announcement System Initialization -----
    // ---------------------------------------------------
    // Get audio cache config from ConfigManager
    const auto& audioCacheConfig = configManager.GetAudioCache();
    AudioFileCache audioCache(audioCacheConfig.max_size_bytes);
    if (!audioCache.Init()) {
        LOG_ERROR("AudioFileCache initialization failed!");
        return 1;
    }

    AudioFileFetcher fetcher(&certModule, audioCache);
    if (!fetcher.Init()) {
        LOG_ERROR("AudioFileFetcher initialization failed!");
        return 1;
    }
    // Set up mainConfig from ConfigManager
    Config mainConfig = Config::FromConfigManager();
    // PDCCPriorityQueueManager instance
    PDCCPriorityQueueManager pdccQueueManager(mainConfig);

    // Get AMQP broker config from ConfigManager
    BrokerConfig amqp_broker_config = configManager.GetAmqpBroker();
    AMQPHandler* amqpHandler = AMQPHandler::GetInstance(amqp_broker_config, &certModule, &pdccQueueManager); //with certs
    //AMQPHandler* amqpHandler = AMQPHandler::GetInstance(amqp_broker_config, nullptr, &pdccQueueManager); //without certificates

    // Initialize PPMReporter FIRST to ensure it's ready before AMQP processing starts
    auto ppm_reporter = PPMReporter::GetInstance(&certModule);
    //auto ppm_reporter = PPMReporter::GetInstance(nullptr);
    if (!ppm_reporter->Init()) {
        LOG_ERROR("PPMReporter initialization failed!");
        return 1;
    }
    
    // Wait a moment to ensure PPMReporter connection is fully established
    std::this_thread::sleep_for(std::chrono::milliseconds(500));
    LOG_INFO("PPMReporter initialized and ready");

    // Create AASApp instance FIRST so we can reference it in DownloadManager callback
    AASApp aas_app(mainConfig, 
      // PPM emission callback
      [&configManager](const std::string& status, const std::string& event, const AnnouncementJob& job, const std::string& detail) {
        auto ppm_reporter = PPMReporter::GetInstance();
        const auto& deviceId = configManager.GetDeviceIdentity();

        nlohmann::json ppm_msg;
        ppm_msg["timestamp"] = std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();
        ppm_msg["product"] = deviceId.product;
        ppm_msg["service"] = deviceId.service;
        ppm_msg["instance"] = deviceId.instance;
        
        // Fix the type/event assignment to match Python format
        ppm_msg["type"] = status; // Don't convert to lowercase here
        ppm_msg["event"] = event; // Don't convert to lowercase here

        // Build full metaData block to match Python exactly
        nlohmann::json metaData;
        metaData["deviceCommandId"] = job.device_command_id;
        metaData["priority"] = job.priority;
        metaData["command"] = CommandKindToString(job.command);
        metaData["channelAddress"] = job.channel_address;
        metaData["validUntil"] = ToIso8601(job.valid_until);
        metaData["requestedOuputTime"] = ToIso8601(job.requested_output_time); // Keep typo for compatibility
        metaData["sequenceNo"] = job.sequence_no;
        metaData["announcementId"] = job.announcement_id;
        metaData["announcementHash"] = job.announcement_hash;
        metaData["announcementProfile"] = {
            {"text", job.profile_text},
            {"language", job.profile_language}
        };

        ppm_msg["metaData"] = metaData;

        if (!detail.empty()) {
            ppm_msg["detail"] = detail;
        }

        // Use PublishPPM method which handles lowercase conversion internally
        ppm_reporter->PublishPPM(status, event, ppm_msg.dump(4));
      },
      // Download function (no longer used - DownloadManager handles downloads)
      [&fetcher](const std::string& url, const std::string& hash, std::string* error) -> std::optional<std::string> {
        // This function is no longer called since we use DownloadManager
        return std::nullopt;
      },
      // Status function
      [&pdccQueueManager](const AnnouncementJob& job, DownloadState state, const std::string& detail) {
        // Update the pdccQueueManager with download status
        std::string status_str;
        switch (state) {
          case DownloadState::kPending:
            status_str = "Pending";
            break;
          case DownloadState::kInProgress:
            status_str = "InProgress";
            break;
          case DownloadState::kSuccess:
            status_str = "Success";
            break;
          case DownloadState::kError:
            status_str = "Error";
            break;
          default:
            status_str = "Unknown";
            break;
        }
        pdccQueueManager.UpdateAudioStatus(job.announcement_id, status_str, job.local_file_path);
      }
    );

    // Create DownloadManager with callback that notifies both PDCCQueueManager and AASApp
    auto statusCallback = [&pdccQueueManager, &aas_app](const std::string& announcementId, const std::string& status, const std::vector<std::string>& filePaths) {
        // Handle multi-file announcements
        LOG_INFO("Download status for announcement " + announcementId + ": " + status + 
                " (" + std::to_string(filePaths.size()) + " files)");
        
        // For backward compatibility, use first file path or empty string
        std::string primaryFilePath = filePaths.empty() ? "" : filePaths[0];
        
        // Update PDCCQueueManager (existing functionality)
        pdccQueueManager.UpdateAudioStatus(announcementId, status, primaryFilePath);
        
        // Notify AASApp about download completion with multi-file support
        bool success = (status == "SUCCESS" || status == "PARTIAL_SUCCESS");
        if (success && !filePaths.empty()) {
            // For multi-file support, we'll pass the primary file path for now
            // TODO: Update AASApp to handle multiple files
            aas_app.HandleDownloadComplete(announcementId, success, primaryFilePath);
            
            // Log all downloaded files
            for (size_t i = 0; i < filePaths.size(); ++i) {
                LOG_INFO("  File " + std::to_string(i + 1) + ": " + filePaths[i]);
            }
        } else {
            aas_app.HandleDownloadComplete(announcementId, false, "");
        }
    };

    DownloadManager downloadManager(fetcher, statusCallback);
    if (!downloadManager.Init(100)) { 
        LOG_ERROR("DownloadManager initialization failed!");
        return 1;
    }

    amqpHandler->SetDownloadManager(&downloadManager);

    if (!amqpHandler->Init()) {
        LOG_ERROR("AMQPHandler initialization failed!");
        return 1;
    }

    // Start AMQP consume loop in background AFTER PPMReporter is ready
    std::thread amqpThread([amqpHandler]() {
        amqpHandler->Start();
    });

    // Connect AASApp to AMQPHandler
    amqpHandler->SetAASApp(&aas_app);

    

    // Start AASApp after AMQPHandler is ready
    aas_app.Start();

    // -------------------------------------------------
    // ---- Status Feedback + ELISA3Manager Section ----
    // -------------------------------------------------
    // ---- Get TDM Broker Config from ConfigManager ----
    const auto& tdm_config = configManager.GetTdmBroker();

    

    // ---- Use ELISA3Manager from AASApp + StatusFeedbackModule ----
    // Get a reference to the ELISA3Manager instance from AASApp instead of creating a separate one
    ELISA3Manager& elisaManager = aas_app.GetElisaManager();
    std::shared_ptr<ELISA3Manager> elisaManagerPtr = std::shared_ptr<ELISA3Manager>(&elisaManager, [](ELISA3Manager*){});

    // Set up PPM error callback for ELISA3Manager to send aag-nack directly
    elisaManagerPtr->SetPpmErrorCallback([&ppm_reporter, &configManager](const std::string& device_command_id, const std::string& error_detail) {
        const auto& deviceId = configManager.GetDeviceIdentity();
        const auto& ppm_broker = configManager.GetPpmBroker();
        nlohmann::json ppm_error;
        ppm_error["timestamp"] = std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();
        ppm_error["type"] = "error";
        ppm_error["event"] = "aag-nack";
        ppm_error["product"] = deviceId.product;
        ppm_error["service"] = deviceId.service;
        ppm_error["instance"] = deviceId.instance;
        ppm_error["metaData"] = {
            {"deviceCommandId", device_command_id}
        };
        ppm_error["detail"] = error_detail;
        
        ppm_reporter->Publish(ppm_broker.exchange, ppm_broker.routing_key, ppm_error.dump(4));
        LOG_INFO("Published PPM error (aag-nack) for DeviceCommandID: " + 
                 device_command_id + " with error: " + error_detail);
    });

    StatusFeedbackModule& statusModule =
        StatusFeedbackModule::GetInstance(mainConfig, elisaManagerPtr, &certModule); // with certificates
        //StatusFeedbackModule::GetInstance(mainConfig, elisaManagerPtr, nullptr); //without certs
    // Register status module with SignalManager for shutdown coordination
    signalMgr.SetStatusModule(&statusModule);

    statusModule.Start();

    std::thread statusThread([&statusModule]() {
        while (true) {
            std::this_thread::sleep_for(std::chrono::seconds(30));
    
        }
    });

    LOG_INFO("Waiting for AMQP and TDM messages...");
    LOG_INFO("Periodic RUNNING messages sent every 30 seconds. Press Ctrl+C to exit.");

    // ----------------- Main Wait Loop ------------------
    {
        // Wait for exit signal
        signalMgr.WaitForExit();
    }

    // -------------------- Cleanup ----------------------
    if (amqpThread.joinable()) amqpThread.join();
    if (certThread.joinable()) certThread.join();
    if (statusThread.joinable()) statusThread.join();

    downloadManager.Deinit();
    fetcher.Deinit();
    audioCache.Deinit();

    statusModule.Stop();

    LOG_INFO("Program exiting.");
    return 0;
}


