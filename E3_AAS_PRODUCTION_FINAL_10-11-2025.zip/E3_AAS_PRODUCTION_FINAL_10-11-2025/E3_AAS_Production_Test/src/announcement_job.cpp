#include "announcement_job.h"

/**
 * @brief Generates a unique deduplication key for this job.
 * 
 * Creates a composite key using announcement_id and sequence_no to
 * identify duplicate jobs and prevent redundant processing.
 * The key format is: "announcement_id/sequence_no"
 * 
 * @return Unique string key for deduplication
 */
std::string AnnouncementJob::DedupeKey() const {
    return announcement_id + "/" + std::to_string(sequence_no);
}

/**
 * @brief Checks if the job has expired beyond its valid time window.
 * 
 * Determines whether the current time has exceeded the job's valid_until
 * timestamp, indicating the job should no longer be processed.
 * This is used to clean up stale jobs and prevent processing of
 * announcements that are no longer valid.
 * 
 * @param now Current system time point to compare against
 * @return True if the job has expired, false otherwise
 */
bool AnnouncementJob::IsExpired(std::chrono::system_clock::time_point now) const {
    return now > valid_until;
}

