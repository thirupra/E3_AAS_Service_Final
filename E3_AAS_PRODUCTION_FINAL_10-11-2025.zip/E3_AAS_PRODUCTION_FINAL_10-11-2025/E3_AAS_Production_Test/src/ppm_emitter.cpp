#include "ppm_emitter.h"
#include "ppm_reporter.h"
#include <chrono>
#include <optional>

using nlohmann::json;

/**
 * @brief Internal method to send PPM messages.
 *
 * Constructs and sends PPM messages with the specified type and event.
 * Creates a JSON message with timestamp, routing information, and metadata.
 *
 * @param type Message type (info, success, error)
 * @param event Event identifier
 * @param cmd_meta Command metadata
 * @param detail Optional error detail
 */

void PPMEmitter::send(const std::string& type, const std::string& event,
                      const json& cmd_meta,
                      std::optional<std::string> detail)
{
    const auto now_ms = std::chrono::duration_cast<std::chrono::milliseconds>(
                            std::chrono::system_clock::now().time_since_epoch()).count();

    json msg = {
        {"timestamp", now_ms},
        {"type",      type},
        {"event",     event},
        {"product",   ctx_.product},
        {"service",   ctx_.service},
        {"instance",  ctx_.instance},
        {"metaData",  cmd_meta}
    };
    if (detail && !detail->empty()) msg["detail"] = *detail;

    //reporter_.Publish(ctx_.exchange, ctx_.routing_key, msg.dump());
    auto rk = ctx_.routing_key + "." + type + "." + event;
    reporter_.Publish(ctx_.exchange, rk, msg.dump());
}
