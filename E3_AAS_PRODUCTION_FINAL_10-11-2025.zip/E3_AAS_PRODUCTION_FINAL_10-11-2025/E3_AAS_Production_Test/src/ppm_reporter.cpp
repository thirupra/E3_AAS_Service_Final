/**
 * @file PPMReporter.cpp
 * @brief Singleton AMQP client for publishing PPM messages as per specification {S_110}.
 *
 * This module provides a single, centralized entry point for sending Pulse Per Minute (PPM)
 * messages to an AMQP (RabbitMQ) message broker. It is implemented as a **singleton**
 * to ensure that only one connection to the broker is ever established, preventing
 * conflicts and efficiently managing resources.
 *
 * Specification: {S_106} Outgoing PPM Reporting
 *
 * Responsibilities:
 * - **Connection Management**: Establishes and maintains a single AMQP connection for publishing messages.
 * - **Singleton Access**: Provides a thread-safe way to get the single instance of the reporter.
 * - **Message Publishing**: Publishes JSON-formatted messages to the configured exchange and routing key.
 * - **Logging**: Logs important events like connection status, successful publishes, and errors for easy debugging and traceability.
 *
 * @author Thirupathi Rao
 * @date 2025-09-09
 */
#include "ppm_reporter.h"
#include "log_manager.h"
#include "config_manager.h"
#include <iostream>
#include <nlohmann/json.hpp>
#include "broker_base.h"
#include <algorithm>  // for std::transform
#include <cctype>     // for ::tolower

/**
 * @brief Static pointer to the singleton instance of `PPMReporter`.
 *
 * This pointer is initialized to `nullptr` and will hold the single instance
 * of the class once it is created.
 */
PPMReporter* PPMReporter::instance_ = nullptr;

/**
 * @brief Constructs the PPMReporter.
 *
 * The constructor is private to enforce the singleton pattern. It initializes
 * the class by calling the `Init()` method, which establishes the connection
 * to the broker.
 */

PPMReporter::PPMReporter(CertificateModule* certModule)
    : BrokerBase(ConfigManager::GetInstance().GetPpmBroker(), certModule), connected_(false) {
}


/**
 * @brief Destructor for the PPMReporter.
 *
 * The destructor is responsible for a clean shutdown. It calls `Deinit()` to
 * ensure all resources, including the AMQP connection, are properly released.
 */
PPMReporter::~PPMReporter() {
    Deinit();
}

/**
 * @brief Gets the single instance of the PPMReporter.
 *
 * This method is the only way to access the `PPMReporter` class. It checks
 * if an instance already exists. If not, it creates a new one. This ensures
 * that there is always and only one `PPMReporter` object in the application.
 *
 * @return A pointer to the singleton instance of `PPMReporter`.
 */

PPMReporter* PPMReporter::GetInstance() {
    if (!instance_) {
        instance_ = new PPMReporter(nullptr);
    }
    return instance_;
}

PPMReporter* PPMReporter::GetInstance(CertificateModule* certModule) {
    if (!instance_) {
        instance_ = new PPMReporter(certModule);
    }
    return instance_;
}

/**
 * @brief Deletes the singleton instance of `PPMReporter`.
 *
 * This method should be called once at the end of the application's lifecycle
 * to free the memory allocated for the singleton instance and ensure a clean exit.
 */
void PPMReporter::DestroyInstance() {
    delete instance_;
    instance_ = nullptr;
}

/**
 * @brief Establishes the AMQP connection to the broker.
 *
 * This method overrides the base class's `Connect()` method to perform the
 * initial connection handshake and set the `connected_` flag. It provides
 * specific logging for the `PPMReporter`.
 *
 * @return `true` if the connection is successfully established, `false` otherwise.
 */
bool PPMReporter::Connect() {
    if (!BrokerBase::Connect()) {
        return false;
    }
    connected_ = true;
    LOG_INFO("╔════════════════════════════════════════════════════════════════╗");
    LOG_INFO("║    [PPMReporter] ✓ Connected to PPM Broker: " + config_.host + ":" + std::to_string(config_.port));
    LOG_INFO("╚════════════════════════════════════════════════════════════════╝");
    //LOG_INFO("[PPMReporter] Connected to " + config_.host + ":" + std::to_string(config_.port));
    return true;
}

/**
 * @brief Publishes a JSON string message to a specific exchange and routing key.
 *
 * This method sends a JSON-formatted message to the specified AMQP exchange
 * using the given routing key. It first checks that the reporter is connected
 * before attempting to publish. If not connected, the method returns false.
 *
 * @param exchange The AMQP exchange to which the message will be published.
 * @param routing_key The routing key used by the exchange to route the message.
 * @param message The JSON string message body to be sent.
 * @return `true` if the message is successfully published, `false` otherwise.
 */
bool PPMReporter::Publish(const std::string& exchange, const std::string& routing_key, const std::string& message) {
    if (!connected_) {
        LOG_ERROR("Not connected");
        return false;
    }

    // Parse the JSON message to extract type and event for the header
    try {
        nlohmann::json json_msg = nlohmann::json::parse(message);
        std::string type = json_msg.value("type", "unknown");
        std::string event = json_msg.value("event", "unknown");
        
        // Print the descriptive header
        LOG_INFO("PPM " + type + " " + event);
        LOG_INFO("");
        LOG_INFO(json_msg.dump(2));
        
    } catch (const nlohmann::json::exception& e) {
        // Fallback to original format if JSON parsing fails
        LOG_INFO("[PPMReporter] Publishing to exchange: " + exchange + " with routing key: " + routing_key);
        LOG_INFO("[PPMReporter] Message content:\n" + message);
    }
    
    LOG_INFO("-------------------------------------------------------");


    amqp_bytes_t body;
    body.len = message.size();
    body.bytes = const_cast<char*>(message.data());

    const auto& amqp_config = ConfigManager::GetInstance().GetAmqp();
    int status = amqp_basic_publish(conn_, amqp_config.channel_id,
                                    amqp_cstring_bytes(config_.exchange.c_str()),
                                    amqp_cstring_bytes(config_.routing_key.c_str()),
                                    amqp_config.publish_flags, amqp_config.publish_flags, nullptr, body);
    if (status != AMQP_STATUS_OK) {
        LOG_ERROR("Publish failed: " + std::string(amqp_error_string2(status)));
        return false;
    }

    return true;
}

/**
 * @brief Build a dynamic routing key using base routing_key from config and the message type/event.
 *
 * Example: if config_.routing_key == "aag" and type == "SUCCESS", event == "aag-ack"
 * result -> "aag.success.aag-ack"
 *
 * @param type The message type (e.g., "SUCCESS", "ERROR")
 * @param event The event name (e.g., "aag-ack", "start-msg")
 * @return Dynamic routing key in format "<base>.<type>.<event>" (all lowercase)
 */
std::string PPMReporter::BuildDynamicRoutingKey(const std::string& type, const std::string& event) {
    std::string lower_type = type;
    std::string lower_event = event;
    std::transform(lower_type.begin(), lower_type.end(), lower_type.begin(), ::tolower);
    std::transform(lower_event.begin(), lower_event.end(), lower_event.begin(), ::tolower);

    return config_.routing_key + "." + lower_type + "." + lower_event;
}

/**
 * @brief Publish a PPM message using a dynamic routing key built from type and event.
 *
 * This convenience method mirrors the behavior of the Python client that publishes
 * to routing keys of the form "<base>.<type>.<event>" with lowercase type and event.
 * It provides better logging and automatic routing key generation.
 *
 * @param type The message type (e.g., "SUCCESS", "ERROR")
 * @param event The event name (e.g., "aag-ack", "start-msg")
 * @param message The JSON message payload to publish
 * @return true if message was published successfully, false otherwise
 */
bool PPMReporter::PublishPPM(const std::string& type, const std::string& event, const std::string& message) {
    if (!connected_) {
        LOG_ERROR("[PPMReporter] Not connected - cannot publish PPM message");
        return false;
    }

    std::string dynamic_routing_key = BuildDynamicRoutingKey(type, event);

    // Log header and payload with enhanced formatting
    LOG_INFO("╔════════════════════════════════════════════════════════════════╗");
    LOG_INFO("║ PPM  + type + " " + event                                         ║");
    LOG_INFO("║ Exchange:  + config_.exchange                                  ║");
    LOG_INFO("║ Routing Key:  + dynamic_routing_key                            ║");
    LOG_INFO("╚════════════════════════════════════════════════════════════════╝");
    
    // Pretty print JSON if possible
    try {
        nlohmann::json json_msg = nlohmann::json::parse(message);
        LOG_INFO(json_msg.dump(2));
    } catch (const nlohmann::json::exception& e) {
        // Fallback to raw message if JSON parsing fails
        LOG_INFO(message);
    }
    
    LOG_INFO("-------------------------------------------------------");

    amqp_bytes_t body;
    body.len = message.size();
    body.bytes = const_cast<char*>(message.data());

    const auto& amqp_config = ConfigManager::GetInstance().GetAmqp();
    int status = amqp_basic_publish(conn_, amqp_config.channel_id,
                                    amqp_cstring_bytes(config_.exchange.c_str()),
                                    amqp_cstring_bytes(dynamic_routing_key.c_str()),
                                    amqp_config.publish_flags, amqp_config.publish_flags, nullptr, body);

    if (status != AMQP_STATUS_OK) {
        LOG_ERROR("[PPMReporter] Publish failed: " + std::string(amqp_error_string2(status)));
        return false;
    }

    LOG_INFO("[PPMReporter] ✓ PPM message published successfully");
    return true;
}

/**
 * @brief Cleanly disconnects and destroys the AMQP connection.
 *
 * This method ensures a proper shutdown of the connection by closing the
 * channel and the main connection object before freeing the resources.
 */
void PPMReporter::Disconnect() {
    if (connected_) {
        amqp_channel_close(conn_, 1, AMQP_REPLY_SUCCESS);
        amqp_connection_close(conn_, AMQP_REPLY_SUCCESS);
        amqp_destroy_connection(conn_);
        connected_ = false;
        LOG_INFO("[PPMReporter] Disconnected");
    }
}

/**
 * @brief Initializes the reporter by calling the `Connect()` method.
 *
 * @return `true` if the initialization is successful, `false` otherwise.
 */
bool PPMReporter::Init() {
    return Connect();
}

/**
 * @brief De-initializes the reporter by calling the `Disconnect()` method.
 */
void PPMReporter::Deinit() {
    Disconnect();
}
