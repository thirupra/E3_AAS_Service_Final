#!/usr/bin/env python3
"""
TC_117 - Partial Test: PDCC Version Compatibility (Non-TLS)

This version tests only the version compatibility aspect of TC_117
since TLS is not currently configured in the system.
"""

import pika
import json
import time
import uuid
from datetime import datetime, timezone, timedelta

class TC117VersionOnlyTest:
    def __init__(self):
        self.connection = None
        self.channel = None
        
    def setup_connection(self):
        """Setup regular connection to RabbitMQ"""
        try:
            self.connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
            self.channel = self.connection.channel()
            print("✅ Connected to RabbitMQ (Non-TLS)")
            return True
        except Exception as e:
            print(f"❌ Connection failed: {e}")
            return False

    def create_pdcc_message(self, version, test_id):
        """Create PDCC message with specified version"""
        now = datetime.now(timezone.utc)
        valid_until = now + timedelta(seconds=300)
        requested_output_time = now + timedelta(seconds=60)

        return {
            "msg-meta": {
                "id": str(uuid.uuid4()),
                "created": now.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z",
                "type": "PDCC",
                "version": version  # Variable version
            },
            "physicalDeviceCommands": [
                {
                    "pdevCommand": {
                        "cmd-meta": {
                            "deviceCommandId": f"TC117-PARTIAL-V{version}-{test_id}",
                            "command": "ANNOUT",
                            "channelAddress": "CH:1-1",
                            "validUntil": valid_until.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z",
                            "requestedOutputTime": requested_output_time.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z",
                            "sequenceNo": test_id,
                            "announcementId": f"TC117-PARTIAL-V{version}-{test_id}",
                            "announcementHash": f"hash_v{version}_{test_id}",
                            "priority": 5,
                            "announcementProfile": {
                                "text": f"TC117 Version Test - v{version} - ID {test_id}",
                                "language": "en"
                            }
                        },
                        "cmd-content": {
                            "content-type": "text/x-url",
                            "content-transfer-encoding": "",
                            "content": "https://freetestdata.com/wp-content/uploads/2021/09/Free_Test_Data_100KB_OGG.ogg"
                        }
                    }
                }
            ]
        }

    def run_test(self):
        """Run version compatibility test"""
        print("=" * 60)
        print("🧪 TC_117 - Partial Test: PDCC Version Compatibility")
        print("⚠️  Note: TLS testing skipped (not configured)")
        print("=" * 60)
        
        if not self.setup_connection():
            return False

        versions = ["1.4", "1.5", "1.6"]
        test_id = 1170
        
        for version in versions:
            print(f"\n📤 Testing PDCC Version {version}...")
            
            message = self.create_pdcc_message(version, test_id)
            
            try:
                self.channel.basic_publish(
                    exchange='test_exchange1',
                    routing_key='test_routingkey1', 
                    body=json.dumps(message),
                    properties=pika.BasicProperties(content_type='application/json')
                )
                print(f"✅ Version {version} message sent successfully")
                
            except Exception as e:
                print(f"❌ Version {version} failed: {e}")
            
            test_id += 1
            time.sleep(2)
        
        print(f"\n⏳ Waiting for AAS processing...")
        time.sleep(30)
        
        print(f"\n📋 VERIFICATION CHECKLIST:")
        print(f"1. Check AAS logs for message acceptance")
        print(f"2. Verify PPM INFO messages for all versions")
        print(f"3. Verify PPM SUCCESS messages") 
        print(f"4. Confirm no version rejection errors")
        
        print(f"\n🔧 TLS SETUP REQUIRED FOR FULL TC_117:")
        print(f"1. Configure RabbitMQ with TLS on port 5671")
        print(f"2. Add TLS certificates to broker_config.json")
        print(f"3. Re-run full TLS version of test")

        if self.connection:
            self.connection.close()
        
        return True

if __name__ == "__main__":
    test = TC117VersionOnlyTest()
    test.run_test()