#!/usr/bin/env python3
"""
elisa3_sim.py — Minimal ELISA III-IP simulator for AAS

Works with the current ELISA3Manager:
- Receives a size header (mtype=1), then a text payload (mtype=99).
- Parses the ANNOUT request with control-map lines:
    status
    start
    <device_command_id>   # "magic"
    <ablaufid>
    <prio>
    <ziel>
    <start_epoch>
    <stop_epoch>
    0                     # intervall
    0                     # connstatus
    1
    <ablaufid>
    <local_file_path>

- Sends a reply payload (mtype=99) with lines:
    status
    <device_command_id or empty>     # empty => spontaneous TDM status
    <code>                           # integer (2 = success)
    <par1>
    <par2>
    <par3>

Command examples:
  python3 elisa3_sim.py --ftok-dir /path/to/ipc_dir --proj-id 65
  python3 elisa3_sim.py --ftok-dir /path/to/ipc_dir --proj-id 65 --reply-delay 0.2
  python3 elisa3_sim.py --ftok-dir /path/to/ipc_dir --proj-id 65 --no-reply
  python3 elisa3_sim.py --ftok-dir /path/to/ipc_dir --proj-id 65 --tdm-every 5 --tdm-code 501 --tdm-par2 "CH:1-1"
"""

import argparse
import signal
import struct
import sys
import threading
import time
from pathlib import Path

try:
    import sysv_ipc
except ImportError:
    print("This script requires the 'sysv_ipc' package. Install with: pip install sysv_ipc", file=sys.stderr)
    sys.exit(1)

SIZE_MTYPE = 1
PAYLOAD_FROM_AAS = 99  # AAS -> ELISA (ANNOUT payload)
PAYLOAD_TO_AAS   = 199 # ELISA -> AAS (replies/TDM)
MAX_REPLY_LEN = 4000  # keep comfortably under the 4096 C++ buffer


def ensure_token(ftok_path: Path) -> Path:
    # If ftok_path is a directory, use .k file inside it
    # If it's a file path, use it directly
    if ftok_path.is_dir() or (not ftok_path.exists() and not ftok_path.suffix):
        ftok_path.mkdir(parents=True, exist_ok=True)
        token = ftok_path / ".k"
    else:
        # It's a file path - ensure parent directory exists
        ftok_path.parent.mkdir(parents=True, exist_ok=True)
        token = ftok_path
    
    if not token.exists():
        token.write_bytes(b"elisa3_ipc_token")
    return token


def ftok_key(token_path: Path, proj_id: int) -> int:
    # sysv_ipc.ftok requires the file to exist and proj_id (0..255)
    return sysv_ipc.ftok(str(token_path), proj_id & 0xFF)


def build_ack_payload(device_command_id: str, code: int, par2: str = "", par1: str = "", par3: str = "") -> bytes:
    # Exactly 6 lines as the manager expects to parse
    lines = [
        "status",
        device_command_id,      # "magic" (non-empty for ANNOUT reply)
        str(code),
        par1,
        par2,
        par3,
    ]
    text = "\n".join(lines)
    if len(text) > MAX_REPLY_LEN:
        text = text[:MAX_REPLY_LEN]
    return text.encode("utf-8", errors="ignore")


def build_tdm_status_payload(code: int, par2: str = "", par1: str = "", par3: str = "") -> bytes:
    # magic empty => spontaneous TDM status
    lines = [
        "status",
        "",                      # empty magic
        str(code),
        par1,
        par2,
        par3,
    ]
    text = "\n".join(lines)
    if len(text) > MAX_REPLY_LEN:
        text = text[:MAX_REPLY_LEN]
    return text.encode("utf-8", errors="ignore")


def parse_annout_payload(text: str) -> dict:
    """
    Extracts key fields from the incoming ANNOUT request.
    Returns dict with at least 'device_command_id' (may be empty if malformed).
    """
    # Defensive split: keep even empty trailing lines predictable
    lines = text.splitlines()
    # Expect at least 10 lines before the content section
    d = {
        "status0": lines[0] if len(lines) > 0 else "",
        "command1": lines[1] if len(lines) > 1 else "",
        "device_command_id": lines[2] if len(lines) > 2 else "",
        "ablaufid": lines[3] if len(lines) > 3 else "",
        "prio": lines[4] if len(lines) > 4 else "",
        "ziel": lines[5] if len(lines) > 5 else "",
        "start_epoch": lines[6] if len(lines) > 6 else "",
        "stop_epoch": lines[7] if len(lines) > 7 else "",
    }
    return d


def tdm_spammer(mq: sysv_ipc.MessageQueue, interval_sec: float, code: int, par2: str, stop_ev: threading.Event):
    while not stop_ev.is_set():
        time.sleep(interval_sec)
        try:
            payload = build_tdm_status_payload(code=code, par2=par2)
            mq.send(payload, type=PAYLOAD_TO_AAS)  # manager listens on 99
            print(f"📡 TDM Status: code={code}, par2='{par2}'")
        except sysv_ipc.BusyError:
            pass
        except Exception as e:
            print(f"❌ TDM send error: {e}", file=sys.stderr)


def main():
    ap = argparse.ArgumentParser(description="ELISA III-IP Simulator for AAS")
    ap.add_argument("--ftok-dir", required=True,
                    help="Directory or file path for SysV IPC ftok token (same as cfg_.ipc_ftok_path)")
    ap.add_argument("--proj-id", type=int, default=65,
                    help="ftok project id (same as cfg_.ipc_proj_id), 0..255 (default: 65)")

    ap.add_argument("--reply-code", type=int, default=2, help="ACK code to send (2=success)")
    ap.add_argument("--reply-delay", type=float, default=0.0, help="Delay before sending ACK (sec)")
    ap.add_argument("--no-reply", action="store_true", help="Do not send any reply (simulate timeout)")
    ap.add_argument("--fail-ids", nargs="*", default=[],
                    help="List of device_command_id values for which to send non-zero code")

    ap.add_argument("--tdm-every", type=float, default=0.0,
                    help="If >0, send spontaneous TDM status every N seconds (magic empty)")
    ap.add_argument("--tdm-code", type=int, default=500, help="Spontaneous TDM status code")
    ap.add_argument("--tdm-par2", type=str, default="", help="Spontaneous TDM status par2 (e.g., channel)")

    args = ap.parse_args()
    print(f"[DEBUG] Starting ELISA3 simulator...")
    print(f"[DEBUG] ftok-dir argument: {args.ftok_dir}")
    
    ftok_dir = Path(args.ftok_dir)
    token = ensure_token(ftok_dir)
    key = ftok_key(token, args.proj_id)
    
    print(f"[DEBUG] Token file: {token}")
    print(f"[DEBUG] IPC Key: 0x{key:08x} ({key})")
    
    try:
        mq = sysv_ipc.MessageQueue(key, sysv_ipc.IPC_CREAT, mode=0o666)
        print(f"[DEBUG] Message queue created/opened successfully")
    except Exception as e:
        print(f"[ERROR] Failed to create/open message queue: {e}")
        sys.exit(1)

    # Optional TDM spontaneous status thread
    stop_ev = threading.Event()
    spam_thread = None
    if args.tdm_every and args.tdm_every > 0:
        spam_thread = threading.Thread(
            target=tdm_spammer, args=(mq, args.tdm_every, args.tdm_code, args.tdm_par2, stop_ev), daemon=True
        )
        spam_thread.start()
        print(f"📡 TDM status enabled: every {args.tdm_every}s, code={args.tdm_code}, par2='{args.tdm_par2}'")

    def on_sigint(signum, frame):
        stop_ev.set()
        print("\n🛑 ELISA3 Simulator stopping…")
        sys.exit(0)

    signal.signal(signal.SIGINT, on_sigint)

    print(f"🎤 ELISA3 Simulator Ready")
    print(f"   IPC Key: 0x{key:08x} ({key}), SIZE type: {SIZE_MTYPE}, PAYLOAD type: {PAYLOAD_FROM_AAS}")
    print(f"   Token file: {token}")
    print("📡 Waiting for announcement requests… (Ctrl+C to quit)")

    while True:
        # Drain size header (type=1) — we don't strictly need the number, so just discard.
        try:
            size_bytes, mtype = mq.receive(type=SIZE_MTYPE)  # blocking
            # Optional: decode size if you want to validate
            # Most Linux builds use 8-byte unsigned long; be tolerant if not.
            # We ignore it because AAS already ensures coherence.
        except Exception as e:
            print(f"❌ Error receiving SIZE header: {e}", file=sys.stderr)
            continue

        # Receive payload (type=99)
        try:
            payload_bytes, mtype = mq.receive(type=PAYLOAD_FROM_AAS)  # blocking
        except Exception as e:
            print(f"❌ Error receiving PAYLOAD: {e}", file=sys.stderr)
            continue

        try:
            text = payload_bytes.decode("utf-8", errors="ignore")
        except Exception:
            text = str(payload_bytes)

        req = parse_annout_payload(text)
        dev_cmd_id = req.get("device_command_id", "")
        print(f"📢 ANNOUNCEMENT REQUEST RECEIVED")
        print(f"   Command ID: {dev_cmd_id}")
        print(f"   Target: {req.get('ziel','')}")
        print(f"   Priority: {req.get('prio','')}")

        # Optionally delay or suppress reply (simulate timeout)
        if args.no_reply:
            print("⏰ No reply mode: simulating timeout scenario")
            continue

        if args.reply_delay > 0:
            time.sleep(args.reply_delay)

        # Choose reply code
        code = args.reply_code  # Use the command-line argument
        if dev_cmd_id and dev_cmd_id in args.fail_ids:
            # Use specific error codes for different failure types
            if "E_NO_DEVICE" in dev_cmd_id:
                code = 11  # E_NO_DEVICE
            elif "E_NO_LINE" in dev_cmd_id:
                code = 15  # E_NO_LINE
            elif "E_DEST_DEF" in dev_cmd_id:
                code = 21  # E_DEST_DEF
            elif "E_DEST_OCC" in dev_cmd_id:
                code = 22  # E_DEST_OCC
            else:
                code = 500  # E_UNKNOWN

        # Build and send the reply (type=99)
        reply = build_ack_payload(device_command_id=dev_cmd_id, code=code, par2=req.get("ziel", ""))
        try:
            mq.send(reply, type=PAYLOAD_TO_AAS)
            print(f"✅ ANNOUNCEMENT ACKNOWLEDGED")
            print(f"   Command ID: {dev_cmd_id}")
            print(f"   Response Code: {code}")
            print(f"   Target: {req.get('ziel','')}")
        except Exception as e:
            print(f"❌ Error sending ACK: {e}", file=sys.stderr)


if __name__ == "__main__":
    main()
