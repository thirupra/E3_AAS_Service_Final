#!/usr/bin/env python3
"""
Custom PDCC sender script with specific parameters for testing.
"""

import json
import time
import uuid
import argparse
from datetime import datetime, timedelta
import pika

class PDCCSender:
    def __init__(self, host="localhost", port=5672, username="guest", password="guest", 
                 exchange="test_exchange1", routing_key="test_routingkey1"):
        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.exchange = exchange
        self.routing_key = routing_key
        self.connection = None
        self.channel = None

    def connect(self):
        try:
            credentials = pika.PlainCredentials(self.username, self.password)
            self.connection = pika.BlockingConnection(
                pika.ConnectionParameters(host=self.host, port=self.port, credentials=credentials)
            )
            self.channel = self.connection.channel()
            return True
        except Exception as e:
            print(f"❌ Failed to connect: {e}")
            return False

    def create_annout_message(self, channel, priority, due_offset_seconds, valid_offset_seconds, 
                             text, url, announcement_id=None, error_type=None):
        if not announcement_id:
            announcement_id = str(uuid.uuid4())
        
        device_command_id = str(uuid.uuid4())
        if error_type:
            device_command_id = f"{error_type}_{device_command_id}"
        now = datetime.utcnow()
        valid_until = now + timedelta(seconds=valid_offset_seconds)
        requested_output_time = now + timedelta(seconds=due_offset_seconds)

        message = {
            "msg-meta": {
                "id": str(uuid.uuid4()),
                "created": now.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "000",
                "type": "PDCC",
                "version": "1.5",
                "@": "further attributes may follow here"
            },
            "physicalDeviceCommands": [
                {
                    "pdevCommand": {
                        "cmd-meta": {
                            "deviceCommandId": device_command_id,
                            "priority": priority,
                            "command": "ANNOUT",
                            "channelAddress": channel,
                            "validUntil": valid_until.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "000Z",
                            "requestedOutputTime": requested_output_time.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "000Z",
                            "sequenceNo": int(time.time() * 1000) % 10000000,
                            "announcementId": announcement_id,
                            "announcementHash": "8f4285c72ee645695d17f93ed0328784d04fa27d",
                            "announcementProfile": {
                                "text": text,
                                "language": "en"
                            }
                        },
                        "cmd-content": {
                            "content-type": "text/x-url",
                            "content-transfer-encoding": "",
                            "content": url
                        }
                    }
                }
            ]
        }
        return message

    def create_multiple_commands_message(self, commands):
        """
        Create a PDCC message with multiple commands.
        commands: list of dicts with command details
        """
        now = datetime.utcnow()
        
        physical_device_commands = []
        for cmd in commands:
            if cmd['type'] == 'ANNOUT':
                device_command_id = str(uuid.uuid4())
                if cmd.get('error_type'):
                    device_command_id = f"{cmd['error_type']}_{device_command_id}"
                
                valid_until = now + timedelta(seconds=cmd['valid_offset_seconds'])
                requested_output_time = now + timedelta(seconds=cmd['due_offset_seconds'])
                
                physical_device_commands.append({
                    "pdevCommand": {
                        "cmd-meta": {
                            "deviceCommandId": device_command_id,
                            "priority": cmd['priority'],
                            "command": "ANNOUT",
                            "channelAddress": cmd['channel'],
                            "validUntil": valid_until.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "000Z",
                            "requestedOutputTime": requested_output_time.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "000Z",
                            "sequenceNo": int(time.time() * 1000) % 10000000,
                            "announcementId": cmd.get('announcement_id', str(uuid.uuid4())),
                            "announcementHash": "8f4285c72ee645695d17f93ed0328784d04fa27d",
                            "announcementProfile": {
                                "text": cmd['text'],
                                "language": "en"
                            }
                        },
                        "cmd-content": {
                            "content-type": "text/x-url",
                            "content-transfer-encoding": "",
                            "content": cmd['url']
                        }
                    }
                })
            elif cmd['type'] == 'ANNDEL':
                device_command_id = str(uuid.uuid4())
                valid_until = now + timedelta(seconds=300)
                
                physical_device_commands.append({
                    "pdevCommand": {
                        "cmd-meta": {
                            "deviceCommandId": device_command_id,
                            "priority": 0,
                            "command": "ANNDEL",
                            "channelAddress": "",
                            "validUntil": valid_until.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "000Z",
                            "requestedOutputTime": now.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "000Z",
                            "sequenceNo": int(time.time() * 1000) % 10000000,
                            "announcementId": cmd['announcement_id'],
                            "announcementHash": "",
                            "announcementProfile": {
                                "text": "",
                                "language": "en"
                            }
                        },
                        "cmd-content": {
                            "content-type": "text/plain",
                            "content-transfer-encoding": "",
                            "content": ""
                        }
                    }
                })

        message = {
            "msg-meta": {
                "id": str(uuid.uuid4()),
                "created": now.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "000",
                "type": "PDCC",
                "version": "1.5",
                "@": "further attributes may follow here"
            },
            "physicalDeviceCommands": physical_device_commands
        }
        return message

    def create_anndel_message(self, announcement_id):
        device_command_id = str(uuid.uuid4())
        now = datetime.utcnow()

        message = {
            "msg-meta": {
                "id": str(uuid.uuid4()),
                "created": now.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "000",
                "type": "PDCC",
                "version": "1.5",
                "@": "further attributes may follow here"
            },
            "physicalDeviceCommands": [
                {
                    "pdevCommand": {
                        "cmd-meta": {
                            "deviceCommandId": device_command_id,
                            "priority": 0,
                            "command": "ANNDEL",
                            "channelAddress": "",
                            "validUntil": (now + timedelta(seconds=300)).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "000Z",
                            "requestedOutputTime": now.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "000Z",
                            "sequenceNo": int(time.time() * 1000) % 10000000,
                            "announcementId": announcement_id,
                            "announcementHash": "",
                            "announcementProfile": {
                                "text": "",
                                "language": "en"
                            }
                        },
                        "cmd-content": {
                            "content-type": "text/plain",
                            "content-transfer-encoding": "",
                            "content": ""
                        }
                    }
                }
            ]
        }
        return message

    def create_keepalive_message(self):
        """
        Create a keep-alive message with empty physicalDeviceCommands array.
        This will trigger the keep-alive detection logic in AMQPHandler.
        """
        now = datetime.utcnow()
        
        message = {
            "msg-meta": {
                "id": str(uuid.uuid4()),
                "created": now.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "000",
                "type": "PDCC",
                "version": "1.5",
                "@": "further attributes may follow here"
            },
            "physicalDeviceCommands": []  # Empty array - this is the key for keep-alive detection!
        }
        return message

    def send_message(self, message):
        try:
            self.channel.basic_publish(
                exchange=self.exchange,
                routing_key=self.routing_key,
                body=json.dumps(message),
                properties=pika.BasicProperties(
                    content_type="application/json",
                    delivery_mode=2  # Make message persistent
                )
            )
            return True
        except Exception as e:
            print(f"❌ Failed to send message: {e}")
            return False

    def disconnect(self):
        if self.connection and not self.connection.is_closed:
            self.connection.close()

def main():
    parser = argparse.ArgumentParser(description="Send PDCC ANNOUT/ANNDEL/KEEPALIVE messages with specific parameters")
    parser.add_argument("--user", default="guest", help="RabbitMQ username")
    parser.add_argument("--password", default="guest", help="RabbitMQ password")
    parser.add_argument("command", choices=["annout", "anndel", "multiple", "keepalive"], help="Command type")
    
    # ANNOUT specific arguments
    parser.add_argument("--ch", help="Channel address (required for ANNOUT)")
    parser.add_argument("--prio", type=int, help="Priority (required for ANNOUT)")
    parser.add_argument("--due", help="Due time offset (e.g., +5s, +8s) (required for ANNOUT)")
    parser.add_argument("--valid", help="Valid until offset (e.g., +120s) (required for ANNOUT)")
    parser.add_argument("--text", help="Announcement text (required for ANNOUT)")
    parser.add_argument("--url", help="Content URL (required for ANNOUT)")
    parser.add_argument("--error-type", help="Error type for testing (E_NO_DEVICE, E_NO_LINE, E_DEST_DEF, E_DEST_OCC, E_UNKNOWN)")
    
    # ANNDEL specific arguments
    parser.add_argument("--annid", help="Announcement ID to delete (required for ANNDEL)")
    
    # KEEPALIVE specific arguments
    parser.add_argument("--count", type=int, default=1, help="Number of keep-alive messages to send (default: 1)")
    parser.add_argument("--interval", type=int, default=10, help="Interval between keep-alive messages in seconds (default: 10)")
    
    args = parser.parse_args()
    
    sender = PDCCSender(username=args.user, password=args.password)
    if not sender.connect():
        return 1

    if args.command == "annout":
        # Validate ANNOUT arguments
        if not all([args.ch, args.prio is not None, args.due, args.valid, args.text, args.url]):
            print("❌ ANNOUT command requires --ch, --prio, --due, --valid, --text, --url")
            return 1
            
        # Parse due time offset
        due_offset = int(args.due.replace('+', '').replace('s', ''))
        valid_offset = int(args.valid.replace('+', '').replace('s', ''))
        
        print(f"📤 Sending ANNOUT command:")
        print(f"   Channel: {args.ch}")
        print(f"   Priority: {args.prio}")
        print(f"   Due in: {due_offset} seconds")
        print(f"   Valid for: {valid_offset} seconds")
        print(f"   Text: {args.text}")
        print(f"   URL: {args.url}")
        
        message = sender.create_annout_message(
            channel=args.ch,
            priority=args.prio,
            due_offset_seconds=due_offset,
            valid_offset_seconds=valid_offset,
            text=args.text,
            url=args.url,
            error_type=args.error_type
        )
        
        if sender.send_message(message):
            print("✅ ANNOUT message sent successfully")
            print(f"   Announcement ID: {message['physicalDeviceCommands'][0]['pdevCommand']['cmd-meta']['announcementId']}")
            print(f"   Due time: {message['physicalDeviceCommands'][0]['pdevCommand']['cmd-meta']['requestedOutputTime']}")
        else:
            print("❌ Failed to send ANNOUT message")
            sender.disconnect()
            return 1
            
    elif args.command == "anndel":
        # Validate ANNDEL arguments
        if not args.annid:
            print("❌ ANNDEL command requires --annid")
            return 1
            
        print(f"🗑️  Sending ANNDEL command:")
        print(f"   Announcement ID: {args.annid}")
        
        message = sender.create_anndel_message(args.annid)
        
        if sender.send_message(message):
            print("✅ ANNDEL message sent successfully")
            print(f"   Announcement ID: {message['physicalDeviceCommands'][0]['pdevCommand']['cmd-meta']['announcementId']}")
        else:
            print("❌ Failed to send ANNDEL message")
            sender.disconnect()
            return 1
                   
    elif args.command == "multiple":
        print(f"📦 Sending MULTIPLE commands in one PDCC message:")
        
        # Create multiple commands for testing
        commands = [
            {
                'type': 'ANNOUT',
                'channel': '871982313',
                'priority': 3,
                'due_offset_seconds': 5,
                'valid_offset_seconds': 90,
                'text': 'First announcement in batch',
                'url': 'https://files.example/first_batch.mp3'
            },
            {
                'type': 'ANNOUT',
                'channel': '871982314',
                'priority': 4,
                'due_offset_seconds': 8,
                'valid_offset_seconds': 90,
                'text': 'Second announcement in batch',
                'url': 'https://files.example/second_batch.mp3'
            },
            {
                'type': 'ANNOUT',
                'channel': '871982315',
                'priority': 2,
                'due_offset_seconds': 12,
                'valid_offset_seconds': 90,
                'text': 'Third announcement in batch',
                'url': 'https://files.example/third_batch.mp3'
            }
        ]
        
        print(f"   Total commands: {len(commands)}")
        for i, cmd in enumerate(commands, 1):
            print(f"   Command {i}: {cmd['type']} on channel {cmd['channel']} (priority {cmd['priority']})")
        
        message = sender.create_multiple_commands_message(commands)
        
        if sender.send_message(message):
            print("✅ Multiple commands message sent successfully")
            print(f"   Message contains {len(commands)} commands")
        else:
            print("❌ Failed to send multiple commands message")
            sender.disconnect()
            return 1

    elif args.command == "keepalive":
        print(f"💓 Sending KEEP-ALIVE message(s):")
        print(f"   Count: {args.count}")
        if args.count > 1:
            print(f"   Interval: {args.interval} seconds")
        print(f"   Empty physicalDeviceCommands array")
        
        success_count = 0
        for i in range(args.count):
            if i > 0:
                print(f"\n   ⏳ Waiting {args.interval} seconds before next keep-alive...")
                time.sleep(args.interval)
            
            message = sender.create_keepalive_message()
            
            if sender.send_message(message):
                success_count += 1
                if args.count == 1:
                    print("✅ Keep-alive message sent successfully")
                    print(f"   Message ID: {message['msg-meta']['id']}")
                    print(f"   Commands count: {len(message['physicalDeviceCommands'])}")
                    print(f"   Created: {message['msg-meta']['created']}")
                else:
                    print(f"✅ Keep-alive {i+1}/{args.count} sent successfully (ID: {message['msg-meta']['id']})")
            else:
                print(f"❌ Failed to send keep-alive {i+1}/{args.count}")
        
        if args.count > 1:
            print(f"\n📊 Keep-alive summary: {success_count}/{args.count} messages sent successfully")
        
        if success_count == 0:
            sender.disconnect()
            return 1

    sender.disconnect()
    return 0

if __name__ == "__main__":
    exit(main())