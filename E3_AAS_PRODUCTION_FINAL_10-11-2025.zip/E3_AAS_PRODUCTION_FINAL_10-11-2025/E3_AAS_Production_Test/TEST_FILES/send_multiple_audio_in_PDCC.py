#!/usr/bin/env python3
# filepath: /home/csg/Videos/E3-aas_testing_cod3_27-10-25/E3-aas_testing_cod3_23-10-25/e3-aas/pdcc_send_annout_single.py
import pika
import json
import time
import uuid
import hashlib
from datetime import datetime, timezone, timedelta
 
# Connect to RabbitMQ
connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
channel = connection.channel()
 
now = datetime.now(timezone.utc)
valid_until = now + timedelta(seconds=120)
requested_output_time = now + timedelta(seconds=30)

# Define multiple audio files with unique hashes
audio_files = [
    {
        "url": "https://freetestdata.com/wp-content/uploads/2021/09/Free_Test_Data_100KB_OGG.ogg",
        "text": "Test announcement 1",
        "channel": "CH-01-1",
        "command_id": "TEST-DeviceCommandId-008",
        "announcement_id": "TEST-ANNOUTID-008",
        "sequence_no": 100008
    },
    {
        "url": "https://getsamplefiles.com/download/ogg/sample-4.ogg",
        "text": "Test announcement 2", 
        "channel": "CH-01-2",
        "command_id": "TEST-DeviceCommandId-009",
        "announcement_id": "TEST-ANNOUTID-009",
        "sequence_no": 100009
    },
    {
        "url": "https://getsamplefiles.com/download/ogg/sample-1.ogg",
        "text": "Test announcement 3",
        "channel": "CH-01-3", 
        "command_id": "TEST-DeviceCommandId-010",
        "announcement_id": "TEST-ANNOUTID-010",
        "sequence_no": 100010
    }
]

# Function to generate unique hash for each URL
def generate_hash_for_url(url):
    return hashlib.md5(url.encode()).hexdigest()

# Create multiple pdevCommand objects
physical_device_commands = []

for i, audio_file in enumerate(audio_files):
    # Generate unique hash for each audio file URL
    unique_hash = generate_hash_for_url(audio_file["url"])
    
    # Different output times: 30s, 35s, 40s apart
    individual_output_time = now + timedelta(seconds=30 + (i * 5))
    
    pdev_command = {
        "pdevCommand": {
            "cmd-meta": {
                "deviceCommandId": audio_file["command_id"],
                "priority": 7,
                "command": "ANNOUT",
                "channelAddress": audio_file["channel"],
                "validUntil": valid_until.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "000Z",
                "requestedOutputTime": individual_output_time.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "000Z",
                "sequenceNo": audio_file["sequence_no"],
                "announcementId": audio_file["announcement_id"],
                "announcementHash": unique_hash,  # Use unique hash for each file
                "announcementProfile": {
                    "text": audio_file["text"],
                    "language": "en"
                }
            },
            "cmd-content": {
                "content-type": "text/x-url",
                "content-transfer-encoding": "",
                "content": audio_file["url"]
            }
        }
    }
    physical_device_commands.append(pdev_command)

# 1. Send ANNOUT message (with multiple audio files)
annout_message = {
    "msg-meta": {
        "id": str(uuid.uuid4()),
        "created": now.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "000Z",
        "type": "PDCC",
        "version": "1.5"
    },
    "physicalDeviceCommands": physical_device_commands
}
 
print(f"Sending ANNOUT message with {len(audio_files)} audio files...")
channel.basic_publish(
    exchange='test_exchange1',
    routing_key='test_routingkey1',
    body=json.dumps(annout_message),
    properties=pika.BasicProperties(content_type='application/json')
)
print("✅ ANNOUT message sent!")
 
# Wait a moment to ensure ANNOUT is processed
time.sleep(5)
 
connection.close()