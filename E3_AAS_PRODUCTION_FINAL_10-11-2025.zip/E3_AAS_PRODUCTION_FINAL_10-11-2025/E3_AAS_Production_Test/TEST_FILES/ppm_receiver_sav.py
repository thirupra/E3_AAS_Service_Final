#!/usr/bin/env python3
"""
PPM Message Receiver for AAS Service Testing
"""
 
import json
import time
import pika
import sys
import argparse
from datetime import datetime, timezone
 
class PPMReceiver:
    def __init__(self, host='localhost', port=5672, username='guest', password='guest',
                 virtual_host='/', exchange='test_exchange2', routing_key='test_routingkey2.*.*'):
        """Initialize the PPM receiver with RabbitMQ connection parameters."""
        self.connection_params = pika.ConnectionParameters(
            host=host,
            port=port,
            virtual_host=virtual_host,
            credentials=pika.PlainCredentials(username, password)
        )
        self.exchange = exchange
        self.routing_key = routing_key
        self.connection = None
        self.channel = None
        self.message_count = 0
        self.queue_name = "test_queue2"
 
    def connect(self):
        """Establish connection to RabbitMQ broker."""
        try:
            print(f"[INFO] Connecting to RabbitMQ at {self.connection_params.host}:{self.connection_params.port}")
            self.connection = pika.BlockingConnection(self.connection_params)
            self.channel = self.connection.channel()
            
            # Declare the exchange - create if it doesn't exist
            print(f"[INFO] Declaring exchange: {self.exchange}")
            self.channel.exchange_declare(exchange=self.exchange, exchange_type='direct', durable=True)
            
            # Create a temporary queue with auto-generated name for better isolation
            result = self.channel.queue_declare(queue='', exclusive=True)
            queue_name = result.method.queue
            self.queue_name = queue_name
            print(f"[INFO] Created temporary queue: {queue_name}")
            
            # Bind to catch all PPM message types
            ppm_routing_keys = [
                'test_routingkey2.info.pdc-received',
                'test_routingkey2.success.aag-ack',
                'test_routingkey2.error.aag-nack'
            ]
            
            for routing_key in ppm_routing_keys:
                self.channel.queue_bind(
                    exchange=self.exchange,
                    queue=self.queue_name,
                    routing_key=routing_key
                )
                print(f"[INFO] ✓ Bound to routing key: {routing_key}")
            
            print(f"[SUCCESS] Connected to RabbitMQ broker")
            print(f"[INFO] Listening for PPM messages on exchange '{self.exchange}'")
            return True
            
        except Exception as e:
            print(f"[ERROR] Failed to connect to RabbitMQ: {e}")
            return False
 
    def format_due_time(self, iso_timestamp):
        """Convert ISO timestamp to human-readable format with time until due."""
        try:
            # Parse the ISO timestamp
            if iso_timestamp.endswith('Z'):
                # Remove Z and parse as UTC
                iso_timestamp = iso_timestamp[:-1] + '+00:00'
            
            due_time = datetime.fromisoformat(iso_timestamp)
            now = datetime.now(timezone.utc)
            
            # Calculate time difference
            time_diff = due_time - now
            
            if time_diff.total_seconds() > 0:
                # Future time
                hours, remainder = divmod(int(time_diff.total_seconds()), 3600)
                minutes, seconds = divmod(remainder, 60)
                
                if hours > 0:
                    time_str = f"{hours}h {minutes}m {seconds}s"
                elif minutes > 0:
                    time_str = f"{minutes}m {seconds}s"
                else:
                    time_str = f"{seconds}s"
                
                return f"{due_time.strftime('%Y-%m-%d %H:%M:%S UTC')} (in {time_str})"
            else:
                # Past time
                time_diff = now - due_time
                hours, remainder = divmod(int(time_diff.total_seconds()), 3600)
                minutes, seconds = divmod(remainder, 60)
                
                if hours > 0:
                    time_str = f"{hours}h {minutes}m {seconds}s"
                elif minutes > 0:
                    time_str = f"{minutes}m {seconds}s"
                else:
                    time_str = f"{seconds}s"
                
                return f"{due_time.strftime('%Y-%m-%d %H:%M:%S UTC')} ({time_str} ago)"
                
        except Exception as e:
            return f"{iso_timestamp} (parse error: {e})"
 
    def disconnect(self):
        """Close the RabbitMQ connection."""
        if self.connection and not self.connection.is_closed:
            self.connection.close()
            print("[INFO] Disconnected from RabbitMQ")
 
    def process_message(self, ch, method, properties, body):
        """Process received PPM messages."""
        try:
            self.message_count += 1
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            
            # Parse the JSON message
            message = json.loads(body.decode('utf-8'))
            
            # Extract due time for banner display
            due_time_display = ""
            if 'metaData' in message and 'requestedOutputTime' in message['metaData']:
                due_time_iso = message['metaData']['requestedOutputTime']
                due_time_display = f" | Due: {self.format_due_time(due_time_iso)}"
            
            print(f"\n{'='*60}")
            print(f"📡 PPM MESSAGE #{self.message_count} - {timestamp}{due_time_display}")
            print(f"{'='*60}")
            
            # Pretty print the message
            print(json.dumps(message, indent=2))
            
            # Extract key information
            if 'event' in message:
                event = message['event']
                print(f"\n📊 ANALYSIS: Event Type: {event}")
                
                if event == 'pdc-received':
                    print("✅ AAS service acknowledged receipt of PDCC message")
                elif event == 'aag-ack':
                    print("✅ AAS service successfully processed the command")
                elif event == 'aag-nack':
                    print("❌ AAS service failed to process the command")
                    if 'detail' in message:
                        print(f"🔍 Error detail: {message['detail']}")
            
            if 'metaData' in message and 'deviceCommandId' in message['metaData']:
                device_cmd_id = message['metaData']['deviceCommandId']
                print(f"🔧 Device Command ID: {device_cmd_id}")
            
            if 'metaData' in message and 'announcementId' in message['metaData']:
                ann_id = message['metaData']['announcementId']
                print(f"📢 Announcement ID: {ann_id}")
            
            if 'metaData' in message and 'requestedOutputTime' in message['metaData']:
                due_time_iso = message['metaData']['requestedOutputTime']
                due_time_formatted = self.format_due_time(due_time_iso)
                print(f"⏰ Due Time: {due_time_formatted}")
            
            print(f"{'='*60}")
            
        except json.JSONDecodeError as e:
            print(f"❌ Failed to parse JSON message: {e}")
            print(f"📄 Raw message: {body.decode('utf-8')}")
        except Exception as e:
            print(f"❌ Error processing message: {e}")
 
    def start_listening(self, timeout=None):
        """Start listening for PPM messages."""
        try:
            # Set up consumer
            self.channel.basic_consume(
                queue=self.queue_name,
                on_message_callback=self.process_message,
                auto_ack=True
            )
            
            print(f"[INFO] Starting to listen for PPM messages...")
            print(f"[INFO] Press Ctrl+C to stop")
            
            if timeout:
                print(f"[INFO] Will timeout after {timeout} seconds")
                start_time = time.time()
                while time.time() - start_time < timeout:
                    self.connection.process_data_events(time_limit=1)
            else:
                # Start consuming messages
                self.channel.start_consuming()
                
        except KeyboardInterrupt:
            print("\n[INFO] Stopped by user")
        except Exception as e:
            print(f"[ERROR] Error while listening: {e}")
        finally:
            if self.channel:
                self.channel.stop_consuming()
 
def main():
    parser = argparse.ArgumentParser(description='PPM Message Receiver for AAS Service Testing')
    parser.add_argument('--host', default='localhost', help='RabbitMQ host (default: localhost)')
    parser.add_argument('--port', type=int, default=5672, help='RabbitMQ port (default: 5672)')
    parser.add_argument('--username', default='guest', help='RabbitMQ username (default: guest)')
    parser.add_argument('--password', default='guest', help='RabbitMQ password (default: guest)')
    parser.add_argument('--exchange', default='test_exchange2', help='Exchange name (default: test_exchange2)')
    parser.add_argument('--timeout', type=int, help='Timeout in seconds (default: no timeout)')
    
    args = parser.parse_args()
    
    # Create PPM receiver - routing key not needed since we bind to specific keys
    receiver = PPMReceiver(
        host=args.host,
        port=args.port,
        username=args.username,
        password=args.password,
        exchange=args.exchange
    )
    
    # Connect to broker
    if not receiver.connect():
        sys.exit(1)
    
    try:
        receiver.start_listening(timeout=args.timeout)
    except Exception as e:
        print(f"[ERROR] Unexpected error: {e}")
    finally:
        receiver.disconnect()
 
if __name__ == "__main__":
    main()
 
 