#!/usr/bin/env python3
"""
elisa3_status_sender.py — Interactive status message sender for ELISA III-IP simulator
 
Allows sending individual status messages interactively:
1. NO_ERR_DEVICE (code 7)
2. NO_ERR_DEST (code 6) with channel address
3. ERR_DESTDEF (code 21) with channel address
4. ERR_DEVICEDEF (code 30)
 
NEW: Test scenarios for edge cases:
5. Missing magic field (completely omitted)
6. Invalid status code (non-existent code)
7. Malformed message structure
8. Custom message with user input
 
This script works alongside elisa3_sim.py and sends spontaneous status messages
to the same message queue. The main elisa3_sim.py continues to handle regular
PDCC commands and responses normally.
 
Usage:
  python3 elisa3_status_sender.py --ftok-dir /path/to/ipc_dir --proj-id 65
  python3 elisa3_status_sender.py --ftok-dir /path/to/ipc_dir --proj-id 65 --channel "CH:1-1"
"""
 
import argparse
import signal
import sys
import time
from pathlib import Path
 
try:
    import sysv_ipc
except ImportError:
    print("This script requires the 'sysv_ipc' package. Install with: pip install sysv_ipc", file=sys.stderr)
    sys.exit(1)
 
PAYLOAD_TO_AAS = 199  # ELISA -> AAS (status messages)
MAX_REPLY_LEN = 4000
 
# Status message definitions
STATUS_MESSAGES = {
    "1": {"name": "NO_ERR_DEVICE", "code": 7, "par1": "", "par2": "", "par3": ""},
    "2": {"name": "NO_ERR_DEST", "code": 6, "par1": "", "par2": "{channel}", "par3": ""},
    "3": {"name": "ERR_DESTDEF", "code": 21, "par1": "", "par2": "{channel}", "par3": ""},
    "4": {"name": "ERR_DEVICEDEF", "code": 30, "par1": "", "par2": "", "par3": ""},
}
 
# Test scenarios for edge cases
TEST_MESSAGES = {
    "5": {"name": "TEST: Missing Magic Field", "description": "Status message with magic field completely omitted"},
    "6": {"name": "TEST: Invalid Status Code", "description": "Status message with non-existent status code (999)"},
    "7": {"name": "TEST: Malformed Structure", "description": "Status message with wrong number of fields"},
    "8": {"name": "TEST: Custom Message", "description": "Create custom status message with user input"},
}
 
 
def ensure_token(ftok_path: Path) -> Path:
    """Ensure the ftok token file exists."""
    if ftok_path.is_dir() or (not ftok_path.exists() and not ftok_path.suffix):
        ftok_path.mkdir(parents=True, exist_ok=True)
        token = ftok_path / ".k"
    else:
        ftok_path.parent.mkdir(parents=True, exist_ok=True)
        token = ftok_path
    
    if not token.exists():
        token.write_bytes(b"elisa3_ipc_token")
    return token
 
 
def ftok_key(token_path: Path, proj_id: int) -> int:
    """Generate IPC key using ftok."""
    return sysv_ipc.ftok(str(token_path), proj_id & 0xFF)
 
 
def build_status_payload(code: int, par1: str = "", par2: str = "", par3: str = "", magic: str = "") -> bytes:
    """
    Build a spontaneous status message (TDM) payload.
    Magic field is empty by default to indicate spontaneous/unsolicited status.
    """
    lines = [
        "status",
        magic,        # empty magic => spontaneous TDM status
        str(code),
        par1,
        par2,
        par3,
    ]
    text = "\n".join(lines)
    if len(text) > MAX_REPLY_LEN:
        text = text[:MAX_REPLY_LEN]
    return text.encode("utf-8", errors="ignore")
 
 
def build_test_payload(test_type: str, channel: str = "") -> bytes:
    """Build test payloads for edge case testing."""
    
    if test_type == "missing_magic":
        # Completely omit the magic field line
        lines = [
            "status",
            # magic field line completely missing
            "7",  # valid code
            "",   # par1
            channel,  # par2
            "",   # par3
        ]
        text = "\n".join(lines)
        
    elif test_type == "invalid_code":
        # Use an invalid/non-existent status code
        lines = [
            "status",
            "",     # empty magic (spontaneous)
            "999",  # invalid status code
            "",     # par1
            channel,  # par2
            "",     # par3
        ]
        text = "\n".join(lines)
        
    elif test_type == "malformed":
        # Wrong number of fields (missing some fields)
        lines = [
            "status",
            "",     # empty magic
            "7",    # valid code
            # missing par1, par2, par3 fields completely
        ]
        text = "\n".join(lines)
        
    else:
        # Default fallback
        lines = ["status", "", "7", "", channel, ""]
        text = "\n".join(lines)
    
    if len(text) > MAX_REPLY_LEN:
        text = text[:MAX_REPLY_LEN]
    return text.encode("utf-8", errors="ignore")
 
 
def display_menu():
    """Display the interactive menu."""
    print("\n" + "="*70)
    print("ELISA3 Status Message Sender - Interactive Mode")
    print("="*70)
    print("Standard status messages:")
    for key, msg in STATUS_MESSAGES.items():
        print(f"  {key}. {msg['name']} (code {msg['code']})")
    
    print("\nTest scenarios (Edge cases):")
    for key, msg in TEST_MESSAGES.items():
        print(f"  {key}. {msg['name']}")
        print(f"     {msg['description']}")
    
    print("\nOther options:")
    print("  c. Change channel address")
    print("  q. Quit")
    print("="*70)
 
 
def send_single_message(mq: sysv_ipc.MessageQueue, msg_key: str, channel: str):
    """Send a single status message."""
    if msg_key not in STATUS_MESSAGES:
        print(f"❌ Invalid message key: {msg_key}")
        return False
    
    msg = STATUS_MESSAGES[msg_key]
    
    # Replace {channel} placeholder with actual channel address
    par1 = msg["par1"]
    par2 = msg["par2"].replace("{channel}", channel)
    par3 = msg["par3"]
    
    try:
        payload = build_status_payload(
            code=msg["code"],
            par1=par1,
            par2=par2,
            par3=par3
        )
        mq.send(payload, type=PAYLOAD_TO_AAS)
        print(f"✓ Sent {msg['name']}: code={msg['code']}", end="")
        if par2:
            print(f", par2='{par2}'", end="")
        print(f" at {time.strftime('%H:%M:%S')}")
        return True
        
    except sysv_ipc.BusyError:
        print(f"⚠ Queue busy, failed to send {msg['name']}")
        return False
    except Exception as e:
        print(f"❌ Error sending {msg['name']}: {e}")
        return False
 
 
def send_test_message(mq: sysv_ipc.MessageQueue, test_key: str, channel: str):
    """Send a test message for edge case testing."""
    if test_key not in TEST_MESSAGES:
        print(f"❌ Invalid test key: {test_key}")
        return False
    
    test_msg = TEST_MESSAGES[test_key]
    
    try:
        if test_key == "5":  # Missing magic field
            payload = build_test_payload("missing_magic", channel)
            description = "Magic field completely omitted"
            
        elif test_key == "6":  # Invalid status code
            payload = build_test_payload("invalid_code", channel)
            description = "Invalid status code (999)"
            
        elif test_key == "7":  # Malformed structure
            payload = build_test_payload("malformed", channel)
            description = "Missing par1, par2, par3 fields"
            
        elif test_key == "8":  # Custom message
            print("\n--- Custom Message Builder ---")
            magic = input("Magic field (press Enter for empty/spontaneous): ").strip()
            code = input("Status code (e.g., 7, 999, abc): ").strip()
            par1 = input("Par1 field: ").strip()
            par2 = input(f"Par2 field (current channel: {channel}): ").strip()
            if not par2:
                par2 = channel
            par3 = input("Par3 field: ").strip()
            
            # Build custom payload
            lines = ["status", magic, code, par1, par2, par3]
            text = "\n".join(lines)
            if len(text) > MAX_REPLY_LEN:
                text = text[:MAX_REPLY_LEN]
            payload = text.encode("utf-8", errors="ignore")
            description = f"Custom: magic='{magic}', code='{code}', par2='{par2}'"
        
        else:
            print(f"❌ Unknown test key: {test_key}")
            return False
        
        # Send the test message
        mq.send(payload, type=PAYLOAD_TO_AAS)
        print(f"✓ Sent {test_msg['name']}: {description} at {time.strftime('%H:%M:%S')}")
        
        # Show the raw payload for debugging
        print(f"📋 Raw payload: {payload.decode('utf-8', errors='replace')!r}")
        return True
        
    except sysv_ipc.BusyError:
        print(f"⚠ Queue busy, failed to send {test_msg['name']}")
        return False
    except Exception as e:
        print(f"❌ Error sending {test_msg['name']}: {e}")
        return False
 
 
def interactive_mode(mq: sysv_ipc.MessageQueue, initial_channel: str):
    """Run the interactive message sending mode."""
    channel = initial_channel
    
    while True:
        display_menu()
        print(f"Current channel: {channel}")
        
        try:
            choice = input("\nEnter your choice: ").strip().lower()
        except KeyboardInterrupt:
            print("\n\n🛑 Exiting...")
            break
        except EOFError:
            print("\n\n🛑 Exiting...")
            break
        
        if choice == 'q':
            print("🛑 Exiting...")
            break
        elif choice == 'c':
            new_channel = input(f"Enter new channel address (current: {channel}): ").strip()
            if new_channel:
                channel = new_channel
                print(f"✓ Channel changed to: {channel}")
            else:
                print("Channel address unchanged")
        elif choice in STATUS_MESSAGES:
            send_single_message(mq, choice, channel)
        elif choice in TEST_MESSAGES:
            send_test_message(mq, choice, channel)
        else:
            print(f"❌ Invalid choice: {choice}")
 
 
def main():
    ap = argparse.ArgumentParser(
        description="ELISA III-IP Interactive Status Message Sender with Edge Case Testing",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
This script allows you to send individual status messages interactively:
  Standard messages:
    1. NO_ERR_DEVICE (code 7)
    2. NO_ERR_DEST (code 6) with channel address
    3. ERR_DESTDEF (code 21) with channel address  
    4. ERR_DEVICEDEF (code 30)
  
  Test scenarios for edge cases:
    5. Missing magic field (completely omitted)
    6. Invalid status code (999)
    7. Malformed message structure
    8. Custom message with user input
 
You can send messages one by one, change the channel address, and test
various edge cases to see how the AAS handles malformed messages.
        """
    )
    
    ap.add_argument("--ftok-dir", required=True,
                    help="Directory or file path for SysV IPC ftok token (same as elisa3_sim.py)")
    ap.add_argument("--proj-id", type=int, default=65,
                    help="ftok project id (0..255, default: 65)")
    ap.add_argument("--channel", type=str, default="CH:1-1",
                    help="Initial channel address for par2 field (default: CH:1-1)")
 
    args = ap.parse_args()
    
    print("="*70)
    print("ELISA3 Interactive Status Message Sender with Edge Case Testing")
    print("="*70)
    print(f"ftok-dir:  {args.ftok_dir}")
    print(f"proj-id:   {args.proj_id}")
    print(f"channel:   {args.channel}")
    print("="*70)
    
    # Set up IPC
    ftok_dir = Path(args.ftok_dir)
    token = ensure_token(ftok_dir)
    key = ftok_key(token, args.proj_id)
    
    print(f"Token file: {token}")
    print(f"IPC Key:    0x{key:08x} ({key})")
    
    try:
        mq = sysv_ipc.MessageQueue(key, sysv_ipc.IPC_CREAT, mode=0o666)
        print("✓ Message queue opened successfully")
    except Exception as e:
        print(f"❌ Failed to open message queue: {e}", file=sys.stderr)
        sys.exit(1)
    
    # Signal handling for graceful shutdown
    def on_sigint(signum, frame):
        print("\n\n🛑 Interrupted, exiting...")
        sys.exit(0)
    
    signal.signal(signal.SIGINT, on_sigint)
    signal.signal(signal.SIGTERM, on_sigint)
    
    print("\n🚀 Starting interactive mode...\n")
    print("💡 You can now test edge cases:")
    print("   - Options 5-7 for predefined test scenarios")
    print("   - Option 8 for custom messages with any values")
    print("   - Option 'c' to set invalid channel addresses")
    
    try:
        interactive_mode(mq, args.channel)
    except KeyboardInterrupt:
        print("\n\n🛑 Status message sender stopped")
        sys.exit(0)
 
 
if __name__ == "__main__":
    main()
 