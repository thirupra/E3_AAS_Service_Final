#!/usr/bin/env python3
# filepath: test_single_anndel.py
import pika
import json
import time
import uuid
from datetime import datetime, timezone, timedelta
 
def send_message(message, exchange='test_exchange1', routing_key='test_routingkey1'):
    connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
    channel = connection.channel()
    channel.basic_publish(
        exchange=exchange,
        routing_key=routing_key,
        body=json.dumps(message),
        properties=pika.BasicProperties(content_type='application/json')
    )
    connection.close()
 
def annout_payload(seq, priority, channel, valid_until, requested_output_time, extra_fields=None):
    payload = {
        "msg-meta": {
            "id": str(uuid.uuid4()),
            "created": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "000Z",
            "type": "PDCC",
            "version": "1.5"
        },
        "physicalDeviceCommands": [
            {
                "pdevCommand": {
                    "cmd-meta": {
                        "deviceCommandId": f"TEST-DeviceCommandId-{seq}",
                        "priority": priority,
                        "command": "ANNOUT",
                        "channelAddress": channel,
                        "validUntil": valid_until.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "000Z",
                        "requestedOutputTime": requested_output_time.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "000Z",
                        "sequenceNo": seq,
                        "announcementId": f"TEST-ANNOUTID-{seq}",
                        "announcementHash": str(uuid.uuid4().hex),
                        "announcementProfile": {
                            "text": f"Test announcement {seq}",
                            "language": "en"
                        }
                    },
                    "cmd-content": {
                        "content-type": "text/x-url",
                        "content-transfer-encoding": "",
                        "content": "https://freetestdata.com/wp-content/uploads/2021/09/Free_Test_Data_100KB_OGG.ogg"
                    }
                }
            }
        ]
    }
    if extra_fields:
        payload["extra"] = extra_fields
    return payload
 
def anndel_payload(announcement_id):
    return {
        "msg-meta": {
            "id": str(uuid.uuid4()),
            "created": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "000Z",
            "type": "PDCC",
            "version": "1.5"
        },
        "physicalDeviceCommands": [
            {
                "pdevCommand": {
                    "cmd-meta": {
                        "deviceCommandId": f"DEL-{announcement_id}",
                        "priority": 4,
                        "command": "ANNDEL",
                        "announcementId": announcement_id
                    }
                }
            }
        ]
    }
 
def generate_annout_tests():
    now = datetime.now(timezone.utc)
    tests = []
 
    # 1. Multiple ANNOUT messages with different sequence, priority, time
    for i in range(3):
        valid_until = now + timedelta(seconds=60 + i*10)
        requested_output_time = now + timedelta(seconds=10 + i*5)
        tests.append(annout_payload(seq=100+i, priority=2+i, channel=f"CH-01-{i+1}", valid_until=valid_until, requested_output_time=requested_output_time))
 
    # 3. Single ANNOUT with updating sequence, priority, time
    tests.append(annout_payload(seq=62, priority=7, channel="CH-02-2", valid_until=now+timedelta(seconds=120), requested_output_time=now+timedelta(seconds=30)))

    # 4. ANNOUT with extra fields (should be ignored)
    tests.append(annout_payload(seq=59, priority=7, channel="CH-02-2", valid_until=now+timedelta(seconds=120), requested_output_time=now+timedelta(seconds=30), extra_fields={"foo": "bar"}))
 
    # 5. Multiple channels handling
    for ch in ["CH-01-1", "CH-02-1"]:
        tests.append(annout_payload(seq=300, priority=4, channel=ch, valid_until=now+timedelta(seconds=120), requested_output_time=now+timedelta(seconds=30)))
 
    # 6. Sequence number handling (duplicate sequence)
    tests.append(annout_payload(seq=100, priority=7, channel="CH-01-1", valid_until=now+timedelta(seconds=120), requested_output_time=now+timedelta(seconds=30)))
 
    # 7. Missing mandatory fields
    msg = annout_payload(seq=400, priority=4, channel="CH-01-1", valid_until=now+timedelta(seconds=120), requested_output_time=now+timedelta(seconds=30))
    del msg["physicalDeviceCommands"][0]["pdevCommand"]["cmd-meta"]["priority"]
    tests.append(msg)
 
    # 8. Invalid priority value
    tests.append(annout_payload(seq=25, priority=7, channel="CH-01-1", valid_until=now+timedelta(seconds=120), requested_output_time=now+timedelta(seconds=60)))
 
    # 9. Invalid timestamp format
    msg = annout_payload(seq=402, priority=4, channel="CH-01-1", valid_until=now+timedelta(seconds=120), requested_output_time=now+timedelta(seconds=30))
    msg["physicalDeviceCommands"][0]["pdevCommand"]["cmd-meta"]["validUntil"] = "invalid-timestamp"
    tests.append(msg)
 
    # 10. Expired announcements in queue
    expired_time = now - timedelta(seconds=10)
    tests.append(annout_payload(seq=403, priority=4, channel="CH-01-1", valid_until=expired_time, requested_output_time=expired_time))
 
    # 11. Zero-delay execution
    tests.append(annout_payload(seq=404, priority=4, channel="CH-01-1", valid_until=now+timedelta(seconds=120), requested_output_time=now))
 
    # 12. Large batch scheduling (50 ANNOUT)
    for i in range(50):
        tests.append(annout_payload(seq=500+i, priority=4, channel="CH-01-1", valid_until=now+timedelta(seconds=120), requested_output_time=now+timedelta(seconds=30+i)))
 
    return tests
 
def generate_anndel_tests():
    tests = []
    # 13. ANNDEL before validUntil expiry
    tests.append(anndel_payload("TEST-ANNOUTID-200"))
 
    # 14. ANNDEL for non-existent announcement
    tests.append(anndel_payload("NON-EXISTENT-ID"))
 
    # 15. ANNDEL payload for already deleted announcement
    tests.append(anndel_payload("TEST-ANNOUTID-200"))
 
    # 16. Sequential deletion of multiple announcements
    for i in range(3):
        tests.append(anndel_payload(f"TEST-ANNOUTID-{100+i}"))
 
    return tests
 
def generate_network_recovery_tests():
    now = datetime.now(timezone.utc)
    tests = []
    for i in range(2):
        tests.append(annout_payload(seq=600+i, priority=4, channel="CH-01-1", valid_until=now+timedelta(seconds=120), requested_output_time=now+timedelta(seconds=30)))
    return tests
 
def choose_and_send(test_list, indices):

    for idx in indices:

        msg = test_list[idx]

        # Determine if ANNOUT or ANNDEL

        try:
            
            cmd_meta = msg["physicalDeviceCommands"][0]["pdevCommand"]["cmd-meta"]
            cmd_content = msg["physicalDeviceCommands"][0]["pdevCommand"]["cmd-content"]
            command = cmd_meta.get("command", "")

            if command == "ANNOUT":

                print(f"Sending ANNOUT test index {idx}:")
                print(f"  DeviceCommandId: {cmd_meta.get('deviceCommandId')}")
                print(f"  SequenceNo: {cmd_meta.get('sequenceNo')}")

                print(f"  Priority: {cmd_meta.get('priority')}")

                print(f"  Channel: {cmd_meta.get('channelAddress')}")

                print(f"  AnnouncementId: {cmd_meta.get('announcementId')}")

                print(f"  RequestedOutputTime: {cmd_meta.get('requestedOutputTime')}")

                print(f"  ValidUntil: {cmd_meta.get('validUntil')}")
                #print(f"  AudioUrl:{cmd_content.get('content')}")
                print(f"  AnnouncementHash:{cmd_meta.get('announcementHash')}")

            elif command == "ANNDEL":

                print(f"Sending ANNDEL test index {idx}:")
                print(f"  DeviceCommandId: {cmd_meta.get('deviceCommandId')}")
 
                print(f"  AnnouncementId: {cmd_meta.get('announcementId')}")

                print(f"  Priority: {cmd_meta.get('priority')}")

            else:

                print(f"Sending test index {idx}: Unknown command type")

        except Exception as e:

            print(f"Sending test index {idx}: Unable to parse details ({e})")

        send_message(msg)
 
        

 
def annout_test_descriptions():
    return [
        "0-2: Multiple ANNOUT messages with different sequence, priority, time (test indices: 0,1,2)",
        "3: Single ANNOUT with updating sequence, priority, time (test index: 3)",
        "4: ANNOUT with extra fields (should be ignored) (test index: 4)",
        "5-6: Multiple channels handling (test indices: 5,6)",
        "7: Sequence number handling (duplicate sequence) (test index: 7)",
        "8: Missing mandatory fields (priority) (test index: 8)",
        "9: Invalid priority value (test index: 9)",
        "10: Invalid timestamp format (test index: 10)",
        "11: Expired announcements in queue (test index: 11)",
        "12: Zero-delay execution (test index: 12)",
        "13-62: Large batch scheduling (50 ANNOUT) (test indices: 13-62)"
    ]
 
def anndel_test_descriptions():
    return [
        "0: ANNDEL before validUntil expiry (test index: 0)",
        "1: ANNDEL for non-existent announcement (test index: 1)",
        "2: ANNDEL payload for already deleted announcement (test index: 2)",
        "3: Sequential deletion of multiple announcements (test indices: 3,4,5)"
    ]
 
def network_test_descriptions():
    return [
        "0: Network recovery scenario (send ANNOUT after reconnect 1) (test index: 0)",
        "1: Network recovery scenario (send ANNOUT after reconnect 2) (test index: 1)"
    ]
 
# Usage example:
# annout_tests = generate_annout_tests()
# anndel_tests = generate_anndel_tests()
# network_tests = generate_network_recovery_tests()
# choose_and_send(annout_tests, [0, 5, 10])  # Send selected ANNOUT tests
# choose_and_send(anndel_tests, [0, 2])      # Send selected ANNDEL tests
# choose_and_send(network_tests, [1])        # Send selected network recovery test
 
if __name__ == "__main__":
    print("Choose test type:")
    print("1. ANNOUT tests")
    print("2. ANNDEL tests")
    print("3. Network recovery tests")
    choice = input("Enter choice (1/2/3): ").strip()
 
    if choice == "1":
        tests = generate_annout_tests()
        desc = annout_test_descriptions()
        print(f"Available ANNOUT tests: {len(tests)} (indices 0 to {len(tests)-1})")
        for d in desc:
            print(d)
    elif choice == "2":
        tests = generate_anndel_tests()
        desc = anndel_test_descriptions()
        print(f"Available ANNDEL tests: {len(tests)} (indices 0 to {len(tests)-1})")
        for d in desc:
            print(d)
    elif choice == "3":
        tests = generate_network_recovery_tests()
        desc = network_test_descriptions()
        print(f"Available Network tests: {len(tests)} (indices 0 to {len(tests)-1})")
        for d in desc:
            print(d)
    else:
        print("Invalid choice.")
        exit(1)
 
    indices = input("Enter test indices to send (comma separated, e.g. 0,2,5): ")
    try:
        idx_list = [int(i.strip()) for i in indices.split(",") if i.strip().isdigit()]
        choose_and_send(tests, idx_list)
    except Exception as e:
        print(f"Error: {e}")
 