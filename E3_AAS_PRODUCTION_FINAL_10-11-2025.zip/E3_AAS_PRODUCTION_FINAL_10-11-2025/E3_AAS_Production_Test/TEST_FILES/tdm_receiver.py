#!/usr/bin/env python3
"""
TDM Message Receiver for AAS Service Testing

This script receives and displays TDM (Technical Device Message) messages
from the AAS service to verify that ELISA3 status messages are being
forwarded correctly.
"""

import json
import time
import pika
import sys
import argparse
from datetime import datetime

# ELISA status code names for better readability
ELISA_STATUS_CODES = {
    2: "NO_ERR_STOP (Success)",
    6: "NO_ERR_DEST (Destination OK)",
    7: "NO_ERR_DEVICE (Device OK)",
    11: "E_NO_DEVICE (No Device)",
    15: "E_NO_LINE (No Line)",
    21: "ERR_DESTDEF (Destination Defective)",
    22: "E_DEST_OCC (Destination Occupied)",
    30: "ERR_DEVICEDEF (Device Defective)",
    500: "E_UNKNOWN (Unknown Error)",
}

class TDMReceiver:
    def __init__(self, host='localhost', port=5672, username='guest', password='guest', 
                 virtual_host='/', exchange='test_exchange3', routing_key='test_routingkey3'):
        """Initialize the TDM receiver with RabbitMQ connection parameters."""
        self.connection_params = pika.ConnectionParameters(
            host=host,
            port=port,
            virtual_host=virtual_host,
            credentials=pika.PlainCredentials(username, password)
        )
        self.exchange = exchange
        self.routing_key = routing_key
        self.connection = None
        self.channel = None
        self.message_count = 0
        self.queue_name = ""  # Auto-generated queue name

    def connect(self):
        """Establish connection to RabbitMQ broker."""
        try:
            self.connection = pika.BlockingConnection(self.connection_params)
            self.channel = self.connection.channel()
            
            # Declare the exchange (passive=True to check if it exists, durable=True to match existing)
            try:
                self.channel.exchange_declare(exchange=self.exchange, exchange_type='direct', durable=True, passive=True)
            except pika.exceptions.AMQPChannelError:
                # Exchange doesn't exist, create it
                self.channel = self.connection.channel()  # Reset channel after error
                self.channel.exchange_declare(exchange=self.exchange, exchange_type='direct', durable=True)
            
            # Create an exclusive queue (will be deleted when connection closes)
            result = self.channel.queue_declare(queue='', exclusive=True)
            self.queue_name = result.method.queue
            
            # Bind the queue to the exchange with our routing key
            self.channel.queue_bind(
                exchange=self.exchange,
                queue=self.queue_name,
                routing_key=self.routing_key
            )
            
            print(f"[INFO] Connected to RabbitMQ broker at {self.connection_params.host}:{self.connection_params.port}")
            print(f"[INFO] Listening for TDM messages on exchange '{self.exchange}' with routing key '{self.routing_key}'")
            print(f"[INFO] Using queue: {self.queue_name}")
            return True
        except Exception as e:
            print(f"[ERROR] Failed to connect to RabbitMQ: {e}")
            return False

    def disconnect(self):
        """Close the RabbitMQ connection."""
        if self.connection and not self.connection.is_closed:
            self.connection.close()
            print("[INFO] Disconnected from RabbitMQ")

    def get_status_name(self, code):
        """Get human-readable name for ELISA status code."""
        return ELISA_STATUS_CODES.get(code, f"Unknown Code ({code})")

    def process_message(self, ch, method, properties, body):
        """Process received TDM messages."""
        try:
            self.message_count += 1
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            
            # Parse the JSON message
            message = json.loads(body.decode('utf-8'))
            
            print(f"\n{'='*70}")
            print(f"📡 TDM MESSAGE #{self.message_count} - {timestamp}")
            print(f"{'='*70}")
            
            # Pretty print the message
            print(json.dumps(message, indent=2))
            
            # Extract and display key information
            print(f"\n{'─'*70}")
            print("📊 MESSAGE ANALYSIS:")
            print(f"{'─'*70}")
            
            if 'elisaStatus' in message:
                elisa_status = message['elisaStatus']
                
                if 'code' in elisa_status:
                    code = elisa_status['code']
                    status_name = self.get_status_name(code)
                    
                    # Color code based on status
                    if code in [2, 6, 7]:
                        symbol = "✅"
                    elif code in [21, 30]:
                        symbol = "⚠️"
                    else:
                        symbol = "❌"
                    
                    print(f"{symbol} Status Code: {code} - {status_name}")
                
                if 'magic' in elisa_status:
                    magic = elisa_status['magic']
                    if magic == "":
                        print("📢 Type: Spontaneous/Unsolicited Status (TDM)")
                    else:
                        print(f"🔗 Type: Response to Command (magic: {magic})")
                
                if 'par1' in elisa_status and elisa_status['par1']:
                    print(f"📝 Parameter 1: {elisa_status['par1']}")
                
                if 'par2' in elisa_status and elisa_status['par2']:
                    print(f"📝 Parameter 2: {elisa_status['par2']}")
                    
                if 'par3' in elisa_status and elisa_status['par3']:
                    print(f"📝 Parameter 3: {elisa_status['par3']}")
            
            if 'timestamp' in message:
                print(f"⏰ Timestamp: {message['timestamp']}")
            
            if 'deviceId' in message:
                print(f"🔧 Device ID: {message['deviceId']}")
            
            print(f"{'='*70}")
            
        except json.JSONDecodeError as e:
            print(f"❌ Failed to parse JSON message: {e}")
            print(f"📄 Raw message: {body.decode('utf-8')}")
        except Exception as e:
            print(f"❌ Error processing message: {e}")
            import traceback
            traceback.print_exc()

    def start_listening(self, timeout=None):
        """Start listening for TDM messages."""
        try:
            # Set up consumer
            self.channel.basic_consume(
                queue=self.queue_name,
                on_message_callback=self.process_message,
                auto_ack=True
            )
            
            print(f"\n{'='*70}")
            print(f"🚀 TDM RECEIVER STARTED")
            print(f"{'='*70}")
            print(f"Waiting for TDM messages from AAS service...")
            print(f"Press Ctrl+C to stop\n")
            
            if timeout:
                print(f"[INFO] Will timeout after {timeout} seconds")
                start_time = time.time()
                while time.time() - start_time < timeout:
                    self.connection.process_data_events(time_limit=1)
            else:
                # Start consuming messages
                self.channel.start_consuming()
                
        except KeyboardInterrupt:
            print("\n[INFO] Stopped by user")
        except Exception as e:
            print(f"[ERROR] Error while listening: {e}")
            import traceback
            traceback.print_exc()
        finally:
            if self.channel:
                try:
                    self.channel.stop_consuming()
                except:
                    pass

def main():
    parser = argparse.ArgumentParser(description='TDM Message Receiver for AAS Service Testing')
    parser.add_argument('--host', default='localhost', help='RabbitMQ host (default: localhost)')
    parser.add_argument('--port', type=int, default=5672, help='RabbitMQ port (default: 5672)')
    parser.add_argument('--username', default='guest', help='RabbitMQ username (default: guest)')
    parser.add_argument('--password', default='guest', help='RabbitMQ password (default: guest)')
    parser.add_argument('--exchange', default='test_exchange3', help='Exchange name (default: test_exchange3)')
    parser.add_argument('--routing-key', default='test_routingkey3', help='Routing key (default: test_routingkey3)')
    parser.add_argument('--timeout', type=int, help='Timeout in seconds (default: no timeout)')
    
    args = parser.parse_args()
    
    # Create TDM receiver
    receiver = TDMReceiver(
        host=args.host,
        port=args.port,
        username=args.username,
        password=args.password,
        exchange=args.exchange,
        routing_key=args.routing_key
    )
    
    # Connect to broker
    if not receiver.connect():
        sys.exit(1)
    
    try:
        receiver.start_listening(timeout=args.timeout)
    except Exception as e:
        print(f"[ERROR] Unexpected error: {e}")
    finally:
        receiver.disconnect()

if __name__ == "__main__":
    main()

