#!/usr/bin/env python3
# filepath: test_single_anndel.py
import pika
import json
import time
import uuid
import hashlib
from datetime import datetime, timezone, timedelta
 
# Connect to RabbitMQ
connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
channel = connection.channel()
 
now = datetime.now(timezone.utc)
valid_until = now + timedelta(seconds=180)
requested_output_time = now + timedelta(seconds=60)

channel_address = "CH:1-1"
def generate_hash_for_url(url):
    return hashlib.sha1(url.encode()).hexdigest()
audio_url = "https://github.com/my-sample-files/files-hub/raw/refs/heads/main/audio/ogg/sample-30s.ogg"
unique_hash = generate_hash_for_url(audio_url)

# 1. Send ANNOUT message (with correct structure)
annout_message = {
    
    "msg-meta": {
        "id": str(uuid.uuid4()),
        "created": now.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "000Z",
        "type": "PDCC",
        "version": "1.5"       
    },
    "physicalDeviceCommands": [
        {
            "pdevCommand": {
                
                "cmd-meta": {
                    
                    "deviceCommandId": "TEST-DeviceCommandId-165",
                    "priority": 8,
                    "command": "ANNOUT",
                    "channelAddress": "CH-02-2",
                    "validUntil": valid_until.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "000Z",
                    "requestedOutputTime": requested_output_time.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "000Z",
                    "sequenceNo": 100165,
                    "announcementId": "TEST-ANNOUTID-165",
                    "announcementHash": unique_hash,
                    "announcementProfile": {
                        "text": "Test announcement",
                        "language": "en"
                    }
                },
                "cmd-content": {
                   
                    "content-type": "text/x-url",
                    "content-transfer-encoding": "",
                    "content": audio_url
                    
                }
            }
        }
    ]
}
 
print("Sending ANNOUT message...")
print(f"Aduio URL: {audio_url}")
print(f"Generated_Hash: {unique_hash}")
channel.basic_publish(
    exchange='test_exchange1',
    routing_key='test_routingkey1',
    body=json.dumps(annout_message),
    properties=pika.BasicProperties(content_type='application/json')
)
print("✅ ANNOUT message sent!")
 
# Wait a moment to ensure ANNOUT is processed
time.sleep(5)
 
 
connection.close()