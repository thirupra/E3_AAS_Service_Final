#!/usr/bin/env python3
"""
Sequential ANNOUT and ANNDEL Test Script
Sends 3 ANNOUT messages followed by 3 ANNDEL messages
All with the same requestedOutputTime and validUntil timestamps
"""
import pika
import json
import time
import uuid
from datetime import datetime, timezone, timedelta

# Connect to RabbitMQ
connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
channel = connection.channel()

# Common timestamps for all messages
now = datetime.now(timezone.utc)
valid_until = now + timedelta(minutes=10)  # 10 minutes from now
requested_output_time = now + timedelta(minutes=2)  # 2 minutes from now

# Format timestamps consistently
valid_until_str = valid_until.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "000Z"
requested_output_time_str = requested_output_time.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "000Z"
created_time_str = now.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "000Z"

print("=" * 80)
print("SEQUENTIAL ANNOUT/ANNDEL TEST")
print("=" * 80)
print(f"Created Time:           {created_time_str}")
print(f"Requested Output Time:  {requested_output_time_str}")
print(f"Valid Until:            {valid_until_str}")
print("=" * 80)

# Test data for 3 announcements
announcements = [
    {
        "id": "TEST-ANNOUT-001",
        "device_command_id": "TEST-DeviceCmd-001",
        "sequence_no": 1001,
        "hash": str(uuid.uuid4()).replace('-', ''),  # Generate UUID hash
        "url": "https://freetestdata.com/wp-content/uploads/2021/09/Free_Test_Data_100KB_OGG.ogg"
    },
    {
        "id": "TEST-ANNOUT-002", 
        "device_command_id": "TEST-DeviceCmd-002",
        "sequence_no": 1002,
        "hash": str(uuid.uuid4()).replace('-', ''),  # Generate UUID hash
        "url": "https://freetestdata.com/wp-content/uploads/2021/09/Free_Test_Data_500KB_OGG.ogg"
    },
    {
        "id": "TEST-ANNOUT-003",
        "device_command_id": "TEST-DeviceCmd-003", 
        "sequence_no": 1003,
        "hash": str(uuid.uuid4()).replace('-', ''),  # Generate UUID hash
        "url": "https://freetestdata.com/wp-content/uploads/2021/09/Free_Test_Data_1MB_OGG.ogg"
    }
]

def send_annout(announcement_data):
    """Send an ANNOUT message"""
    message = {
        "msg-meta": {
            "id": str(uuid.uuid4()),
            "created": created_time_str,
            "type": "PDCC", 
            "version": "1.5"
        },
        "physicalDeviceCommands": [
            {
                "pdevCommand": {
                    "cmd-meta": {
                        "deviceCommandId": announcement_data["device_command_id"],
                        "command": "ANNOUT",
                        "channelAddress": "CH:1-1",
                        "validUntil": valid_until_str,
                        "requestedOutputTime": requested_output_time_str,
                        "sequenceNo": announcement_data["sequence_no"],
                        "announcementId": announcement_data["id"],
                        "announcementHash": announcement_data["hash"],
                        "announcementProfile": {
                            "text": f"Test announcement {announcement_data['id']}",
                            "language": "en"
                        }
                    },
                    "cmd-content": {
                        "content-type": "text/x-url",
                        "content-transfer-encoding": "",
                        "content": announcement_data["url"]
                    }
                }
            }
        ]
    }
    
    channel.basic_publish(
        exchange='test_exchange1',
        routing_key='test_routingkey1', 
        body=json.dumps(message),
        properties=pika.BasicProperties(content_type='application/json')
    )
    
    print(f"✅ ANNOUT sent: {announcement_data['id']} (DeviceCmd: {announcement_data['device_command_id']})")

def send_anndel(announcement_data):
    """Send an ANNDEL message"""
    message = {
        "msg-meta": {
            "id": str(uuid.uuid4()),
            "created": created_time_str,
            "type": "PDCC",
            "version": "1.5"
        },
        "physicalDeviceCommands": [
            {
                "pdevCommand": {
                    "cmd-meta": {
                        "deviceCommandId": announcement_data["device_command_id"] + "-DEL",
                        "command": "ANNDEL", 
                        "channelAddress": "CH:1-1",
                        "sequenceNo": announcement_data["sequence_no"] + 1000,  # Higher sequence for delete
                        "announcementId": announcement_data["id"]
                    }
                }
            }
        ]
    }
    
    channel.basic_publish(
        exchange='test_exchange1',
        routing_key='test_routingkey1',
        body=json.dumps(message), 
        properties=pika.BasicProperties(content_type='application/json')
    )
    
    print(f"🗑️  ANNDEL sent: {announcement_data['id']} (DeviceCmd: {announcement_data['device_command_id']}-DEL)")

# Phase 1: Send all 3 ANNOUT messages
print("\n📤 PHASE 1: Sending ANNOUT messages...")
print("-" * 50)
for i, announcement in enumerate(announcements, 1):
    print(f"Sending ANNOUT {i}/3...")
    send_annout(announcement)
    time.sleep(2)  # Wait 2 seconds between messages

print(f"\n⏳ Waiting 10 seconds for ANNOUT processing...")
time.sleep(10)

# Phase 2: Send all 3 ANNDEL messages  
print("\n🗑️  PHASE 2: Sending ANNDEL messages...")
print("-" * 50)
for i, announcement in enumerate(announcements, 1):
    print(f"Sending ANNDEL {i}/3...")
    send_anndel(announcement)
    time.sleep(2)  # Wait 2 seconds between messages

print("\n" + "=" * 80)
print("✅ ALL MESSAGES SENT SUCCESSFULLY!")
print("=" * 80)
print("Summary:")
print("- 3 ANNOUT messages sent with same timestamps")
print("- 3 ANNDEL messages sent with same timestamps") 
print("- All messages use consistent timing:")
print(f"  • requestedOutputTime: {requested_output_time_str}")
print(f"  • validUntil:          {valid_until_str}")
print("=" * 80)

connection.close()