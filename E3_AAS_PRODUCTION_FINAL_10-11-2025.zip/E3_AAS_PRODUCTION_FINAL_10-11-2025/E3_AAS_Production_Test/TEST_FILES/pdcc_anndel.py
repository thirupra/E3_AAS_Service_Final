#!/usr/bin/env python3
import pika
import json
import time
import uuid
from datetime import datetime, timezone, timedelta

# Connect to RabbitMQ
connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
channel = connection.channel()

# Create simple ANNDEL message
now = datetime.now(timezone.utc)
valid_until = now + timedelta(seconds=120)

announcement_id = "TEST-ANNOUTID-008";
message = {
    "msg-meta": {
        "id": str(uuid.uuid4()),
        "created": now.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "000",
        "type": "PDCC",
        "version": "1.5"
    },
    "physicalDeviceCommands": [
        {
            "pdevCommand": {
                "cmd-meta": {
                    "deviceCommandId": "TEST-DeviceCommandId-008",
                    "command": "ANNDEL",
                    "channelAddress": "CH:1-1",
                    "validUntil": valid_until.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "000Z",
                    "sequenceNo": 1000080,
                    "announcementId": announcement_id
                }
            }
        }
    ]
}

print("Sending single ANNDEL message...")
print(f"AnnouncementID: ",announcement_id)
print(f"Command: ANNDEL")

# Send message
channel.basic_publish(
    exchange='test_exchange1',
    routing_key='test_routingkey1',
    body=json.dumps(message),
    properties=pika.BasicProperties(content_type='application/json')
)

print("✅ Message sent!")
connection.close()
