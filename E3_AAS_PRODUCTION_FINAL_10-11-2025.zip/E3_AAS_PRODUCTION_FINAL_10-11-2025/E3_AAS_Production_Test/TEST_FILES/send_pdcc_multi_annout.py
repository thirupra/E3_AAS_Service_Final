#!/usr/bin/env python3
import os, json, uuid, time, random, datetime
import pika

EXCHANGE     = os.getenv("PDCC_EXCHANGE", "test_exchange2")
ROUTING_KEY  = os.getenv("PDCC_ROUTING_KEY", "test_routingkey2")
CHANNEL_ADDR = os.getenv("CHANNEL_ADDR", "871982313")
DUE_OFFSET_S = int(os.getenv("DUE_OFFSET_SEC", "8"))   # all due in +8s (adjust as you like)
TEXT_PREFIX  = os.getenv("TEXT_PREFIX", "Batch ANNOUT")

def single_annout(text:str, priority:int, due_dt:datetime.datetime, valid_dt:datetime.datetime):
    ann_id = str(uuid.uuid4())
    cmd_id = str(uuid.uuid4())
    return {
        "event": "pdc-received",
        "type": "info",
        "product": "ela",
        "service": "aag",
        "timestamp": int(time.time() * 1000),
        "metaData": {
            "command": "ANNOUT",
            "deviceCommandId": cmd_id,
            "sequenceNo": random.randint(2_000_000, 9_999_999),
            "announcementId": ann_id,
            "channelAddress": CHANNEL_ADDR,
            "priority": priority,
            "announcementHash": "8f4285c72ee645695d17f93ed0328784d04fa27d",
            "announcementProfile": {"language": "en", "text": text},
            "requestedOutputTime": due_dt.strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
            "validUntil": valid_dt.strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
        },
    }

def publish_batch(commands:list):
    conn = pika.BlockingConnection(pika.ConnectionParameters(host="localhost", port=5672))
    ch = conn.channel()
    # IMPORTANT: your exchange is 'direct'
    ch.exchange_declare(exchange=EXCHANGE, exchange_type="direct", durable=True)
    ch.basic_publish(
        exchange=EXCHANGE,
        routing_key=ROUTING_KEY,
        body=json.dumps(commands).encode("utf-8"),
        properties=pika.BasicProperties(content_type="application/json", delivery_mode=2),
    )
    conn.close()

if __name__ == "__main__":
    now = datetime.datetime.utcnow()
    due  = now + datetime.timedelta(seconds=DUE_OFFSET_S)
    valid= now + datetime.timedelta(minutes=5)

    cmds = [
        single_annout(f"{TEXT_PREFIX} #1 (P7)", 7, due, valid),
        single_annout(f"{TEXT_PREFIX} #2 (P5)", 5, due, valid),
        single_annout(f"{TEXT_PREFIX} #3 (P3)", 3, due, valid),
    ]

    print(f"Publishing ONE AMQP message containing {len(cmds)} ANNOUT commands; due in +{DUE_OFFSET_S}s")
    publish_batch(cmds)

