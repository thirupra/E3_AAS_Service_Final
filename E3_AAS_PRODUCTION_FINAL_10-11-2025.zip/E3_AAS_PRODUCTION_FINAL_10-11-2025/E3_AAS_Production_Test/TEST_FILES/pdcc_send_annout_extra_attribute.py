#!/usr/bin/env python3
# filepath: test_single_anndel.py
import pika
import json
import time
import uuid
from datetime import datetime, timezone, timedelta
 
# Connect to RabbitMQ
connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
channel = connection.channel()
 
now = datetime.now(timezone.utc)
valid_until = now + timedelta(seconds=120)
requested_output_time = now + timedelta(seconds=30)

channel_address = "CH:1-1"
 
# 1. Send ANNOUT message (with correct structure)
annout_message = {
    "extra": {
    "foo": "bar"
  },
    "msg-meta": {
        "id": str(uuid.uuid4()),
        "created": now.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "000Z",
        "type": "PDCC",
        "version": "1.5",
        "name": "Extra value",
        "extraId": 1234
    },
    "physicalDeviceCommands": [
        {
            "pdevCommand": {
                "extra2": {
    "too": "bar"
  },
                "cmd-meta": {
                    "extraAttribute": "extraValue",
                    "deviceCommandId": "TEST-DeviceCommandId-006",
                    "priority": 3,
                    "command": "ANNOUT",
                    "channelAddress": "CH-01-1",
                    "validUntil": valid_until.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "000Z",
                    "requestedOutputTime": requested_output_time.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "000Z",
                    "sequenceNo": 1000156,
                    "announcementId": "TEST-ANNOUTID-156",
                    "announcementHash": "8f4285c72ee645695d17f93ed0328784d04fa27d",
                    "announcementProfile": {
                        "text": "Test announcement",
                        "language": "en"
                    }
                },
                "cmd-content": {
                   "extraCmdContentAttribute": "extraCmdContentValue",
                    "content-type": "text/x-url",
                    "content-transfer-encoding": "",
                    "content": "https://freetestdata.com/wp-content/uploads/2021/09/Free_Test_Data_100KB_OGG.ogg"
                }
            }
        }
    ]
}
 
print("Sending ANNOUT message...")
channel.basic_publish(
    exchange='test_exchange1',
    routing_key='test_routingkey1',
    body=json.dumps(annout_message),
    properties=pika.BasicProperties(content_type='application/json')
)
print("✅ ANNOUT message sent!")
 
# Wait a moment to ensure ANNOUT is processed
time.sleep(5)
 
 
connection.close()