import pika

import json

import time

import uuid

import hashlib

from datetime import datetime, timezone, timedelta
 
# Connect to RabbitMQ

connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))

channel = connection.channel()
 
now = datetime.now(timezone.utc)

valid_until = now + timedelta(seconds=300)  # 5 minutes validity

requested_output_time = now + timedelta(seconds=60)  # 1 minute delay
 
# List of audio URLs

audio_urls = [

    "https://freetestdata.com/wp-content/uploads/2021/09/Free_Test_Data_100KB_OGG.ogg",

    "https://getsamplefiles.com/download/ogg/sample-4.ogg",

    "https://getsamplefiles.com/download/ogg/sample-1.ogg"

]
 
# Generate a unique hash for the combined URLs

announcement_id = "TEST-ANNOUTID-MULTI_2"

announcement_hash = hashlib.md5("".join(audio_urls).encode()).hexdigest()
 
pdev_command = {

    "pdevCommand": {

        "cmd-meta": {

            "deviceCommandId": "TEST-DeviceCommandId-MULTI",

            "priority": 7,

            "command": "ANNOUT",

            "channelAddress": "CH-01-MULTI",

            "validUntil": valid_until.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "000Z",

            "requestedOutputTime": requested_output_time.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "000Z",

            "sequenceNo": 100011,

            "announcementId": announcement_id,

            "announcementHash": announcement_hash,

            "announcementProfile": {

                "text": "Test announcement with multiple audio files",

                "language": "en"

            }

        },

        "cmd-content": {

            "content-type": "text/x-url",

            "content-transfer-encoding": "",

            "content": audio_urls  # List of URLs

        }

    }

}
 
annout_message = {

    "msg-meta": {

        "id": str(uuid.uuid4()),

        "created": now.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "000Z",

        "type": "PDCC",

        "version": "1.5"

    },

    "physicalDeviceCommands": [pdev_command]

}
 
print("Sending ANNOUT message with multiple audio files for one announcementId...")

print(json.dumps(annout_message, indent=2))
 
channel.basic_publish(

    exchange='test_exchange1',

    routing_key='test_routingkey1',

    body=json.dumps(annout_message),

    properties=pika.BasicProperties(content_type='application/json')

)

print("✅ ANNOUT message sent!")
 
time.sleep(5)

connection.close()
 